<?php 

// +------------------------------------------------------------------+
// |                                                                  |
// | Copyright 1999-Present Kryptronic, Inc. All rights reserved.     |
// |                                                                  |
// | This software is copyrighted, trademarked, developed and         |
// | licensed by Kryptronic, Inc. This software is distributed        |
// | under license.                                                   |
// |                                                                  |
// | View the license agreement for more information.  Installation   |
// | of this software package indicates acceptance of the license     |
// | agreement.                                                       |
// |                                                                  |
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | IF INSTRUCTED TO EDIT THE $main_path_force VARIABLE, EDIT THE    |
// | VALUE BETWEEN THE SINGLE QUOTES ON THE FOLLOWING LINE.           |
// +------------------------------------------------------------------+

$main_path_force   = '';

$perms_level_files  = '777';
$perms_level_dirs   = '777';
$perms_level_exec   = '777';

// +------------------------------------------------------------------+
// | DO NOT EDIT BELOW THIS LINE.                                     |
// +------------------------------------------------------------------+

// +--
// | Debugger Note:  If you would like to turn debugging on, once the
// | core is installed you can adjust the class $debug variable in
// | the file {PRIVATE}/core/CORE/CORE.php.  The following settings
// | apply:
// |
// | 0:         Debugging off (default)
// | 1:         File-based output (sent to {PRIVATE}/temp directory)
// | 2:         Browser-based output (sent to web browser)
// +--

// +--
// | The following parameters are to be left alone.  They represent
// | core directives that affect how this program operates when 
// | executed.  These parameters need to remain unchanged here but 
// | may require changes to run other core-based scripts via methods
// | like cron.
// |
// | app:       The 'app' parameter is generally left blank.  'app' is
// |            passed using URL parameters.
// |
// | namespace: The 'namespace' parameter is generally left blank.  
// |            'namespace' is passed using URL parameters.
// |
// | interface: The 'interface' parameter dictates the interface
// |            to be run by the core.
// | 
// |            Value FrontEnd:  Produces frontend interface
// |            Value BackEnd:   Produces backend (admin) interface
// |            Value Installer: Produces installer (admin without
// |                             login) interface
// |
// | output:    The 'output' parameter allows the caller script to
// |            run the core without any output being generated.
// |           
// |            Value 0:         No Output Produced
// |            Value 1:         Output standards compliant XHTML
// |
// | errhandle: The 'errhandle' parameter allows the caller script to
// |            specify whether errors should be triggered or returned
// |            in an array.
// |           
// |            Value 0:         Trigger error in core
// |            Value 1:         Return a COREerror object.
// +--

$interface = 'Installer';
$output    = 0;
$errhandle = 1;

// +--
// | Enter the installer script name if it has been changed.
// +--

$installer_script = 'installer.php';

// +--
// | Set permissions level for executable files and 
// | dirs to the same level as this file.
// +--

$thisfile = __FILE__;

while (preg_match('/\\\\/',$thisfile)) {$thisfile = preg_replace('/\\\\/','/',$thisfile);}

while (preg_match('/\/\//',$thisfile)) {$thisfile = preg_replace('/\/\//','/',$thisfile);}

$thisfile = preg_replace('/\/$/','',$thisfile);

$thisfile_perms = @substr(@decoct(@fileperms($thisfile)),3);

if ((!(empty($thisfile_perms))) && ($thisfile_perms == 755)) {

     $perms_level_exec = $thisfile_perms;

} // End of if statement.

// +--
// | Main program loader.  This object call creates an instance
// | of the COREmain class.  When the exec() function runs, the
// | program runs and produces output.  We exit() afterwards.
// +--

$coremain = new COREmain;

$coremain->exec(array('core.main_path_force'    => $main_path_force,
                      'core.interface'          => $interface,
                      'core.output'             => $output,
                      'core.errhandle'          => $errhandle,
                      'core.perms_level_files'  => $perms_level_files,
                      'core.perms_level_dirs'   => $perms_level_dirs,
                      'core.perms_level_exec'   => $perms_level_exec,
                      'installer.script_name'   => $installer_script));

// +--
// | Exit() is called from within the core during it's shutdown
// | function, however it's good practice to call it here as well
// | to handle garbage collection.
// +--

exit();

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | COREmain Core Class                                              |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Class Definition                                                 |
// +------------------------------------------------------------------+

class COREmain {

// +--
// | This class is used to verify the PHP environment we're running
// | in, load and execute the CORE class and provide error handling
// | outside of the scope of the main core class.
// +--

// +------------------------------------------------------------------+
// | Class Variables                                                  |
// +------------------------------------------------------------------+

var $class   = 'COREmain';
var $version = '8.0.0';
var $cerror;

// +------------------------------------------------------------------+
// | Constructor Function                                             |
// +------------------------------------------------------------------+

function COREmain () {

// +--
// | This is the constructor function.  This function starts up the
// | class.  Any pre-load variable assignments go here.
// +--

// +--
// | Return object.
// +--

return $this;

} // End of function.

// +------------------------------------------------------------------+
// | Function: exec                                                   |
// +------------------------------------------------------------------+

function exec ($input = array()) {

// +--
// | This routine is run to run the internals of the class.  Main class
// | logic is contained in this function.
// +--

// +--
// | Set our timezone to avoid PHP5 notices about the timezone
// | not being set.
// +--

if ((function_exists('date_default_timezone_get')) && (!(ini_get('date.timezone')))) {

     $timezone = @date_default_timezone_get();

     if (function_exists('date_default_timezone_set')) {

          @date_default_timezone_set($timezone);

     } // End of if statement.

} // End of if statement.

// +--
// | Globalize our input array.
// +--

if (!(empty($input))) {

     foreach ($input as $key => $value) {$this->globals($key,$value);}

} // End of if statement.

// +--
// | Set error handling up to output errors to the browser.  We handle
// | all errors except for E_NOTICE errors.
// +--

ini_set('display_errors','1');

error_reporting(E_ALL ^ E_NOTICE);

set_error_handler(array(&$this,'error_display'));

// +--
// | Determine the directory from where we're running this program.
// +--

$path = $this->globals('core.main_path_force');

if ((!(empty($path))) && (@file_exists($path))) {

     $path = $this->globals('core.main_path_force');

} elseif (@file_exists(dirname(__FILE__))) {

     $path = dirname(__FILE__);

} elseif (@file_exists(getcwd())) {

     $path = getcwd();

} elseif (@file_exists(dirname($_SERVER['PATH_TRANSLATED']))) {

     $path = dirname($_SERVER['PATH_TRANSLATED']);

} elseif (@file_exists(dirname($_SERVER['SCRIPT_FILENAME']))) {

     $path = dirname($_SERVER['SCRIPT_FILENAME']);

} else {

     $errstr = "

     <p>This script could not determine the directory from which it is 
     being executed.  You need to edit the scripts 'index.php', 'admin.php' 
     and 'installer.php' and enter a value for the \$main_path_force 
     variable at the top of those scripts. Follow the instructions in each of 
     those scripts for more information.</p>

     <p>If you have already edited the \$main_path_force variable and are 
     seeing this message again, the value you used for that variable 
     appears to be incorrect.  Please try again.</p>

     ";

     trigger_error($errstr,E_USER_ERROR);

} // End of if statement.

// +--
// | Format our working directory we've just determined and globalize it.
// +--

$path = $this->paths_convert($path);

$this->globals('core.main_path_force',$path);

// +--
// | Now we run our installer class.
// +--

$coreinstaller = new COREinstaller();
$coreinstaller = $coreinstaller->exec();

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: globals                                                |
// +------------------------------------------------------------------+

function globals ($name = '',$value = null,$default = null) {

// +--
// | This function maintains a global array of global variables for
// | use within the program.  Global variables can be set, changed and
// | obtained from this function.
// +--

global $xglobal_cache;

// +--
// | If the request contained a default identifier (passed as a true
// | value), we set a default value if the global doesn't exist.
// +--

if ((!(empty($name))) && (isset($value)) && (isset($default)) && (!(isset($xglobal_cache[$name])))) {

     $xglobal_cache[$name] = $value;

     return $value;

} // End of if statement.

// +--
// | Set requests have both a name and value passed
// | to this function.
// +--

if ((!(empty($name))) && (isset($value)) && (!(isset($default)))) {

     $xglobal_cache[$name] = $value;

     return $value;

} // End of if statement.

// +--
// | Get requests have only a global variable name
// | passed to this function.
// +--

if ((!(empty($name))) && (isset($xglobal_cache[$name]))) {

     return $xglobal_cache[$name];

} // End of if statement.

// +--
// | All other requests result in a null return value.
// +--

return null;

} // End of function.

// +------------------------------------------------------------------+
// | Function: paths_convert                                          |
// +------------------------------------------------------------------+

function paths_convert ($string) {

// +--
// | This function converts filesystem paths to unix-style and strips
// | any trailing slashes.
// +--

while (preg_match('/\\\\/',$string)) {$string = preg_replace('/\\\\/','/',$string);}

while (preg_match('/\/\//',$string)) {$string = preg_replace('/\/\//','/',$string);}

$string = preg_replace('/\/$/','',$string);

return $string;

} // End of function.

// +------------------------------------------------------------------+
// | Function: paths_strip                                            |
// +------------------------------------------------------------------+

function paths_strip ($string) {

// +--
// | This function strips full server paths from a given string for
// | security purposes.
// +--

$pathpub   = $this->globals('core.path_public');
$pathpriv  = $this->globals('core.path_private');
$pathforce = $this->globals('core.main_path_force');

$string = str_replace('\\','/',$string);

if (!(empty($pathforce))) {

     $find   = preg_quote($pathforce . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.
 
if (!(empty($pathpub))) {

     $find   = preg_quote($pathpub . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.

if (!(empty($pathpriv))) {

     $find   = preg_quote($pathpriv . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.

return $string;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_display                                          |
// +------------------------------------------------------------------+

function error_display ($errno = '',$errstr = '',$errfile = '',$errline = '') {

// +--
// | This function is called via PHP when an error is encountered.
// | Scripts pass errors through this function via PHP's trigger_error
// | function using:
// |
// | trigger_error('some_error_message',E_USER_ERROR);
// | 
// | PHP also passes errors through this function without script
// | intervention.
// +--

// +--
// | If we've hit this function with a suppressed error or an E_STRICT
// | or E_NOTICE error, we return.
// +--

if ((error_reporting() == 0) || ($errno == E_NOTICE) || ($errno == E_STRICT)) {

     return 1;

} // End of if statement.

// +--
// | If we are currently buffering output, destroy the buffer
// | and reset buffer status.
// +--

if ($this->globals('installer.buffer_status')) {

     @ob_end_clean();

     $this->globals('installer.buffer_status',0);

} // End of if statement.

// +--
// | Modify our $errfile if it is non-blank.  We want to remove
// | full paths from error messages to increase security.
// +--

if ($errfile) {$errfile = $this->paths_strip($errfile);}

// +--
// | Modify our $errstr if it is non-blank.  We want to add <p>
// | tags if they're not there.
// +--

if (($errstr) && (!(preg_match('/<p>/',$errstr)))) {

     $errstr = '<p>' . $errstr . '</p>';

} // End of if statement.

// +--
// | Print output header.
// +--

print $this->error_div_header();

// +--
// | Print output content.
// +--

if ($errstr) {print $this->error_div_content($errstr);}

// +--
// | Print output info.
// +--

if ($errno && $errline && $errfile) {print $this->error_div_info($errno,$errline,$errfile);}

// +--
// | Print output footer.
// +--

print $this->error_div_footer();

// +--
// | This was a fatal error so we exit.
// +--

exit();

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_header                                       |
// +------------------------------------------------------------------+

function error_div_header () {

// +--
// | This function prints the error header.
// +--

$xhtml = <<<ENDOFTEXT

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" /> 

<style type="text/css" media="all">

body {
     font-family: Verdana, Tahoma, Arial, sans-serif;
     font-size: 12px;
     color: #333333;
     font-weight: normal;
     text-align: left;
     background-color: #F5F5F5;
     margin: 20px;
     }

a {
     color: #30569D;
     text-decoration: none;
     font-weight: normal;
     }

a:hover {
     text-decoration: underline;
     }

.strong {
     font-weight: bold;
     }

#content {
     color: #333333;
     background-color: #FFFFFF;
     border: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: 0px auto 0px auto;
     -moz-border-radius: 8px 8px 0px 0px;
     -webkit-border-radius: 8px 8px 0px 0px;
     border-radius: 8px 8px 0px 0px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     line-height: 1.5em;
     }

#info {
     color: #333333;
     background-color: #FFFFFF;
     border-left: 1px solid #333333;
     border-right: 1px solid #333333;
     border-bottom: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: 0px auto 0px auto;
     -moz-border-radius: 0px 0px 8px 8px;
     -webkit-border-radius: 0px 0px 8px 8px;
     border-radius: 0px 0px 8px 8px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     font-size: 11px;
     }

#pgtitle {
     color: #4E70AE;
     padding: 0px;
     margin: 0px 0px 10px 0px;
     font-weight: bold;
     font-size: 18px;
     }

</style>

<title>Script Execution Error</title>

</head>

<body>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_content                                      |
// +------------------------------------------------------------------+

function error_div_content ($errstr = '') {

// +--
// | This function prints the error contet.
// +--

$xhtml = <<<ENDOFTEXT

<div id="content">

<div id="pgtitle">Script Execution Error</div>

{$errstr}

</div>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_info                                         |
// +------------------------------------------------------------------+

function error_div_info ($errno = '',$errline = '',$errfile = '') {

// +--
// | This function prints the error info.
// +--

$xhtml = <<<ENDOFTEXT

<div id="info">File: {$errfile} Line: {$errline} Error Number: {$errno}</div>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_footer                                       |
// +------------------------------------------------------------------+

function error_div_footer () {

// +--
// | This function prints the error footer.
// +--

$xhtml = <<<ENDOFTEXT

</body>

</html>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | End of Class                                                     |
// +------------------------------------------------------------------+

} // End of class.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Installer Core Class                                             |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Class Definition: COREInstaller                                  |
// +------------------------------------------------------------------+

class COREinstaller extends COREmain {

// +--
// | This class handles installation of the program when a core
// | core is not present.  This installer is to be considered
// | standalone software and it's architecture and methodology 
// | are not indicative of the system component.  Do not use 
// | code in this COREinstaller class as a basis for core 
// | or component code.
// +--

// +------------------------------------------------------------------+
// | Class Variables                                                  |
// +------------------------------------------------------------------+

var $class   = 'COREinstaller';
var $version = '8.0.0';
var $cerror;

// +------------------------------------------------------------------+
// | Constructor Function                                             |
// +------------------------------------------------------------------+

function COREinstaller () {

// +--
// | This is the constructor function.  This function starts up the
// | class.  Any pre-load variable assignments go here.
// +--

// +--
// | Return object.
// +--

return $this;

} // End of function.

// +------------------------------------------------------------------+
// | Function: exec                                                   |
// +------------------------------------------------------------------+

function exec () {

// +--
// | This function runs the internals of the installer program.
// +--

// +--
// | Define some important variables.
// +--

$this->globals('installer.eol',"\r\n");
$this->globals('installer.numsteps','13');

// +--
// | Start buffering output.
// +--

if (!($this->globals('installer.buffer_status'))) {

     @ob_start();

     $this->globals('installer.buffer_status',1);

} // End of if statement.

// +--
// | Defeat register globals.
// +--

$this->defeat_register_globals();

// +--
// | Defeat magic quotes.
// +--

$this->defeat_magic_quotes();

// +--
// | Determine the operating system.
// +--

$this->get_os();

// +--
// | Check our PHP and filesystem environment.
// +--

$result = $this->check_php();

if ($this->IsError($result)) {

     trigger_error($result->GetMessage(),E_USER_ERROR);

} // End of if statement.

// +--
// | Include our config.php in the private directory.  Append the 
// | $config array in that file to our class $config array.
// +--

if (@file_exists($this->globals('core.main_path_force') . '/config.php')) {

     include_once($this->globals('core.main_path_force') . '/config.php');

     foreach ($config as $key => $value) {$this->globals($key,$value);}

     unset($config);

} // End of if statement.

// +--
// | Include our config.php in the private directory.  Append the 
// | $config array in that file to our class $config array.
// +--

$pathpriv = $this->globals('core.path_private');

if (!(empty($pathpriv))) {

     if (@file_exists($pathpriv . '/config.php')) {

          include_once($pathpriv . '/config.php');

          foreach ($config as $key => $value) {$this->globals($key,$value);}

          unset($config);

     } // End of if statement.

} // End of if statement.

// +--
// | Load all of our form data.
// +--

$this->load_formdata();

// +--
// | Start processing.
// +--

$result = $this->exec_do();

if ($this->IsError($result)) {

     trigger_error($result->GetMessage(),E_USER_ERROR);

} // End of if statement.

// +--
// | Finish buffering output.
// +--

if ($this->globals('installer.buffer_status')) {

     $buffered_output = @ob_get_contents();

     @ob_end_clean();

     $this->globals('installer.buffered_output',$buffered_output);

     $this->globals('installer.buffer_status',0);

} // End of if statement.

// +--
// | Print the display.
// +--

$this->disp();

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: exec_do                                                |
// +------------------------------------------------------------------+

function exec_do () {

// +--
// | This function processes the main logic of the installer.
// +--

// +--
// | Define the step we're on.
// +--

$step = $this->globals('installer_cgi.step');

if (!($step)) {$step = 'Intro';}

// +--
// | Get password info from form input and present the right 
// | interface.
// +--

$password = $this->globals('core.password');

if (!(empty($password))) {

     $config_password = $this->globals('installer_cgi.config_password');

     if (!($config_password)) {

          $step = 'Password';

     } elseif (md5($config_password) != $password) {

          $message = "The password you entered is incorrect.  Please try again.";
          $step    = 'Password';

          $this->disp_message($message,'ERROR');

     } // End of if statement.

} elseif ($step != 'IntroP') {

     $step = 'Intro';

} // End of if statement.

// +--
// | Check the status of our license agreement acceptance.
// +--

$license_agree = $this->globals('installer_cgi.license_agree');

if (empty($license_agree)) {

          if ($step != 'Password' && $step != 'Intro') {

          $message = "You did not agree to the terms and conditions in the EULA.  
                      You must agree to these terms and conditions to continue.";

          if ($step == 'IntroP') {$step = 'Intro';}

          else {$step = 'Password';}

          $this->disp_message($message,'ERROR');

     } // End of if statement.

} // End of if statement.

// +--
// | Load PEAR if we can.
// +--

$this->load_pear();

// +--
// | Execute our step.
// +--

$result = $this->exec_step($step);

if ($this->IsError($result)) {return $result;}

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: exec_step                                              |
// +------------------------------------------------------------------+

function exec_step ($step = 'Default') {

// +--
// | This function executes installer steps.
// +--

// +--
// | Use the step to figure out what we need to be doing.  If the
// | step is blank, we default to step I.  A list of the steps is
// | below:
// |
// | Step Number  Action          
// | -----------  -------------------
// | Default      Default Invalid Info Screen
// | Password     Password Collection
// | Intro        Intro / Password Selection
// | IntroP       Intro / Password Selection - Process
// | ServPath     Server Paths & Script Names
// | ServPathP    Server Paths & Script Names - Process
// | CurlConf     Curl Configuration
// | CurlConfP    Curl Configuration - Process
// | URL          URLs Info
// | URLP         URLs Info - Process
// | Cook         Cookie Info
// | CookP        Cookie Info - Process
// | RegCrypt     Registration Info & Encryption Key
// | RegCryptP    Registration Info & Encryption Key - Process
// | PEARins      PEAR Install Intro
// | PEARinsP     PEAR Install - Process
// | COREins      Core Install Intro
// | COREinsP     Core Install - Process
// | MailPick     Mail Configuration (Selection)
// | MailPickP    Mail Configuration (Selection) - Process
// | MailConf     Mail Configuration (Settings)
// | MailConfP    Mail Configuration (Settings) - Process
// | DBPick       Database Configuration (Selection)
// | DBPickP      Database Configuration (Selection) - Process
// | DBConf       Database Configuration (Settings)
// | DBConfP      Database Configuration (Settings) - Process
// | InsApps      Component & Module Installation
// | InsAppsP     Component & Module Installation - Process
// | COREsetup    Database Initialization
// | COREsetupP   Database Initialization - Process
// | Final        Final Confirm Display
// +--

switch ($step) {

     case "Password":
          $result = $this->step_Password();
          break;

     case "Intro":
          $result = $this->step_Intro();
          break;

     case "IntroP":
          $result = $this->step_IntroP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_Intro();
          }
          break;

     case "ServPath":
          $result = $this->step_ServPath();
          break;

     case "ServPathP":
          $result = $this->step_ServPathP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_ServPath();
          }
          break;

     case "CurlConf":
          $result = $this->step_CurlConf();
          break;

     case "CurlConfP":
          $result = $this->step_CurlConfP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_CurlConf();
          }
          break;

     case "URL":
          $result = $this->step_URL();
          break;

     case "URLP":
          $result = $this->step_URLP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_URL();
          }
          break;

     case "Cook":
          $result = $this->step_Cook();
          break;

     case "CookP":
          $result = $this->step_CookP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_Cook();
          }
          break;

     case "RegCrypt":
          $result = $this->step_RegCrypt();
          break;

     case "RegCryptP":
          $result = $this->step_RegCryptP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_RegCrypt();
          }
          break;

     case "PEARins":
          $result = $this->step_PEARins();
          break;

     case "PEARinsP":
          $result = $this->step_PEARinsP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_PEARins();
          }
          break;

     case "COREins":
          $result = $this->step_COREins();
          break;

     case "COREinsP":
          $result = $this->step_COREinsP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_COREins();
          }
          break;

     case "MailPick":
          $result = $this->step_MailPick();
          break;

     case "MailPickP":
          $result = $this->step_MailPickP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_MailPick();
          }
          break;

     case "MailConf":
          $result = $this->step_MailConf();
          break;

     case "MailConfP":
          $result = $this->step_MailConfP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_MailConf();
          }
          break;

     case "DBPick":
          $result = $this->step_DBPick();
          break;

     case "DBPickP":
          $result = $this->step_DBPickP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_DBPick();
          }
          break;

     case "DBConf":
          $result = $this->step_DBConf();
          break;

     case "DBConfP":
          $result = $this->step_DBConfP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_DBPick();
          }
          break;

     case "InsApps":
          $result = $this->step_InsApps();
          break;

     case "InsAppsP":
          $result = $this->step_InsAppsP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_InsApps();
          }
          break;

     case "COREsetup":
          $result = $this->step_COREsetup();
          break;

     case "COREsetupP":
          $result = $this->step_COREsetupP();
          if ($this->IsError($result)) {
               $this->disp_message($result->GetMessage(),'ERROR');
               return $this->step_COREsetup();
          }
          break;

     case "Final":
          $result = $this->step_Final();
          break;

     default:
          $result = $this->step_Default();
          break;

} // End of switch statement.

// +--
// | Return the result.
// +--

return $result;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Installer Steps                                                  |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: step_Default                                           |
// +------------------------------------------------------------------+

function step_Default () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','0');
$this->globals('installer.steptext','Software Installer');

// +--
// | Default Invalid Info Screen
// | 
// | This function prints a page indicating the installer was hit 
// | with invalid information and prints a valid installer link.
// +--

$insname = $this->globals('installer.script_name');

print <<<ENDOFTEXT

<p>You have accessed this installer script using invalid data.  In 
order to use the installer script, please follow the link below:</p>

<p><a href="{$insname}" title="Installer">Click here to run the installer script.</a></p>

ENDOFTEXT;

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_Password                                          |
// +------------------------------------------------------------------+

function step_Password () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','0');
$this->globals('installer.steptext','Software Installer');

// +--
// | Password Collection
// | 
// | This function prints a form to be completed by the user to 
// | submit a password for this installer script.  This screen is 
// | accessed when a password already exists for the installer.
// +--

// +--
// | Define the form.
// +--

$header = <<<ENDOFTEXT

<p>This installer script is currently protected by a password that was 
set up during the initial installation of this program.  Enter the password 
below then click the 'Continue' button at the bottom of this page to 
configure this installation using this installer script.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_password';
$fields[0]['name']     = 'Installer Password';
$fields[0]['type']     = 'PASSWORD';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Enter the password below that you selected to permit controlled 
access to this installer.  If you do not remember the installer password 
you selected during the initial installation of this program, edit the 
'config.php' file in this directory.  Delete the MD5 hash assigned to the 
'core.password' variable to create a new password.</p>

ENDOFTEXT;

$fields[1]['id']       = 'license_agree';
$fields[1]['name']     = 'License Agreement';
$fields[1]['type']     = 'CHECKBOX';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('1' => 'I agree to the terms and conditions in the EULA.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Installation and use of this program requires you read and accept the 
End User License Agreement (EULA) distributed with this software.  Follow 
the link below to review the EULA.  The EULA is distributed in Adobe PDF 
format.  You will need Acrobat Reader, which is freely available from Adobe, 
to review the EULA.</p>

<p><a href="license.pdf" rel="external" title="License">Click here to review the EULA.</a></p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'ServPath'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_Intro                                             |
// +------------------------------------------------------------------+

function step_Intro () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','0');
$this->globals('installer.steptext','Software Installer');

// +--
// | Define the form.
// +--

$numsteps = $this->globals('installer.numsteps');

$header = <<<ENDOFTEXT

<p>This installer script will guide you through the process of 
installing this software on your webserver.  The install process consists 
of {$numsteps} steps.  Once this installer script has completed, you will 
be presented with a confirmation page and instructions on how to access the 
frontend and management interfaces of the core.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_password';
$fields[0]['name']     = 'Installer Password';
$fields[0]['type']     = 'PASSWORD';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>This password is used to permit controlled access to the installer 
script for changes to configuration items.  Each time you run the 
installer to change configuration values, you will need to remember 
and enter this password.</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_password_match';
$fields[1]['name']     = 'Installer Password Confirmation';
$fields[1]['type']     = 'PASSWORD';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Confirm your password selection by typing it again in the box 
below.</p>

ENDOFTEXT;

$fields[2]['id']       = 'license_agree';
$fields[2]['name']     = 'License Agreement';
$fields[2]['type']     = 'CHECKBOX';
$fields[2]['required'] = '1';
$fields[2]['values']   = array('1' => 'I agree to the terms and conditions in the EULA.');

$fields[2]['desc']     = <<<ENDOFTEXT

<p>Installation and use of this program requires you read and accept the 
End User License Agreement (EULA) distributed with this software.  Follow 
the link below to review the EULA.  The EULA is distributed in Adobe PDF 
format.  You will need Acrobat Reader, which is freely available from Adobe, 
to review the EULA.</p>

<p><a href="license.pdf" rel="external" title="License">Click here to review the EULA.</a></p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'IntroP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_IntroP                                            |
// +------------------------------------------------------------------+

function step_IntroP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Intro / Password Selection - Process
// | 
// | This function does the following:
// |
// | 1. Verifies the data submitted.
// | 2. Writes out password data to config.php if valid.
// +--

$config_password       = $this->globals('installer_cgi.config_password');
$config_password_match = $this->globals('installer_cgi.config_password_match');

if ((!($config_password)) || (!($config_password_match))) {

     $message = "You did not enter a password and a confirmation of 
                 that password before clicking the 'Continue' button.  
                 Please try again.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

if ($config_password != $config_password_match) {

     $message = "The passwords you entered do not match.  Please 
                 try again.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Create our primary config file in the public directory if 
// | we're good so far. 
// +--

$dest = $this->globals('core.main_path_force') . '/config.php';

if (!(@file_exists($dest))) {

     $file_contents = $this->public_config();

     $result = $this->file_write(array('name' => $dest,
                                       'data' => $file_contents));

     if ($this->IsError($result)) {

          $message  = "The installer script could not create a public configuration 
                       file.  This may be a permissions issue or there may not be 
                       enough disk space available to create the file.  Error
                       Information: " .  $result->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Now write our password out to the public config file.
// +--

$result = $this->writeconfig('core.password',md5($config_password),'PUBLIC');
if ($this->IsError($result)) {return $result;}

// +--
// | We'll attempt to copy our password over to the private
// | config file.  This config file may not exist yet, so
// | we don't check for errrors here.
// +--

$this->writeconfig('core.password_copy',md5($config_password),'PRIVATE');

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The password you entered has been saved.  You 
            can now continue through the installation process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_ServPath();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_ServPath                                          |
// +------------------------------------------------------------------+

function step_ServPath () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','1');
$this->globals('installer.steptext','Server Paths &#038; Script Names');

// +--
// | Server Paths & Script Names
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of this software on 
your webserver requires that two directory paths be used: one public 
path and one private path.  Information on those directory paths and how 
to identify and/or create them is below.</p>

<p>In addition to choosing the directories where this software is 
installed, you also have the ability to change the names of the scripts 
which control the public (frontend) and private (backend) functions of the 
software.  If you choose to rename the index.php and/or admin.php scripts, 
update the script name fields below.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_path_public';
$fields[0]['name']     = 'Public Directory Path';
$fields[0]['type']     = 'TEXT-LONG';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>The public directory path is the absolute (full) webserver filesystem path 
to the directory from which this installer script is running.  This directory 
must be web-accessible.</p>

<p>This path should be entered without a trailing slash and needs to have 
permissions set to a level where it is writable via the webserver process. 
To set the permissions for this directory, adjust permissions as follows:</p>

<p>For Unix/Linux servers, use your FTP client or SSH shell to 'chmod' the 
directory to a writable level.  This level is typically 'chmod 777'.</p>

<p>For Windows servers, contact your server administrator and request that 
they set permissions on the directory above to 'Full Control' for the 
process that PHP runs under.  This needs to be done via Windows Explorer, 
not the IIS Control Panel.</p>

<p>Example: /home/username/www/core or C:/Inetpub/wwwroot/core</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_path_private';
$fields[1]['name']     = 'Private Directory Path';
$fields[1]['type']     = 'TEXT-LONG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>The private directory path is the absolute (full) webserver filesystem path 
to a directory where sensitive information will be stored such as the codebase 
and source files.  This directory must either be in a non-web-accessible 
location, or in a password protected web-accessible location.</p>

<p>This path should be entered without a trailing slash and needs to have 
permissions set to a level where it is writable via the webserver process. 
To set the permissions for this directory, adjust permissions as follows:</p>

<p>For Unix/Linux servers, use your FTP client or SSH shell to 'chmod' the 
directory to a writable level.  This level is typically 'chmod 777'.</p>

<p>For Windows servers, contact your server administrator and request that 
they set permissions on the directory above to 'Full Control' for the process 
that PHP runs under.  This needs to be done via Windows Explorer, not the 
IIS Control Panel.</p>

<p>Example: /home/username/core or C:/Inetpub/db/core</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_script_frontend';
$fields[2]['name']     = 'Public Script Name';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>The public script name is the name of the script used by the public to 
access this software via the Internet.  The default public script name is 
'index.php'.  If you choose to change the name of the public script, do so via 
your FTP client or SSH shell then input the exact filename you selected below.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_script_backend';
$fields[3]['name']     = 'Management Interface Script Name';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '1';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>The Management Interface script name is the name of the script used by 
administrators to access the backend functions of this software via the Internet.  
The default management interface script name is 'admin.php'.  If you choose to change 
the name of the management interface script, do so via your FTP client or SSH shell then 
input the exact filename you selected below.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'ServPathP'));


// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_ServPathP                                         |
// +------------------------------------------------------------------+

function step_ServPathP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Server Paths & Script Names - Process
// | 
// | This function does the following:
// |
// | 1. Verifies the data submitted.
// | 2. Verifies existance of the paths, scripts & permissions.
// | 3. Defines confirm/error messages to be printed to the screen.
// | 4. Writes out reg data to config.php if valid.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_path_public'     => 1,
                                  'config_path_private'    => 1,
                                  'config_script_frontend' => 1,
                                  'config_script_backend'  => 1));

if ($this->IsError($fd)) {return $fd;}

// +--
// | Strip off any trailing slashes and convert to Unix style
// | paths/filenames.
// +--

$config_path_public     = $this->paths_convert($fd['config_path_public']);
$config_path_private    = $this->paths_convert($fd['config_path_private']);

$config_script_frontend = $fd['config_script_frontend'];
$config_script_backend  = $fd['config_script_backend'];

// +--
// | Check the formdata submission items and append error messages as
// | we go.
// +--

$errorcount = 0;

$errmsg     = "The following errors were encountered while attempting 
               to process your request: ";

// +--
// | Check the public path.
// +--

if (!(@file_exists($config_path_public))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The webserver filesystem path 
                 you entered for the Public Directory Path does not exist.";

} // End of if statement.

if (!(is_writable($config_path_public))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The webserver filesystem path you 
                 entered for the Public Directory Path is not writable via the 
                 webserver process.";

} // End of if statement.

// +--
// | Check the private path.
// +--

if (!(@file_exists($config_path_private))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The webserver filesystem path 
                 you entered for the Private Directory Path does not exist.";

} // End of if statement.

if (!(is_writable($config_path_private))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The webserver filesystem path you 
                 entered for the Private Directory Path is not writable via the 
                 webserver process.";

} // End of if statement.

// +--
// | Return errors if we have any at this point.
// +--

if ($errorcount) {

     $result = $this->RaiseError($errmsg);

     return $result;

} // End of if statement.

// +--
// | Check frontend script name.
// +--

if (!(@file_exists($this->globals('core.main_path_force') . '/' . $config_script_frontend))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The filename you specified for the 
                 Public Script Name could not be located.";

} // End of if statement.

// +--
// | Check backend script name.
// +--

if (!(@file_exists($this->globals('core.main_path_force') . '/' . $config_script_backend))) {

     $errorcount++;

     $errmsg .= " {$errorcount}. The filename you specified for the 
                 Management Interface Script Name could not be located.";

} // End of if statement.

// +--
// | Return errors if we have any at this point.
// +--

if ($errorcount) {

     $result = $this->RaiseError($errmsg);

     return $result;

} // End of if statement.

// +--
// | Set up our install directories if we have no errors yet.
// +--

$this->globals('core.path_public',$config_path_public);
$this->globals('core.path_private',$config_path_private);

$result = $this->setupdirs();

if ($this->IsError($result)) {return $result;}

// +--
// | Create our second config file in the private directory if 
// | we're good so far. 
// +--

$dest = $config_path_private . '/config.php';

if (!(@file_exists($dest))) {

     $file_contents = $this->private_config();

     $result = $this->file_write(array('name' => $dest,
                                       'data' => $file_contents));

     if ($this->IsError($result)) {

          $message  = "The installer script could not create a private configuration 
                       file.  This may be a permissions issue or there may not be 
                       enough disk space available to create the file.  Error
                       Information: " .  $result->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.path_public',$config_path_public,'PUBLIC');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.path_private',$config_path_private,'PUBLIC');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.script_frontend',$config_script_frontend,'PUBLIC');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.script_backend',$config_script_backend,'PUBLIC');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you. The directory paths and script names 
            you submitted have been saved.  You can now continue through 
            the installation process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_CurlConf();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_CurlConf                                          |
// +------------------------------------------------------------------+

function step_CurlConf () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','2');
$this->globals('installer.steptext','cURL Configuration');

// +--
// | cURL Configuration
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of this software on 
your webserver requires that cURL be installed and loaded as an 
extension to PHP.</p>

<p>At startup, this software checks to ensure cURL is loaded as an extension 
to PHP and dynamically loads the extension if needed.  This software 
has already verified that cURL is loaded as an extension to PHP for this 
installation.  You do not need to configure a server path for the cURL 
executable for this software as you do with many other programs.</p>

<p>All of the fields below are optional.  These fields aid in configuring 
cURL to use a proxy server if one is needed on your server.  In most cases 
a proxy configuration does not need to be entered.</p>

If you are unsure of whether your server administrator requires a proxy 
for cURL requests, first try to continue to the next step without entering any 
proxy configuration values.  If a connection error is presented, contact your 
server administrator and ask them if a proxy is required to use cURL 
and if so, obtain the information needed to complete the fields below.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_curl_proxyurl';
$fields[0]['name']     = 'cURL Proxy URL';
$fields[0]['type']     = 'TEXT-REG';
$fields[0]['required'] = '0';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>If your server requires the use of a proxy server for connections to other Internet 
sites via cURL, your server administrator should have provided you with a proxy URL.  This 
URL needs to be entered with a leading 'http://' or 'https://'.</p>

<p>If your host provided you with a full URL including a port designation, leave the 
port designation in the URL.</p>

<p>Only enter a cURL Proxy URL if you are sure your host requires the use of a 
proxy server with cURL.</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_curl_proxyuser';
$fields[1]['name']     = 'cURL Proxy Username';
$fields[1]['type']     = 'TEXT-REG';
$fields[1]['required'] = '0';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>If your server requires the use of a proxy server for connections to other Internet 
sites via cURL, your server may also require the use of a username for the proxy server.</p>

<p>Only enter a cURL Proxy Username if you are sure your host requires the use of a 
username with the proxy server used for cURL.</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_curl_proxypass';
$fields[2]['name']     = 'cURL Proxy Password';
$fields[2]['type']     = 'PASSWORD';
$fields[2]['required'] = '0';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>If your server requires the use of a proxy server for connections to other Internet 
sites via cURL, your server may also require the use of a password for the proxy server.</p>

<p>Only enter a cURL Proxy Password if you are sure your host requires the use of a 
password with the proxy server used for cURL.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_curl_proxyhttp';
$fields[3]['name']     = 'cURL Proxy Over HTTP';
$fields[3]['type']     = 'CHECKBOX';
$fields[3]['required'] = '0';
$fields[3]['values']   = array(1 => 'Proxy required for HTTP connections.');

$fields[3]['desc']     = <<<ENDOFTEXT

<p>If your server requires the use of a proxy server for connections to other Internet 
sites via cURL, your server may only require the use of the proxy server for HTTP 
connections.</p>

<p>Check the box below if your server requires the use of a proxy server for HTTP connections.</p>

ENDOFTEXT;

$fields[4]['id']       = 'config_curl_proxyhttps';
$fields[4]['name']     = 'cURL Proxy Over HTTPS';
$fields[4]['type']     = 'CHECKBOX';
$fields[4]['required'] = '0';
$fields[4]['values']   = array(1 => 'Proxy required for HTTPS connections.');

$fields[4]['desc']     = <<<ENDOFTEXT

<p>If your server requires the use of a proxy server for connections to other Internet 
sites via cURL, your server may only require the use of the proxy server for HTTPS 
connections.</p>

<p>Check the box below if your server requires the use of a proxy server for HTTPS connections.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'CurlConfP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_CurlConfP                                         |
// +------------------------------------------------------------------+

function step_CurlConfP () {

// +--
// | Installer Function Step.
// +--

// +--
// | cURL Configuration - Process
// |
// | 1. Verifies the data submitted.
// | 2. Validates the curl connection.
// | 3. Defines confirm/error messages to be printed to the screen.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_curl_proxyurl'   => 0,
                                  'config_curl_proxyuser'  => 0,
                                  'config_curl_proxypass'  => 0,
                                  'config_curl_proxyhttp'  => 0,
                                  'config_curl_proxyhttps' => 0));

if ($this->IsError($fd)) {return $fd;}

$config_curl_proxyurl   = $fd['config_curl_proxyurl'];
$config_curl_proxyuser  = $fd['config_curl_proxyuser'];
$config_curl_proxypass  = $fd['config_curl_proxypass'];
$config_curl_proxyhttp  = $fd['config_curl_proxyhttp'][0];
$config_curl_proxyhttps = $fd['config_curl_proxyhttps'][0];

// +--
// | Handle a few specific requirements.
// +--

$error = 0;

if (($config_curl_proxyuser) && (empty($config_curl_proxypass))) {$error = 1;}
if ((empty($config_curl_proxyuser)) && ($config_curl_proxypass)) {$error = 1;}
if ($error) {

     $message = "If you would like to configure the cURL connection to use 
                 authentication, you must enter both a username and password.  
                 Either remove delete both fields or complete both fields to 
                 continue.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Check the formdata submission items and append error messages as
// | we go.
// +--

$errorcount = 0;

$errmsg     = "The following errors were encountered while attempting 
               to process your request: ";

// +--
// | Globalize our CGI vars for our curl_exec function.
// +--

$this->globals('core.curl_proxyurl',$config_curl_proxyurl);
$this->globals('core.curl_proxyuser',$config_curl_proxyuser);
$this->globals('core.curl_proxypass',$config_curl_proxypass);
$this->globals('core.curl_proxyhttp',$config_curl_proxyhttp);
$this->globals('core.curl_proxyhttps',$config_curl_proxyhttps);

// +--
// | Run TEST 1: HTTP
// +--

$result = $this->exec_curl(array('url'  => 'http://central.kryptronic.com/public/curl/test.php',
                                 'type' => 'GET',
                                 'mode' => 'HTTP',
                                 'data' => ''));

if ($this->IsError($result)) {

     $errorcount++;

     $errmsg .= "{$errorcount}. An error was encountered while running the 
                 HTTP cURL test.  Error Information: " .  $result->GetMessage();

} // End of if statement.

// +--
// | Run TEST 2: HTTPS
// +--

$result = $this->exec_curl(array('url'  => 'https://central.kryptronic.com/public/curl/test.php',
                                 'type' => 'GET',
                                 'mode' => 'HTTPS',
                                 'data' => ''));

if ($this->IsError($result)) {

     $errorcount++;

     $errmsg .= "{$errorcount}. An error was encountered while running the 
                 HTTPS cURL test.  Error Information: " .  $result->GetMessage();

} // End of if statement.

// +--
// | Return errors if we have any at this point.
// +--

if ($errorcount) {

     $result = $this->RaiseError($errmsg);

     return $result;

} // End of if statement.

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.curl_proxyurl',$config_curl_proxyurl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.curl_proxyuser',$config_curl_proxyuser,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.curl_proxypass',$config_curl_proxypass,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.curl_proxyhttp',$config_curl_proxyhttp,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.curl_proxyhttps',$config_curl_proxyhttps,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The cURL configuration information you submitted 
            has been saved.  You can now continue through the installation 
            process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_URL();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_URL                                               |
// +------------------------------------------------------------------+

function step_URL () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','3');
$this->globals('installer.steptext','URL Info');

// +--
// | URL Info
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of this software on 
your webserver requires that URLs be designated for both secure (SSL) and
non-secure (non-SSL) requests.  This software supports running under both 
shared and dedicated SSL certificates.  If you do not wish to set up a secure 
URL at this time, or do not plan on using SSL services, simply enter the same 
URL (a non-SSL URL) in both URL fields below.</p>

<p>If you are installing this software on a webserver account for which 
a domain name has not yet been assigned or propagated, use temporary URLs 
which contain your server IP address.  Once your domain name is active and 
assigned to this webserver account, execute this installer script and 
update your URLs.</p> 

<p>In addition to designating the URLs this software runs under, 
you must also designate the SSL port.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_url_nonssl';
$fields[0]['name']     = 'Non-Secure (Non-SSL) URL';
$fields[0]['type']     = 'TEXT-LONG';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>The non-secure URL entered below will be the main URL used by this 
software for all requests not requiring SSL encryption for transmission 
of sensitive data.</p>

<p>This URL should be prefixed with 'http://' and should be entered without a 
trailing slash.  This URL should point to the same 'Public Directory Path' 
you set up previously during this installation.</p>

<p>Example: http://www.yourdomain.com/core</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_url_ssl';
$fields[1]['name']     = 'Secure (SSL) URL';
$fields[1]['type']     = 'TEXT-LONG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>The secure URL entered below will be the main URL used by this software 
for all requests requiring SSL encryption for transmission of sensitive data.</p>

<p>This URL should be prefixed with 'https://' and should be entered without a 
trailing slash.  This URL should point to the same 'Public Directory Path' 
you set up previously during this installation or a secure directory that is 
symbolically linked to the 'Public Directory Path' you entered.</p>

<p>As noted above, if you do not wish to set up a secure URL at this time, or 
do not plan on using SSL services, simply enter the same URL here that you 
designated for the 'Non-Secure (Non-SSL) URL' above.</p>

<p>Example: https://secure.yourdomain.com/core</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_port_ssl';
$fields[2]['name']     = 'Secure (SSL) Port';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>The secure port entered below will control how media is linked to from 
the external display files used by this software.  The default port for 
nearly all servers is 443.  Use port 443 unless your webserver serves SSL 
content using a different port.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'URLP'));

// +--
// | Return true// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_URLP                                              |
// +------------------------------------------------------------------+

function step_URLP () {

// +--
// | Installer Function Step.
// +--

// +--
// | URL Info - Process
// | 
// | This function does the following:
// |
// | 1. Verifies the data submitted.
// | 2. Validates URL Info.
// | 3. Defines confirm/error messages to be printed to the screen.
// | 4. Writes out reg data to config.php if valid.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_url_nonssl' => 1,
                                  'config_url_ssl'    => 1,
                                  'config_port_ssl'   => 1));

if ($this->IsError($fd)) {return $fd;}

$config_url_nonssl = $fd['config_url_nonssl'];
$config_url_ssl    = $fd['config_url_ssl'];
$config_port_ssl   = $fd['config_port_ssl'];

// +--
// | Strip off any trailing slashes.
// +--

$config_url_nonssl    = preg_replace('/\/$/','',$config_url_nonssl);
$config_url_ssl       = preg_replace('/\/$/','',$config_url_ssl);

// +--
// | We don't do URL checks as some systems can't handle connecting
// | to URLs that reside on the same server.  This checking code is
// | left intact here but is disabled using the line below.
// +--

$check_urls = 0;

if ($check_urls) {

     // +--
     // | Check the formdata submission items and append error messages as
     // | we go.
     // +--

     $errorcount = 0;

     $errmsg     = "The following errors were encountered while attempting 
                    to process your request: ";

     // +--
     // | Run TEST 1: HTTP
     // +--

     $insname = $this->globals('installer.script_name');

     $result = $this->exec_curl(array('url'  => $config_url_nonssl . '/' . $insname,
                                      'type' => 'GET',
                                      'mode' => 'HTTP',
                                      'data' => ''));

     if ($this->IsError($result)) {

          $errorcount++;

          $errmsg .= "{$errorcount}. The Non-Secure (Non-SSL) URL you 
                      entered does not appear to exist on the Internet.  
                      Error Information: " .  $result->GetMessage();

     } elseif (!(preg_match('/CORE/',$result))) {

          $errorcount++;

          $errmsg .= "{$errorcount}. The Non-Secure (Non-SSL) URL you 
                      entered does not appear to exist on the Internet.";

     } // End of if statement.

     // +--
     // | Run TEST 2: HTTPS
     // +--

     $insname = $this->globals('installer.script_name');

     $result = $this->exec_curl(array('url'  => $config_url_ssl . '/' . $insname,
                                      'type' => 'GET',
                                      'mode' => 'HTTPS',
                                      'data' => ''));

     if ($this->IsError($result)) {

          $errorcount++;

          $errmsg .= "{$errorcount}. The Secure (SSL) URL you entered 
                      does not appear to exist on the Internet.  
                      Error Information: " .  $result->GetMessage();

     } elseif (!(preg_match('/CORE/',$result))) {

          $errorcount++;

          $errmsg .= "{$errorcount}. The Secure (SSL) URL you entered 
                      does not appear to exist on the Internet.";

     } // End of if statement.

     // +--
     // | Return errors if we have any at this point.
     // +--

     if ($errorcount) {

          $result = $this->RaiseError($errmsg);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.url_nonssl',$config_url_nonssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.url_ssl',$config_url_ssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.port_ssl',$config_port_ssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The URL configuration information you submitted 
            has been saved.  You can now continue through the installation 
            process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_Cook();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_Cook                                              |
// +------------------------------------------------------------------+

function step_Cook () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','4');
$this->globals('installer.steptext','Cookie Info');

// +--
// | Cookie Info
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of this software on 
your webserver requires that cookie domains and paths be designated for 
both secure (SSL) and non-secure (non-SSL) requests.  While this software 
does not require the use of cookies for its main functions, some core 
auxiliary functions or other components and/or modules may require 
cookies to function properly.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_cookie_domain_nonssl';
$fields[0]['name']     = 'Non-Secure (Non-SSL) Cookie Domain';
$fields[0]['type']     = 'TEXT-REG';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>The cookie domain entered below should correspond to the non-secure URL 
on which this installation will run.  If you are installing this software 
on a webserver account for which a domain name has not yet been assigned 
or propagated, you should still enter the final domain below.</p>

<p>Example: The cookie domain for the URL 'http://www.yourdomain.com/core' would be 
entered as '.yourdomain.com'.  Notice the domain name is preceded by a period 
and does not include anything after the TLD (.com).</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_cookie_path_nonssl';
$fields[1]['name']     = 'Non-Secure (Non-SSL) Cookie Path';
$fields[1]['type']     = 'TEXT-REG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>The cookie path entered below should correspond to the non-secure URL 
on which this installation will run.  This path is preceded by a slash, but 
should not include a trailing slash.  If you are configuring this software 
to interface with Joomla!, enter '/' for the cookie path.</p>

<p>Example: The cookie path for the URL 'http://www.yourdomain.com/core' would be 
entered as '/core'.  Notice the cookie path contains everything after the TLD (.com).</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_cookie_domain_ssl';
$fields[2]['name']     = 'Secure (SSL) Cookie Domain';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>The cookie domain entered below should correspond to the non-secure URL 
on which this installation will run.  If you are installing this software 
on a webserver account for which a domain name has not yet been assigned 
or propagated, you should still enter the final domain below.</p>

<p>Example: The cookie domain for the URL 'http://www.yourdomain.com/core' would be 
entered as '.yourdomain.com'.  Notice the domain name is preceded by a period 
and does not include anything after the TLD (.com).</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_cookie_path_ssl';
$fields[3]['name']     = 'Secure (SSL) Cookie Path';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '1';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>The cookie path entered below should correspond to the secure URL 
on which this installation will run.  This path is preceded by a slash, but 
should not include a trailing slash.  If you are configuring this software 
to interface with Joomla!, enter '/' for the cookie path.</p>

<p>Example: The cookie path for the URL 'http://www.yourdomain.com/core' would be 
entered as '/core'.  Notice the cookie path contains everything after the TLD (.com).</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'CookP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_CookP                                             |
// +------------------------------------------------------------------+

function step_CookP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Cookie Info - Process
// | 
// | This function does the following:
// |
// | 1. Verifies the data submitted.
// | 2. Validates Cookie Info.
// | 3. Defines confirm/error messages to be printed to the screen.
// | 4. Writes out reg data to config.php if valid.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_cookie_domain_nonssl' => 1,
                                  'config_cookie_path_nonssl'   => 1,
                                  'config_cookie_domain_ssl'    => 1,
                                  'config_cookie_path_ssl'      => 1));

if ($this->IsError($fd)) {return $fd;}

$config_cookie_domain_nonssl = $fd['config_cookie_domain_nonssl'];
$config_cookie_path_nonssl   = $fd['config_cookie_path_nonssl'];
$config_cookie_domain_ssl    = $fd['config_cookie_domain_ssl'];
$config_cookie_path_ssl      = $fd['config_cookie_path_ssl'];

// +--
// | Strip off any trailing slashes.
// +--

$config_cookie_path_nonssl = preg_replace('/\/$/','',$config_cookie_path_nonssl);
$config_cookie_path_ssl    = preg_replace('/\/$/','',$config_cookie_path_ssl);

// +--
// | Nothing to check here.  We assume the data is good.
// +--

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.cookie_domain_nonssl',$config_cookie_domain_nonssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.cookie_path_nonssl',$config_cookie_path_nonssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.cookie_domain_ssl',$config_cookie_domain_ssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.cookie_path_ssl',$config_cookie_path_ssl,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The cookie configuration information you submitted 
            has been saved.  You can now continue through the installation 
            process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_RegCrypt();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_RegCrypt                                          |
// +------------------------------------------------------------------+

function step_RegCrypt () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','5');
$this->globals('installer.steptext','Registration Info &#038; Encryption Key');

// +--
// | Registration Info & Encryption Key
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$lickey   = $this->globals('core.reg_lickey');
$fname    = $this->globals('core.reg_fname');
$lname    = $this->globals('core.reg_lname');
$email    = $this->globals('core.reg_email');
$cryptkey = $this->globals('core.cryptkey');

// +--
// | If we already have registration data and an encryption key on
// | file, we just present that info and allow the user to review it.
// +--

if (($lickey) && ($fname) && ($lname) && ($email) && ($cryptkey)) {

$header = <<<ENDOFTEXT

<p>This program has already been registered and an encryption key
has been selected.  The software license key and encryption key 
you submitted when you originally ran this installer script are stored 
in a read-only format.  This information is presented below for you 
to review.  If your contact information has changed, you can update 
that information using the fields below.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_reg_lickey';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $lickey;

$fields[1]['id']       = 'config_cryptkey';
$fields[1]['type']     = 'HIDDEN';
$fields[1]['required'] = '1';
$fields[1]['value']    = $cryptkey;

$fields[2]['id']       = 'config_reg_fname';
$fields[2]['name']     = 'Registrant First Name';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>Enter the first name of the person you wish to designate as the registrant for 
this installation.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_reg_lname';
$fields[3]['name']     = 'Registrant Last Name';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '1';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>Enter the last name of the person you wish to designate as the registrant for 
this installation.</p>

ENDOFTEXT;

$fields[4]['id']       = 'config_reg_email';
$fields[4]['name']     = 'Registrant Email Address';
$fields[4]['type']     = 'TEXT-REG';
$fields[4]['required'] = '1';

$fields[4]['desc']     = <<<ENDOFTEXT

<p>Enter a valid email address for the registrant selected above.  This email 
address will be used to broadcast update messages for this software and to verify 
support requests for secured data.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'RegCryptP'));

// +--
// | Otherwise the user will have to complete all of this information.
// +--

} else {

$header = <<<ENDOFTEXT

<p>In order to install this software on 
your webserver, you need to register the program and select an encryption 
key.  During the registration phase of the installation, contact will be 
made with the central server to verify the information you submit.
In order to sucessfully register the program, be sure to enter the information 
requested exactly as it appears on the order confirmation message you received 
from Kryptronic.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_reg_lickey';
$fields[0]['name']     = 'Software License Key';
$fields[0]['type']     = 'TEXT-REG';
$fields[0]['required'] = '1';

$fields[0]['desc']     = <<<ENDOFTEXT

<p>The software license key was provided when you placed an order for a 
software license.  This license key is unique to this installation and can only be 
used to register a single license of the this software.</p>

ENDOFTEXT;

$fields[1]['id']       = 'config_cryptkey';
$fields[1]['name']     = 'Encryption Key';
$fields[1]['type']     = 'PASSWORD';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Enter an encryption key to use to encrypt sensitive data such as 
passwords in the database.  This encryption key should be unique to 
this installation and should not be shared with anyone.</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_reg_fname';
$fields[2]['name']     = 'Registrant First Name';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>Enter the first name of the person you wish to designate as the registrant for 
this installation.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_reg_lname';
$fields[3]['name']     = 'Registrant Last Name';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '1';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>Enter the last name of the person you wish to designate as the registrant for 
this installation.</p>

ENDOFTEXT;

$fields[4]['id']       = 'config_reg_email';
$fields[4]['name']     = 'Registrant Email Address';
$fields[4]['type']     = 'TEXT-REG';
$fields[4]['required'] = '1';

$fields[4]['desc']     = <<<ENDOFTEXT

<p>Enter a valid email address for the registrant selected above.  This email 
address will be used to broadcast update messages for this software and to verify 
support requests for secured data.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'RegCryptP'));

} // End of if statement.

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_RegCryptP                                         |
// +------------------------------------------------------------------+

function step_RegCryptP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Registration Info & Encryption Key - Process
// | 
// | This function does the following:
// |
// | 1. Verifies the data submitted.
// | 2. Connects to the central server to send/receive reg data.
// | 3. Defines confirm/error messages to be printed to the screen.
// | 4. Writes out reg data to config.php if valid.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_reg_lickey' => 1,
                                  'config_reg_fname'  => 1,
                                  'config_reg_lname'  => 1,
                                  'config_reg_email'  => 1,
                                  'config_cryptkey'   => 1));

if ($this->IsError($fd)) {return $fd;}

$config_reg_lickey = $fd['config_reg_lickey'];
$config_reg_fname  = $fd['config_reg_fname'];
$config_reg_lname  = $fd['config_reg_lname'];
$config_reg_email  = $fd['config_reg_email'];
$config_cryptkey   = $fd['config_cryptkey'];

// +--
// | Ensure the email address is all lowercase.
// +--

$config_reg_email = strtolower($config_reg_email);

// +--
// | Contact the central registration server with the registration info
// | and wait for a response.  If the response is 'OK', then we can write
// | out our info to the config file.  If the response not 'OK', then 
// | we error out back to the entry screen with an error message sent
// | from the server.
// +--

$xmlrequest          = array();

$xmlrequest['xml.0'] = array('reg_fname.0' => $config_reg_fname,
                             'reg_lname.0' => $config_reg_lname,
                             'reg_email.0' => $config_reg_email);

$xmlresponse = $this->centserv_req(array('xml'     => $xmlrequest,
                                         'dtd'     => 'centralserv_regcore_req_v1.0.dtd',
                                         'method'  => 'RegCORE',
                                         'apiver'  => '1.0',
                                         'license' => $config_reg_lickey));

// +--
// | Handle errors.
// +--

if ($this->IsError($xmlresponse)) {return $xmlresponse;}

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.reg_lickey',$config_reg_lickey,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.reg_fname',$config_reg_fname,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.reg_lname',$config_reg_lname,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.reg_email',$config_reg_email,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.cryptkey',$config_cryptkey,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The registration information and encryption key you 
            entered has been validated and saved.  You can now continue 
            through the installation process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_PEARins();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_PEARins                                           |
// +------------------------------------------------------------------+

function step_PEARins () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','6');
$this->globals('installer.steptext','PEAR Installation');

// +--
// | PEAR Install Intro
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>In order to install this software on 
your webserver, modules from the PHP Extension and Application Repository 
(PEAR) need to be installed.  This software requires these PEAR modules to 
provide core functionality.  These modules are freely available from 
pear.php.net and each is distributed under license by their authors.  
Module license information is available on pear.php.net.</p>

<p class="strong">Please note: PEAR module installation is a multi-task 
interactive process which requires you to click 'Continue' after each task 
is completed.</p>

ENDOFTEXT;

// +--
// | Form field is dependent on whether PEAR has been installed.
// +--

$installed = $this->globals('core.install_pear');

if ($installed) {

$fields[0]['id']       = 'install_pear';
$fields[0]['name']     = 'PEAR Module Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('1' => 'No, do not reinstall/update PEAR modules.',
                               '2' => 'Yes, reinstall/update PEAR modules.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>It appears that PEAR modules have already been installed.  Select below whether 
to install these modules again.  If you choose to install these modules again, any 
modules currently installed will be overwritten with a newer version, if a newer 
version is available.  If the latest version is currently installed for a given 
module, that module will be left intact.</p>

<p>If you are currently updating your software and/or installing newly purchased  
software, choose to reinstall/update modules. You do not have to overwrite all 
files to update your software or to install new software.</p>

<p>If you would like to completely reinstall all of the PEAR modules, 
check the Overwrite Installed Modules box below.</p>

ENDOFTEXT;

$fields[1]['id']       = 'install_overwrite';
$fields[1]['name']     = 'Overwrite Software Files';
$fields[1]['type']     = 'CHECKBOX';
$fields[1]['required'] = '0';
$fields[1]['values']   = array('1' => 'Overwrite all files.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>By default this installer will not update software if it is installed and
it's version and/or files are up to date.</p>

<p>You can force the reinstallation of all files regardless of version or 
file update status by checking the box below.  This option is available for 
installations that may have been corrupted due to faulty code modifications or 
some other error.  It is recommended that you leave this box unchecked unless 
you know of a problem with the software currently installed.</p>

ENDOFTEXT;

$fields[2]['id']       = 'auto_submit';
$fields[2]['name']     = 'Auto-Submit Installation Steps';
$fields[2]['type']     = 'RADIO';
$fields[2]['required'] = '1';
$fields[2]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[2]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

$fields[3]['id']       = 'install_newonly';
$fields[3]['type']     = 'HIDDEN';
$fields[3]['required'] = '1';
$fields[3]['value']    = '0';

} else {

$fields[0]['id']       = 'install_pear';
$fields[0]['name']     = 'PEAR Module Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('2' => 'Install PEAR modules.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Installation and use of this program requires you install modules from 
the PHP Extension and Application Repository (PEAR).</p>

ENDOFTEXT;


$fields[1]['id']       = 'auto_submit';
$fields[1]['name']     = 'Auto-Submit Installation Steps';
$fields[1]['type']     = 'RADIO';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'PEARinsP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_PEARinsP                                          |
// +------------------------------------------------------------------+

function step_PEARinsP () {

// +--
// | Installer Function Step.
// +--

// +--
// | PEAR Install - Process
// | 
// | This function does the following:
// |
// | 1. Downloads and installs all PEAR files.
// | 2. Defines confirm/error messages to be printed to the screen.
// +--

$install = $this->globals('installer_cgi.install_pear');
if (!($install)) {$install = 4;}

$overwrite = $this->globals('installer_cgi.install_overwrite');
if (empty($overwrite)) {$overwrite = 0;} else {$overwrite = 1;}

$newonly = $this->globals('installer_cgi.install_newonly');
if (empty($newonly)) {$newonly = 0;} else {$newonly = 1;}

// +--
// | Bypass this step if the formdata variable is 1.
// +--

if ($install == 1) {

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  The PEAR modules already installed have been 
                 left intact.  You can now continue through the 
                 installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_COREins();

} // End of if statement.

// +--
// | If we have a formdata value of 3 that means the install has
// | been completed.
// +--

if ($install == 3) {

     // +--
     // | Write out our config variable.
     // +--

     $result = $this->writeconfig('core.install_pear','1','PRIVATE');
     if ($this->IsError($result)) {return $result;}

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  All required PEAR modules have been installed.  
                 You can now continue through the installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_COREins();

} // End of if statement.

// +--
// | Otherwise we need to do the installation.  Do the source install
// | first.  We do this if $install is not equal to 4.  If it is 
// | equal to 4 that means we're in the middle of our installation
// | process and this step has already been done.
// +--

if ($install != '4') {

     $this->globals('core.install_pearsource',0);

     $result = $this->install_pear_source();

     if ($this->IsError($result)) {return $result;}

     // +--
     // | Print a confirmation message.
     // +--

     $message = "PEAR source files have been installed.  The installer
                 is now ready to install PEAR archive files.";

     $this->disp_message($message,'CONFIRM');

} // End of if statement.

// +--
// | Now do the archive installation.
// +--

$installdo = array('install'   => 'PEAR',
                   'stepnum'   => '6',
                   'steptext'  => 'PEAR Installation',
                   'stepthis'  => 'PEARinsP',
                   'cgivar'    => 'install_pear',
                   'cgivalue'  => '4',
                   'cgifinish' => '3',
                   'overwrite' => $overwrite,
                   'newonly'   => $newonly);

// +--
// | Execute and return the InstallDo step.
// +--

return $this->install_do($installdo);

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_COREins                                           |
// +------------------------------------------------------------------+

function step_COREins () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','7');
$this->globals('installer.steptext','Core Installation');

// +--
// | Core Install Intro
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of the system component is required.  The system component is 
installed by contacting the central server with your registration 
information and if a valid response is received, the system component is 
downloaded and installed.</p>

<p class="strong">Please note: Component and module installation 
is a multi-task interactive process which requires you to click 
'Continue' after each task is completed.</p>

ENDOFTEXT;

// +--
// | Form field is dependent on whether the core has been installed.
// +--

$installed = $this->globals('core.install_core');

if ($installed) {

$fields[0]['id']       = 'install_core';
$fields[0]['name']     = 'Core Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('1' => 'No, do not reinstall/update the system component.',
                               '2' => 'Yes, reinstall/update  the system component.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>It appears that the system component has already been installed.  Select below whether 
to install the component again.  If you choose to install these modules again, any 
modules currently installed will be overwritten with a newer version, if a newer 
version is available.  If the latest version is currently installed for a given 
module, that module will be left intact.</p>

<p>If you are currently updating your software and/or installing newly purchased 
software, choose to reinstall/update the component. You do not have to overwrite 
all files to update your software or to install new software.</p>

<p>If you would like to completely reinstall all of the core modules, 
check the Overwrite Installed Modules box below.</p>

ENDOFTEXT;

$fields[1]['id']       = 'install_overwrite';
$fields[1]['name']     = 'Overwrite Software Files';
$fields[1]['type']     = 'CHECKBOX';
$fields[1]['required'] = '0';
$fields[1]['values']   = array('1' => 'Overwrite all files.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>By default this installer will not update software if it is installed and
it's version and/or files are up to date.</p>

<p>You can force the reinstallation of all files regardless of version or 
file update status by checking the box below.  This option is available for 
installations that may have been corrupted due to faulty code modifications or 
some other error.  It is recommended that you leave this box unchecked unless 
you know of a problem with the software currently installed.</p>

ENDOFTEXT;

$fields[2]['id']       = 'auto_submit';
$fields[2]['name']     = 'Auto-Submit Installation Steps';
$fields[2]['type']     = 'RADIO';
$fields[2]['required'] = '1';
$fields[2]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[2]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

$fields[3]['id']       = 'install_newonly';
$fields[3]['type']     = 'HIDDEN';
$fields[3]['required'] = '1';
$fields[3]['value']    = '0';

} else {

$fields[0]['id']       = 'install_core';
$fields[0]['name']     = 'Core Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('2' => 'Install the system component.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Installation of the system component is required.  The system component 
is installed by contacting the central server with your 
registration information and if a valid response is received, the system component
is downloaded and installed.</p>

ENDOFTEXT;

$fields[1]['id']       = 'auto_submit';
$fields[1]['name']     = 'Auto-Submit Installation Steps';
$fields[1]['type']     = 'RADIO';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'COREinsP'));

// +--
// | Return true
// +--
return 1;
} // End of function.

// +------------------------------------------------------------------+
// | Function: step_COREinsP                                          |
// +------------------------------------------------------------------+

function step_COREinsP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Core Install - Process
// |
// | 1. Connects to the central server to get download login.
// | 2. Connects to the central server to get download instructions.
// | 3. Downloads and installs all core files.
// | 4. Defines confirm/error messages to be printed to the screen.
// +--

$install = $this->globals('installer_cgi.install_core');
if (!($install)) {$install = 4;}

$overwrite = $this->globals('installer_cgi.install_overwrite');
if (empty($overwrite)) {$overwrite = 0;} else {$overwrite = 1;}

$newonly = $this->globals('installer_cgi.install_newonly');
if (empty($newonly)) {$newonly = 0;} else {$newonly = 1;}

// +--
// | Bypass this step if the formdata variable is 1.
// +--

if ($install == 1) {

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  The currently installed system component has 
                 been left intact.  You can now continue through the 
                 installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_MailPick();

} // End of if statement.

// +--
// | If we have a formdata value of 3 that means the install has
// | been completed.
// +--

if ($install == 3) {

     // +--
     // | Write out our config variable.
     // +--

     $result = $this->writeconfig('core.install_core','1','PRIVATE');
     if ($this->IsError($result)) {return $result;}

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  The system component has been 
                 installed.  You can now continue through the 
                 installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_MailPick();

} // End of if statement.

// +--
// | Do the archive installation.
// +--

$installdo = array('install'   => 'CORE',
                   'stepnum'   => '7',
                   'steptext'  => 'Core Installation',
                   'stepthis'  => 'COREinsP',
                   'cgivar'    => 'install_core',
                   'cgivalue'  => '4',
                   'cgifinish' => '3',
                   'overwrite' => $overwrite,
                   'newonly'   => $newonly);

// +--
// | Execute and return the InstallDo step.
// +--

return $this->install_do($installdo);

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_MailPick                                          |
// +------------------------------------------------------------------+

function step_MailPick () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','8');
$this->globals('installer.steptext','Mail Configuration');

// +--
// | Mail Configuration
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>Installation of this software on your webserver requires the ability to 
connect to an Simple Mail Transfer Protocol (SMTP) server, the ability to 
connect to the sendmail executable (Unix/Linux servers only), or the ability to 
use the PHP mail() function to send mail using the software.</p>

<p>Wherever possible, a connection to an SMTP server is optimal.  For 
Unix/Linux servers where security protocols prohibit internal connections 
to an SMTP server, select the sendmail option.</p>

<p>After selecting the type of mail connection to configure, you will 
be presented with connection-specific information to complete.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_mail_mailtype';
$fields[0]['name']     = 'Mail Configuration';
$fields[0]['type']     = 'SELECT';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('smtp'     => 'SMTP Server Connection',
                               'sendmail' => 'Sendmail Executable',
                               'mail'     => 'PHP Mail Function');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Select the type of mail configuration you wish to use with this software.  
The types listed below are all fully supported by the PEAR Mail module.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'MailPickP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_MailPickP                                         |
// +------------------------------------------------------------------+

function step_MailPickP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Mail Configuration (Selection) - Process
// |
// | 1. Verifies the data submitted.
// | 2. Directs the user to the mail configuration page.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_mail_mailtype' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_mail_mailtype = $fd['config_mail_mailtype'];

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The mail configuration selection you made has 
            been validated.  You can now continue through the 
            installation process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_MailConf();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_MailConf                                          |
// +------------------------------------------------------------------+

function step_MailConf () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','9');
$this->globals('installer.steptext','Mail Configuration');

// +--
// | SMTP Configuration
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_mail_mailtype' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_mail_mailtype = $fd['config_mail_mailtype'];

// +--
// | Handle SMTP configuration.
// +--

if ($config_mail_mailtype == 'smtp') {

$header = <<<ENDOFTEXT

<p>You have selected to configure mail for this software 
using a connection to a Simple Mail Transfer Protocol 
(SMTP) server.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_mail_mailtype';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $config_mail_mailtype;

$fields[1]['id']       = 'config_mail_host';
$fields[1]['name']     = 'SMTP Server Hostname';
$fields[1]['type']     = 'TEXT-REG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Every SMTP server can be connected to using either a common 
hostname (Example: localhost or mail.host.com) or an IP address 
(Example: 127.1.2.1).  Most SMTP servers will respond to the name 
'localhost'.  Enter your SMTP server's hostname or IP address below.</p>

<p>If your server requires the SMTP server be connected to over SSL, 
prefix the hostname with 'ssl://' to ensure an SSL connection is 
established with the server.</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_mail_port';
$fields[2]['name']     = 'SMTP Server Port';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>Every SMTP server operates on a dedicated port on the server.  The 
standard port for SMTP is port '25'.  Your server may require the use 
of a non-standard port.  Enter your SMTP server's port below.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_mail_user';
$fields[3]['name']     = 'SMTP Server Username';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '0';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>Some server administrators require authentication to connect to their 
SMTP server.  If your server requires SMTP transactions to be authenticated, 
enter the username for the server below.</p>

<p>Only enter a SMTP Server Username if you are sure your host requires 
SMTP authentication.</p>

ENDOFTEXT;

$fields[4]['id']       = 'config_mail_pass';
$fields[4]['name']     = 'SMTP Server Password';
$fields[4]['type']     = 'PASSWORD';
$fields[4]['required'] = '0';

$fields[4]['desc']     = <<<ENDOFTEXT

<p>Some server administrators require authentication to connect to their SMTP 
server.  If your server requires SMTP transactions to be authenticated, enter 
the password for the server below.</p>

<p>Only enter a SMTP Server Password if you are sure your host requires 
SMTP authentication.</p>

ENDOFTEXT;

// +--
// | Handle Sendmail configuration.
// +--

} elseif ($config_mail_mailtype == 'sendmail') {

$header = <<<ENDOFTEXT

<p>You have selected to configure mail for this software 
using a connection to the sendmail executable.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_mail_mailtype';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $config_mail_mailtype;

$fields[1]['id']       = 'config_mail_sendmail';
$fields[1]['name']     = 'Sendmail Executable Location';
$fields[1]['type']     = 'TEXT-REG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Enter the location of the sendmail executable below.  The default sendmail 
executable location for a majority of Unix/Linux servers is:</p>

<p>Example: /usr/sbin/sendmail</p>

<p>If sendmail is not installed or aliased in the /usr/sbin directory, and 
you are unsure of the exact location of the executable, try the following 
in the order they are presented:</p>

<p>Example: /usr/bin/sendmail<br />
Example: /usr/lib/sendmail<br />
Example: /usr/local/sbin/sendmail<br />
Example: /usr/local/bin/sendmail</p>

ENDOFTEXT;

// +--
// | Handle PHP Mail configuration.
// +--

} else {

$header = <<<ENDOFTEXT

<p>You have selected to configure mail for this software 
using a connection to the PHP mail function.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_mail_mailtype';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $config_mail_mailtype;


$fields[1]['id']       = 'config_mail_mail';
$fields[1]['name']     = 'PHP Mail Function Selection';
$fields[1]['type']     = 'SELECT';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('mail' => 'PHP mail()');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Select the mail function to use.</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'MailConfP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_MailConfP                                         |
// +------------------------------------------------------------------+

function step_MailConfP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Mail Configuration - Process
// |
// | 1. Verifies the data submitted.
// | 2. Validates the mail connection.
// | 3. Defines confirm/error messages to be printed to the screen.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_mail_mailtype' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_mail_mailtype = $fd['config_mail_mailtype'];

if ($config_mail_mailtype == 'smtp') {

     $fd = $this->formdata_array(array('config_mail_host'     => 1,
                                       'config_mail_port'     => 1,
                                       'config_mail_user'     => 0,
                                       'config_mail_pass'     => 0,
                                       'config_mail_sendmail' => 0));

     if ($this->IsError($fd)) {return $fd;}

} elseif ($config_mail_mailtype == 'sendmail') {

     $fd = $this->formdata_array(array('config_mail_host'     => 0,
                                       'config_mail_port'     => 0,
                                       'config_mail_user'     => 0,
                                       'config_mail_pass'     => 0,
                                       'config_mail_sendmail' => 1));

     if ($this->IsError($fd)) {return $fd;}

} else {

     $fd = $this->formdata_array(array('config_mail_host'     => 0,
                                       'config_mail_port'     => 0,
                                       'config_mail_user'     => 0,
                                       'config_mail_pass'     => 0,
                                       'config_mail_sendmail' => 0));

     if ($this->IsError($fd)) {return $fd;}

} // End of if statement.

$config_mail_host     = $fd['config_mail_host'];
$config_mail_port     = $fd['config_mail_port'];
$config_mail_user     = $fd['config_mail_user'];
$config_mail_pass     = $fd['config_mail_pass'];
$config_mail_sendmail = $fd['config_mail_sendmail'];

// +--
// | If we have an SMTP request, make sure we have both a user
// | and pass - or they're both empty.
// +--

if ($config_mail_mailtype == 'smtp') {

     $error = 0;

     if (($config_mail_user) && (empty($config_mail_pass))) {$error = 1;}
     if (($config_mail_pass) && (empty($config_mail_user))) {$error = 1;}

     if ($error) {

          $message = "If you would like to configure the SMTP connection 
                      to use authentication, you must enter both a username 
                      and password.  Either delete the values for both fields 
                      or complete both fields to continue.";

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Require the PEAR Mail and Mail_mime modules.
// +--

include_once('Mail.php');
include_once('Mail/mime.php');

// +--
// | Create a new Mail_mime object for the message.
// +--

@$message = new Mail_mime();

$params = array();

// +--
// | Handle SMTP connections.
// +--

if ($config_mail_mailtype == 'smtp') {

     $config_mail_sendmail = '';

     $backend           = 'smtp';

     $params['host']    = $config_mail_host;
     $params['port']    = $config_mail_port;
     $params['persist'] = 0;
     $params['timeout'] = 15;

     if (($config_mail_user) && ($config_mail_pass)) {

          $params['auth']     = 1;
          $params['username'] = $config_mail_user;
          $params['password'] = $config_mail_pass;

     } else {

          $params['auth']     = 0;

     } // End of if statement.

// +--
// | Handle Sendmail connections.
// +--

} elseif ($config_mail_mailtype == 'sendmail') {

     $config_mail_host = '';
     $config_mail_port = '';
     $config_mail_user = '';
     $config_mail_pass = '';

     $backend                 = 'sendmail';

     $params['sendmail_path'] = $config_mail_sendmail;

// +--
// | Handle PHP Mail connections.
// +--

} else {

     $config_mail_host     = '';
     $config_mail_port     = '';
     $config_mail_user     = '';
     $config_mail_pass     = '';
     $config_mail_sendmail = '';

     $backend              = 'mail';

} // End of if statement.

// +--
// | Set up Mail object.
// +--

@$mailob = new Mail();

$mail = $mailob->factory($backend, $params);

if ($this->isError($mail)) {

     $message  = "An error was encountered while creating a new 
                  Mail object for the mail connection.  Error 
                  Information: ";

     $message .= $mail->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Formulate our message and send our mail if we were
// | able to set up an object.
// +--

$eol = $this->globals('installer.eol');

// +--
// | Configure our subject and message.
// +--

$app_url  = $this->globals('core.url_nonssl') . '/';
$app_url .= $this->globals('core.script_frontend');

// +--
// | Create TEXT message.
// +--

$text_message  = 'APP URL:         ' . $app_url . $eol;
$text_message .= 'LICENSE:         ' . $this->globals('core.reg_lickey') . $eol;
$text_message .= 'CONNECTION TYPE: ' . $config_mail_mailtype . $eol;

$message->setTXTBody($text_message);

// +--
// | Create HTML message.
// +--

$html_message  = '<html><body>' . $eol;
$html_message .= '<p><b>APP URL:</b> ' . $app_url . '</p>' . $eol;
$html_message .= '<p><b>LICENSE:</b> ' . $this->globals('core.reg_lickey') . '</p>' . $eol;
$html_message .= '<p><b>CONNECTION TYPE:</b> ' . $config_mail_mailtype . '</p>' . $eol;
$html_message .= '</body></html>' . $eol;

$message->setHTMLBody($html_message);

// +--
// | Set up our send parameters.
// +--

$recipients = 'reg@kryptronic.com';

$body       = $message->get();

// +--
// | Create mail headers.  This needs to be done after the get()
// | method call to ensure our headers include the content-type
// | and boundary.
// +--

$subject = 'Core Mail Configuration: ' . $this->globals('core.reg_lickey');

$headers = $message->headers(array('From'    => $this->globals('core.reg_email'),
                                   'To'      => 'reg@kryptronic.com',
                                   'Subject' => $subject));

// +--
// | Send our mail and handle errors.
// +--

$response = $mail->send($recipients, $headers, $body);

if ($this->isError($response)) {

     $message  = "An error was encountered while sending the mail message 
                  over the Mail connection.  Error Information: ";

     $message .= $response->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.mail_mailtype',$config_mail_mailtype,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.mail_host',$config_mail_host,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.mail_port',$config_mail_port,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.mail_user',$config_mail_user,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.mail_pass',$config_mail_pass,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.mail_sendmail',$config_mail_sendmail,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The Mail configuration information you submitted 
            has been saved.  You can now continue through the installation 
            process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_DBPick();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_DBPick                                            |
// +------------------------------------------------------------------+

function step_DBPick () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','10');
$this->globals('installer.steptext','Database Selection');

// +--
// | Database Selection
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

// +--
// | Get a listing of the database types we can use with the core.
// +--

$xml = $this->xmlget_public('install_db_list.xml');

if (!(IsSet($xml['xml.0']['db.0']))) {

     $message = "This script could not connect to the central
                 server to download a list of valid database types.  
                 This may be the result of an Internet connectivity 
                 problem.  Try again later.";

     trigger_error($message,E_USER_ERROR);

     return $result;

} // End of if statement.

// +--
// | Create a db types array for the form.
// +--

$db_types = array();

$count = 0;

while (IsSet($xml['xml.0']['db.' . $count])) {

     $id   = $xml['xml.0']['db.' . $count]['id.0'];
     $name = $xml['xml.0']['db.' . $count]['name.0'];

     $db_types[$id] = $name;
     
     $count++;

} // End of while statement.

// +--
// | Create the form.
// +--


$header = <<<ENDOFTEXT

<p>Installation of this software on your webserver requires that a connection 
with a database be present.  In the last step of the installation process the 
database module was installed to allow connection to a variety of different databases.</p>

<p>If you have not configured a database account to use, now is the time to do so.  
This software takes care of creating all the database tables it uses, however the 
database itself needs to exist.</p>

<p>If you are unsure of the version or type of database you have configured on this 
webserver, contact your server administrator.</p>

<p>The database used by this software must be configured with the following 
permissions: CREATE, DROP, ALTER, INSERT, UPDATE, DELETE and SELECT.</p>

<p>After selecting the type of database you have configured, you will be presented 
with database-specific connection information to complete.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_db_dbtype';
$fields[0]['name']     = 'Database Type';
$fields[0]['type']     = 'SELECT';
$fields[0]['required'] = '1';
$fields[0]['values']   = $db_types;

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Select the type of database you intend to use with this software.  The types 
listed below are all fully supported by the database module.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'DBPickP'));


// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_DBPickP                                           |
// +------------------------------------------------------------------+

function step_DBPickP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Mail Configuration (Selection) - Process
// |
// | 1. Verifies the data submitted.
// | 2. Directs the user to the mail configuration page.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_db_dbtype' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_db_dbtype = $fd['config_db_dbtype'];

// +--
// | Handle SQLite database creation.
// +--

if ($config_db_dbtype == 'sqlite') {

     // +--
     // | Create the 'sqlite' directory if it doesn't
     // | exist.
     // +--

     $db_dir = $this->globals('core.path_private') . '/sqlite';

     if (!(@file_exists($db_dir))) {

          $result = $this->make_dir($db_dir);

          if ($this->IsError($result)) {

               $message  = "An error was encountered while creating a directory
                            for the SQLite database.  The installer attempted to 
                            create a directory named sqlite within the Private 
                            Directory Path.  Error Information: ";

               $message .= $result->GetMessage();

               $result = $this->RaiseError($message);

               return $result;

          } // End of if statement.

     } // End of if statement.

     $db_file = $this->globals('core.path_private') . '/sqlite/core.db';

     if (!(@file_exists($db_file))) {

          $result = $this->file_write(array('name' => $db_file,
                                            'data' => ''));

          if ($this->IsError($result)) {

               $message  = "An error was encountered while creating a file
                            for the SQLite database.  The installer attempted to 
                            create a file named core.db in the sqlite directory
                            within the Private Directory Path.  Error Information: ";

               $message .= $result->GetMessage();

               $result = $this->RaiseError($message);

               return $result;

          } // End of if statement.

     } // End of if statement.

} // End of if statement.

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The database selection you made has been 
            validated.  You can now continue through the 
            installation process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_DBConf();

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_DBConf                                            |
// +------------------------------------------------------------------+

function step_DBConf () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','11');
$this->globals('installer.steptext','Database Configuration');

// +--
// | Database Configuration
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_db_dbtype' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_db_dbtype = $fd['config_db_dbtype'];

// +--
// | Handle SQLite configuration.
// +--

if ($config_db_dbtype == 'sqlite') {

$db_file = $this->globals('core.path_private') . '/sqlite/core.db';

$this->globals('installer_cgi.config_db_dbname',$db_file);

$header = <<<ENDOFTEXT

<p>Complete the following database connection information to configure a 
connection with the database you selected.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_db_dbtype';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $config_db_dbtype;

$fields[1]['id']       = 'config_db_dbname';
$fields[1]['name']     = 'SQLite Database Path';
$fields[1]['type']     = 'TEXT-LONG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>The path below is the path to the SQLite database file used by this software.  
This file has been created automatically for you.  If at any time you 
wish to back up your SQLite database, simply obtain a copy of this file.</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_db_hostname';
$fields[2]['type']     = 'HIDDEN';
$fields[2]['required'] = '1';
$fields[2]['value']    = 'localhost';

$fields[3]['id']       = 'config_db_username';
$fields[3]['type']     = 'HIDDEN';
$fields[3]['required'] = '1';
$fields[3]['value']    = 'none';

$fields[4]['id']       = 'config_db_password';
$fields[4]['type']     = 'HIDDEN';
$fields[4]['required'] = '1';
$fields[4]['value']    = 'none';

// +--
// | Handle configuration for all other db types.
// +--

} else {

$header = <<<ENDOFTEXT

<p>Complete the following database connection information to configure a 
connection with the database you selected.</p>

ENDOFTEXT;

$fields[0]['id']       = 'config_db_dbtype';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = '1';
$fields[0]['value']    = $config_db_dbtype;

$fields[1]['id']       = 'config_db_hostname';
$fields[1]['name']     = 'Database Hostname';
$fields[1]['type']     = 'TEXT-REG';
$fields[1]['required'] = '1';

$fields[1]['desc']     = <<<ENDOFTEXT

<p>Enter the hostname of the server where the database resides.  Typically 
this is set to 'localhost' if the database resides on the same server as 
this software installation.</p>

ENDOFTEXT;

$fields[2]['id']       = 'config_db_dbname';
$fields[2]['name']     = 'Database Name';
$fields[2]['type']     = 'TEXT-REG';
$fields[2]['required'] = '1';

$fields[2]['desc']     = <<<ENDOFTEXT

<p>Enter the name of the database that was configured for use with this software.</p>

ENDOFTEXT;

$fields[3]['id']       = 'config_db_username';
$fields[3]['name']     = 'Database Username';
$fields[3]['type']     = 'TEXT-REG';
$fields[3]['required'] = '1';

$fields[3]['desc']     = <<<ENDOFTEXT

<p>Enter the username for the database that was configured for use with 
this software.  This is the username which will be used by this software to connect 
to the database.</p>

ENDOFTEXT;

$fields[4]['id']       = 'config_db_password';
$fields[4]['name']     = 'Database Password';
$fields[4]['type']     = 'PASSWORD';
$fields[4]['required'] = '1';

$fields[4]['desc']     = <<<ENDOFTEXT

<p>Enter the password for the username entered above.  This is the password 
which will be used by this software to connect to the database.</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'DBConfP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_DBConfP                                           |
// +------------------------------------------------------------------+

function step_DBConfP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Database Configuration (Settings) - Process
// |
// | 1. Verifies the data submitted.
// | 2. Validates the database connection.
// | 3. Defines confirm/error messages to be printed to the screen.
// | 4. Writes out reg data to config.php if valid.
// +--

// +--
// | Make sure required fields were completed.
// +--

$fd = $this->formdata_array(array('config_db_dbtype'   => 1,
                                  'config_db_hostname' => 1,
                                  'config_db_dbname'   => 1,
                                  'config_db_username' => 1,
                                  'config_db_password' => 1));

if ($this->IsError($fd)) {return $fd;}

$config_db_dbtype   = $fd['config_db_dbtype'];
$config_db_hostname = $fd['config_db_hostname'];
$config_db_dbname   = $fd['config_db_dbname'];
$config_db_username = $fd['config_db_username'];
$config_db_password = $fd['config_db_password'];

// +--
// | If we have an SQLite request, make sure we can locate the 
// | SQLite database file path entered.
// +--

if ($config_db_dbtype == 'sqlite') {

     if (!(@file_exists($config_db_dbname))) {

          $message = "The location for the SQLite database file you 
                      entered does not appear to exist on this webserver.  
                      Please try again.";

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Attempt to connect to the database using the info supplied.  First
// | set a global for our installer password.
// +--

$installer_password = $this->globals('installer_cgi.config_password');

$this->globals('core.installpass',$installer_password);

// +--
// | Include the core and set up our configuration parameters.  We need
// | to globalize our $xglobals_cache var because we need to pass
// | that as a configuration array to the core constructor.
// |
// | We handle core errors a bit differently than regular errors.
// +--

@include_once($this->globals('core.path_private') . '/core/CORE/CORE.php');

global $xglobal_cache;

$core = new CORE($xglobal_cache);

if ((!(empty($core->cerror))) && ($this->IsError($core->cerror))) {

     $message  = "An error was encountered while creating a new 
                  CORE object.  Error Information: ";

     $message .= $core->cerror->getMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Try to include our CORE_DB module using the default
// | object handle.
// +--

$dsn = array('dbtype'   => $config_db_dbtype,
             'username' => $config_db_username,
             'password' => $config_db_password,
             'hostname' => $config_db_hostname,
             'dbname'   => $config_db_dbname);

$CORE_DB =& $core->load_object(array('app'       => 'core',
                                     'class'     => 'CORE_DB',
                                     'name'      => 'CORE_DB_1',
                                     'construct' => $dsn));

if ($this->IsError($CORE_DB)) {

     $message  = "An error was encountered while creating a new 
                  CORE_DB object.  Error Information: ";

     $message .= $CORE_DB->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Now test the connection.
// +--

$result = $CORE_DB->connect_test();

if ($this->IsError($result)) {

     $message  = "The CORE_DB module encountered an error while attempting 
                  to connect to the database.  Error Information: ";

     $message .= $result->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Write our config values.
// +--

$result = $this->writeconfig('core.db_dbtype',$config_db_dbtype,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.db_hostname',$config_db_hostname,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.db_dbname',$config_db_dbname,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.db_username',$config_db_username,'PRIVATE');
if ($this->IsError($result)) {return $result;}

$result = $this->writeconfig('core.db_password',$config_db_password,'PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Print a confirmation message.
// +--

$message = "Thank you.  The database connection information you 
            entered has been validated and a connection was established 
            with the database.  You can now continue through the installation 
            process.";

$this->disp_message($message,'CONFIRM');

// +--
// | Go to the next step.
// +--

return $this->step_InsApps();

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_InsApps                                           |
// +------------------------------------------------------------------+

function step_InsApps () {

// +--
// | Installer Function Step.
// +--

$this->globals('installer.step','12');
$this->globals('installer.steptext','Component &amp; Module Installation');

// +--
// | Component Install Intro
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

$header = <<<ENDOFTEXT

<p>The system component and required PEAR modules have been installed.  
With the core and PEAR set up, this installer can now install 
components and modules.</p>

<p>Any components and modules associated with your software license 
are installed by contacting the central server with your 
registration information and if a valid response is received, 
software is downloaded and installed.</p>

<p class="strong">Please note: Component and module installation 
is a multi-task interactive process which requires you to click 
'Continue' after each task is completed.</p>

ENDOFTEXT;

// +--
// | Form field is dependent on whether apps have been installed.
// +--

$installed = $this->globals('core.install_apps');

if ($installed) {

$fields[0]['id']       = 'install_apps';
$fields[0]['name']     = 'Component &amp; Module Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('1' => 'No, do not reinstall/update components and modules.',
                               '2' => 'Yes, reinstall/update components and modules.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>It appears that components and modules have already been installed.  
Select below whether to install the components and modules again.  If you choose to 
install the components and modules again, any software currently installed will be 
overwritten with a newer version, if a newer version is available.  If the 
latest version is currently installed, that software will be left intact.</p>

<p>If you are currently updating your software and/or installing newly purchased 
software, choose to reinstall/update the components and modules. You do not have 
to overwrite all files to update your software or to install new software.</p>

<p>If you would like to completely reinstall all of the components and modules, 
check the Overwrite Installed Modules box below.</p>

ENDOFTEXT;

$fields[1]['id']       = 'install_newonly';
$fields[1]['name']     = 'Install Only New Components &amp; Modules';
$fields[1]['type']     = 'CHECKBOX';
$fields[1]['required'] = '0';
$fields[1]['values']   = array('1' => 'Only install new components and modules.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>By default this installer will update a module if the module is found 
to be installed already and it's version is not up to date.</p>

<p>You can ignore updates to software and install only new components and modules 
by checking the box below.   If you check the box below, none of your existing 
software will be updated, but any new software you may have purchased, but have not 
yet installed, will be installed for you.  If you select to only install new modules 
and components, ensure you have checked the reinstall/update components and modules
box in the 'Component &amp; Module Installation' section.</p>

ENDOFTEXT;

$fields[2]['id']       = 'install_overwrite';
$fields[2]['name']     = 'Overwrite Software Files';
$fields[2]['type']     = 'CHECKBOX';
$fields[2]['required'] = '0';
$fields[2]['values']   = array('1' => 'Overwrite all files.');

$fields[2]['desc']     = <<<ENDOFTEXT

<p>By default this installer will not update software if it is installed and
it's version and/or files are up to date.</p>

<p>You can force the reinstallation of all files regardless of version or 
file update status by checking the box below.  This option is available for 
installations that may have been corrupted due to faulty code modifications or 
some other error.  It is recommended that you leave this box unchecked unless 
you know of a problem with the software currently installed.</p>

ENDOFTEXT;

$fields[3]['id']       = 'auto_submit';
$fields[3]['name']     = 'Auto-Submit Installation Steps';
$fields[3]['type']     = 'RADIO';
$fields[3]['required'] = '1';
$fields[3]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[3]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

} else {

$fields[0]['id']       = 'install_apps';
$fields[0]['name']     = 'Component &amp; Module Installation';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('2' => 'Install components and modules.',
                               '5' => 'Skip component and module installation.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>Components and modules are installed by contacting the central server with 
your registration information and if a valid response is received, software is 
downloaded and installed.</p>

<p>If no components or modules are associated with your software license, or you 
would like to skip this step, choose the 'Skip component and module installation 
option'.</p>

ENDOFTEXT;

$fields[1]['id']       = 'auto_submit';
$fields[1]['name']     = 'Auto-Submit Installation Steps';
$fields[1]['type']     = 'RADIO';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('1' => 'Yes, auto-submit installation steps.',
                               '2' => 'No, do not auto-submit installation steps.');

$fields[1]['desc']     = <<<ENDOFTEXT
<p>This process is a multi-step installation process.  If you would like this 
installer script to auto-submit each step for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit installation steps option below.  
Otherwise, you will be required to click the 'Continue' button to process each step.</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'InsAppsP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_InsAppsP                                          |
// +------------------------------------------------------------------+

function step_InsAppsP () {

// +--
// | Installer Function Step.
// +--

// +--
// | Component Install - Process
// |
// | 1. Connects to the central server to get download login.
// | 2. Connects to the central server to get download instructions.
// | 3. Downloads and installs all component files.
// | 4. Defines confirm/error messages to be printed to the screen.
// +--

$install   = $this->globals('installer_cgi.install_apps');
if (!($install)) {$install = 4;}

$overwrite = $this->globals('installer_cgi.install_overwrite');
if (empty($overwrite)) {$overwrite = 0;} else {$overwrite = 1;}

$newonly = $this->globals('installer_cgi.install_newonly');
if (empty($newonly)) {$newonly = 0;} else {$newonly = 1;}

// +--
// | Bypass this step if the formdata variable is 1.
// +--

if ($install == 1) {

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  The currently installed components 
                 have been left intact.  You can now 
                 continue through the installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_COREsetup();

} // End of if statement.

// +--
// | Bypass this step if the formdata variable is 5.
// +--

if ($install == 5) {

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  You selected to skip the component 
                 installation step.  You can now continue through the 
                 installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Reset our install_overwrite and install_newonly indicators.
     // +--

     $this->globals('installer_cgi.install_overwrite',0);
     $this->globals('installer_cgi.install_newonly',0);

     // +--
     // | Go to the next step.
     // +--

     return $this->step_COREsetup();

} // End of if statement.

// +--
// | If we have a formdata value of 3 that means the install has
// | been completed.
// +--

if ($install == 3) {

     // +--
     // | Write out our config variable.
     // +--

     $result = $this->writeconfig('core.install_apps','1','PRIVATE');
     if ($this->IsError($result)) {return $result;}

     // +--
     // | Print a confirmation message.
     // +--

     $message = "Thank you.  The components have been installed.
                 You can now continue through the installation process.";

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Go to the next step.
     // +--

     return $this->step_COREsetup();

} // End of if statement.

// +--
// | Do the archive installation.
// +--

$installdo = array('install'   => 'APPS',
                   'stepnum'   => '12',
                   'steptext'  => 'Component Installation',
                   'stepthis'  => 'InsAppsP',
                   'cgivar'    => 'install_apps',
                   'cgivalue'  => '4',
                   'cgifinish' => '3',
                   'overwrite' => $overwrite,
                   'newonly'   => $newonly);

// +--
// | Execute and return the InstallDo step.
// +--

return $this->install_do($installdo);

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_COREsetup                                         |
// +------------------------------------------------------------------+

function step_COREsetup () {

// +--
// | Installer Function Step.
// +--

$installed = $this->globals('core.install_db');

if ($installed) {

     $this->globals('installer.step','13');
     $this->globals('installer.steptext','Database Reload');

} else {

     $this->globals('installer.step','13');
     $this->globals('installer.steptext','Database Initialization');

} // End of if statement.

// +--
// | Database Initialization / Reload
// | 
// | This function prints a form to be completed by the user to 
// | submit information to be processed.
// +--

// +--
// | Form is dependent on whether the database has been 
// | initialized.
// +--

if ($installed) {

$header = <<<ENDOFTEXT

<p>Reload of the database is required 
to complete this installation process.  The database is loaded through a 
series of database update tasks defined as instructions in XML table and data 
definition files in the software codebase.</p>

<p>By default, during a database reload, database table and data definitions are 
reloaded only for XML definition files that exist in the software codebase which are 
less than 12 hours old.  This is done to ensure only recently installed XML 
definition files are used to update the database.</p>

<p>If you are currently updating your software and/or installing newly purchased 
software, you do not have to reload the entire database using all definition files.  
A database reload with changed definition files will make the necessary database 
updates.</p>

ENDOFTEXT;

$fields[0]['id']       = 'install_db';
$fields[0]['name']     = 'Database Reload';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('1' => 'Reload with recently changed definition files only.',
                               '2' => 'Reload using all definition files.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>The module used to handle database initialization makes every attempt to modify 
changed data only.  It is recommended that you choose to reload the database with 
recently changed definition files only.</p>

<p>If you are aware of a database corruption issue or would like to completely 
reload the entire database using all of the definition files in the installation, 
choose to reload using all files.  Only do this if you are sure you need to reload 
all files.</p>

<p>This process is typically completed in under 10 seconds.  On servers 
with heavy traffic or load, or CPU or memory limits in place, the process 
can take longer.  Please allow the installer to complete this step and 
print a confirmation page.</p>

ENDOFTEXT;

} else {

$header = <<<ENDOFTEXT
 
<p>Initialization of the database is required 
to complete this installation process.  The database is initialized through a 
series of database update tasks defined as instructions in XML table and data 
definition files in the software codebase.</p>

<p>This initialization process uses these database-independent XML table and 
data definition files to create database tables and load data into those 
tables.</p>

ENDOFTEXT;

$fields[0]['id']       = 'install_db';
$fields[0]['name']     = 'Database Initialization';
$fields[0]['type']     = 'RADIO';
$fields[0]['required'] = '1';
$fields[0]['values']   = array('3' => 'Initialize the database.');

$fields[0]['desc']     = <<<ENDOFTEXT

<p>This process is typically completed in under 10 seconds.  On servers 
with heavy traffic or load, or CPU or memory limits in place, the process 
can take longer.  Please allow the installer to complete this step and 
print a confirmation page.</p>

ENDOFTEXT;

} // End of if statement.

$fields[1]['id']       = 'auto_submit';
$fields[1]['name']     = 'Auto-Submit Database Load Actions';
$fields[1]['type']     = 'RADIO';
$fields[1]['required'] = '1';
$fields[1]['values']   = array('1' => 'Yes, auto-submit database load actions.',
                               '2' => 'No, do not auto-submit database load actions.');

$fields[1]['desc']     = <<<ENDOFTEXT

<p>This process is a multi-step database load process.  If you would like this 
installer script to auto-submit each action for you, and JavaScript is enabled 
on your Internet browser, choose the auto-submit database load actions option below.  
Otherwise, you will be required to click the 'Continue' button to process each action.</p>

ENDOFTEXT;

// +--
// | Print the form.
// +--

$this->disp_form(array('header' => $header,
                       'fields' => $fields,
                       'step'   => 'COREsetupP'));

// +--
// | Return true
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_COREsetupP                                        |
// +------------------------------------------------------------------+

function step_COREsetupP () {

// +--
// | Installer Function Step.
// +--

$installed = $this->globals('core.install_db');

if ($installed) {

     $this->globals('installer.step','13');
     $this->globals('installer.steptext','Database Reload');

} else {

     $this->globals('installer.step','13');
     $this->globals('installer.steptext','Database Initialization');

} // End of if statement.

// +--
// | Database Initialization - Process
// |
// | 1. Connects to the core and loads the CORE_Installer module.
// | 2. Runs the CORE_Installer setup() method.// +--

$install_db = $this->globals('installer_cgi.install_db');
if (!($install_db)) {$install_db = 1;}

// +--
// | Define a global variable to be passed as a configuration option
// | to the core to indicate whether we're doing a full db load or
// | one for changed XML definition files only.
// +--

if ($install_db == 1) {

     $dbload_type = 'CHANGED';

} else {

     $dbload_type = 'FULL';

} // End of if statement.

$this->globals('core.dbload_type',$dbload_type);

// +--
// | Attempt to connect to the core.  First set a global for our 
// | installer password.
// +--

$installer_password = $this->globals('installer_cgi.config_password');

$this->globals('core.installpass',$installer_password);

// +--
// | Include the core and set up our configuration parameters.  We need
// | to globalize our $xglobals_cache var because we need to pass
// | that as a configuration array to the core constructor.
// |
// | We handle core errors a bit differently than regular errors.
// +--

@include_once($this->globals('core.path_private') . '/core/CORE/CORE.php');

global $xglobal_cache;

$core = new CORE($xglobal_cache);

if ((!(empty($core->cerror))) && ($this->IsError($core->cerror))) {

     $message  = "An error was encountered while creating a new 
                  CORE object.  Error Information: ";

     $message .= $core->cerror->getMessage();

     return $result;

} // End of if statement.

// +--
// | Try to include our CORE_DB module using the default
// | object handle.
// +--

$dsn = array('dbtype'   => $this->globals('core.db_dbtype'),
             'username' => $this->globals('core.db_username'),
             'password' => $this->globals('core.db_password'),
             'hostname' => $this->globals('core.db_hostname'),
             'dbname'   => $this->globals('core.db_dbname'));

$CORE_DB =& $core->load_object(array('app'       => 'core',
                                     'class'     => 'CORE_DB',
                                     'name'      => 'CORE_DB_1',
                                     'construct' => $dsn));

if ($this->IsError($CORE_DB)) {

     $message  = "An error was encountered while creating a new 
                  CORE_DB object.  Error Information: ";

     $message .= $CORE_DB->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Now connect to the database.
// +--

$result = $CORE_DB->connect();

if ($this->IsError($result)) {

     $message  = "The CORE_DB module encountered an error while attempting 
                  to connect to the database.  Error Information: ";

     $message .= $result->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Include our CORE_Installer module.
// +--

$CORE_Installer =& $core->load_object(array('app'       => 'core',
                                            'class'     => 'CORE_Installer',
                                            'name'      => 'CORE_Installer'));

if ($this->IsError($CORE_Installer)) {

     $message  = "An error was encountered while creating a new 
                  CORE_Installer object.  Error Information: ";

     $message .= $CORE_Installer->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Set the completed status.
// +--

$dbload_completed = $this->globals('installer_cgi.dbload_completed');
if (!($dbload_completed)) {$dbload_completed = 0;}

// +--
// | Run the CORE_Installer get_dbload() method.
// +--

$instruct = array();

if (empty($dbload_completed)) {

     $instruct = $CORE_Installer->get_dbload();

     if ($this->IsError($instruct)) {

          $message  = "An error occurred while retrieving the database load
                       instruction set using the CORE_Installer module.  
                       Error Information: ";

          $message .= $instruct->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement

// +--
// | If the instruction set is empty or we're complete, we can 
// | continue onto the next step.
// +--

$dbload_completed = $this->globals('installer_cgi.dbload_completed');
if (!($dbload_completed)) {$dbload_completed = 0;}

if ((empty($instruct)) || ($dbload_completed)) {

     // +--
     // | Disconnect from the DB.
     // +--

     $CORE_DB->disconnect();

     // +--
     // | Globalize the core version number (we use this in the final
     // | step.
     // +--

     $version_core = $core->version;

     $this->globals('installer.version_core',$version_core);

     // +--
     // | Write our our config value.
     // +--

     $result = $this->writeconfig('core.install_db','1','PRIVATE');
     if ($this->IsError($result)) {return $result;}

     // +--
     // | Print a message.
     // +--
     if ($dbload_completed) {

          if ($install_db == 3) {

               $message = "Thank you.  The database has been 
                           intialized.";

          } else {

               $message = "Thank you.  The database has been 
                           reloaded.";

          } // End of if statement.

     } else {

          $message = "Thank you.  The database was fully up to date.  
                      No changes were made.";

     } // End of if statement.

     $this->disp_message($message,'CONFIRM');

     // +--
     // | Go to the next step.
     // +--

     return $this->step_Final();

} // End of if statement.

// +--
// | Otherwise we need to present our form.
// +--

// +--
// | Define the EOL.
// +--

$eol = $this->globals('installer.eol');

// +--
// | Progress bar logic.
// +--

$progress_bar = '';

$progress_bar_countt  = 0;
$progress_bar_counti  = 0;
$progress_bar_disp    = 50;

// +--
// | Figure out where we are in the mix.
// +--

$action = 'COMPLETE';

$taskdo_txt   = '';
$taskcomp_txt = '';
$taskpend_txt = '';

$taskdo_num   = $this->globals('installer_cgi.taskdo');

if (!(isset($taskdo_num))) {$action = 'INTRO'; $taskdo_num = '0';}

// +--
// | Loop through the instruction set.
// +--

$count = 0;

foreach ($instruct as $num => $data) {

     $taskdo_num_incremented = 0;

     // +--
     // | Mark pending tasks as pending.
     // +--

     if ($taskdo_num < $count) {

          $xtext         = $this->xhtml_encode($data['display']);
          $taskpend_txt .= '<li>' . $xtext . '</li>' . $eol;

     } // End of if statement.

     // +--
     // | Handle current tasks.
     // +--

     if ($taskdo_num == $count) {

          // +--
          // | If our action is INTRO we need to present the 
          // | first item as a current install item.
          // +--

          if (($action == 'INTRO') || ($action == 'INSTALL')) {

               $xtext       = $this->xhtml_encode($data['display']);
               $taskdo_txt .= '<li>' . $xtext . '</li>' . $eol;

          // +--
          // | Otherwise we need to do an install.
          // +--

          } else {

               $action = 'INSTALL';

               if (!(empty($data['param']))) {

                    $result = $CORE_Installer->{$data['function']}($data['param']);

               } else {

                    $result = $CORE_Installer->{$data['function']}();

               } // End of if statement.

               // +--
               // | Handle errors.
               // +--

               if ($this->IsError($result)) {

                    $message  = "An error was encountered while performing the database 
                                 load task requested.  Error Information: ";

                    $message .=  $result->GetMessage();

                    $result = $this->RaiseError($message);

                    return $result;

               // +--
               // | Since we completed this install we can confirm it
               // | and add the item to the completed list.
               // +--

               } else {

                    $taskdo_num++;
                    $taskdo_num_incremented++;

                    $xtext         = $this->xhtml_encode($data['display']);
                    $taskcomp_txt .= '<li>' . $xtext . '</li>' . $eol;

                    $message = "Thank you.  The database load task requested has 
                                been completed.  You can now continue through the 
                                multi-step database load process.";

                    $this->disp_message($message,'CONFIRM');

                    $progress_bar_counti = $count + 1;

               } // End of if statement.

          } // End of if statement.

     } // End of if statement.

     // +--
     // | Handle items we've already completed.
     // +--

     if (($taskdo_num > $count) && (!($taskdo_num_incremented))) {

          $xtext         = $this->xhtml_encode($data['display']);
          $taskcomp_txt .= '<li>' . $xtext . '</li>' . $eol . $eol;

     } // End of if statement.

     $count++;

     $progress_bar_countt  = $count;

} // End of foreach statement.

// +--
// | Progress bar logic.
// +--

$bars_disp     = '';
$bars_leftdisp = '';
$bar_count     = 0;

if (($progress_bar_counti) && ($progress_bar_countt)) {

     $pct = $progress_bar_counti / $progress_bar_countt;
     $pct = round($pct,2);

     $pct_disp = $pct * 100;

     $bars = $progress_bar_disp * $pct;
     $bars = round($bars);

} else {

     $bars     = 0;
     $pct_disp = 0;

} // End of if statement.

while ($bar_count < $bars) {$bar_count++; $bars_disp .= '|';}

$bars_left = $progress_bar_disp - $bars;

$bar_count = 0;

while ($bar_count < $bars_left) {$bar_count++; $bars_leftdisp .= '|';}

$pct_leftdisp = 100 - $pct_disp;

$progress_bar  = '<p class="meter">Progress: </p>';

if ($bars) {$progress_bar .= '<p class="metercomp">' . $bars_disp . '</p>';}

if ($bars_left) {$progress_bar .= '<p class="meterpend">' . $bars_leftdisp . '</p>';}

$progress_bar .= '<p class="meter"> [' . $pct_disp . '%]</p>' . $eol . $eol;

// +--
// | Figure out if we just completed what we had to do.
// +--

if ($taskdo_num >= $count) {$action = 'COMPLETE';}

// +--
// | Formulate the form header.
// +--

if ($action == 'INTRO') {

$header = <<<ENDOFTEXT

<p>You have selected to process a multi-step database load that will 
update the database on this webserver account.  Click the 'Continue' 
button to proceed (or wait for the form to submit itself if you selected 
the auto-submit option).</p>

ENDOFTEXT;

} elseif ($action == 'COMPLETE') {

$header = <<<ENDOFTEXT

<p>Database load tasks have completed.</p>

ENDOFTEXT;

} else {

$header = <<<ENDOFTEXT

<p>Continue clicking the 'Continue' button to complete the 
database load on this webserver account (or wait for this form to 
submit itself if you selected the auto-submit option).</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Add the form tag to the header.
// +--

$insname = $this->globals('installer.script_name');

$header .= '<form action="' . $insname . '" method="post" id="installer">' . $eol . $eol;

// +--
// | Add the progress info to the header.
// +--

if (!($taskdo_txt))   {$taskdo_txt   = '<li>Current Task: None</li>' . $eol;}
if (!($taskpend_txt)) {$taskpend_txt = '<li>Pending Tasks: None</li>' . $eol;}
if (!($taskcomp_txt)) {$taskcomp_txt = '<li>Completed Tasks: None</li>' . $eol;}

$header .= <<<ENDOFTEXT

<fieldset>

<legend class="strong"><label for="taskdo">Database Load Task Status</label></legend>

<p class="formfieldleg">Database Load Task Status</p>

<div class="formfieldinstruct">

<p>The progress meter below displays your progress during this multi-task interactive 
database load process.</p>

<div id='meter'>{$progress_bar}</div>

</div>

<p class="hidden"><input type="hidden" name="taskstatus" id="taskstatus" value="1" /></p>

</fieldset>

<fieldset>

<legend class="strong"><label for="taskdo">Database Load Task Listing</label></legend>

<p class="formfieldleg">Database Load Task Listing</p>

<div class="formfieldinstruct">

<p>The following database load task listing shows database load tasks to be 
completed during this multi-task database load process as well as the current 
status of each task.</p>

<p class="strong">Current Task:</p>

<ul>
{$taskdo_txt}
</ul>

<p class="hidden"><input type="hidden" name="taskdo" id="taskdo" value="{$taskdo_num}" /></p>

<p class="strong">Pending Tasks:</p>

<ul>
{$taskpend_txt}
</ul>

<p class="strong">Completed Tasks:</p>

<ul>
{$taskcomp_txt}
</ul>

</div>

</fieldset>

ENDOFTEXT;

// +--
// | Formulate the form fields.
// +--

$fields[0]['id']       = 'install_db';
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = 0;
$fields[0]['value']    = $install_db;

if ($action == 'COMPLETE') {

     $fields[1]['id']       = 'dbload_completed';
     $fields[1]['type']     = 'HIDDEN';
     $fields[1]['required'] = 0;
     $fields[1]['value']    = '1';

} else {

     $fields[1]['id']       = 'dbload_completed';
     $fields[1]['type']     = 'HIDDEN';
     $fields[1]['required'] = 0;
     $fields[1]['value']    = '0';

} // End of if statement.

// +--
// | Handle the auto-submit form object.
// +--

$auto_submit = $this->globals('installer_cgi.auto_submit');
if (!($auto_submit)) {$auto_submit = 0;}

// +--
// | Print the form.
// +--

$this->disp_form(array('header'   => $header,
                       'fields'   => $fields,
                       'step'     => 'COREsetupP',
                       'supform'  => 1,
                       'autosub'  => $auto_submit));

// +--
// | Disconnect from the DB.
// +--

$CORE_DB->disconnect();

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: step_Final                                             |
// +------------------------------------------------------------------+

function step_Final () {

// +--
// | Installer Function Step.
// +--

// +--
// | Get the core version number.  It was defined in the last step.
// +--

$version_core = $this->globals('installer.version_core');

if (empty($version_core)) {$version_core = '0.0.0';}

// +--
// | Connect to the database and get version info for
// | all installed apps.  If we run into errors, we ignore them.
// +--

$apps_array = array();

$error = 0;

// +--
// | Include the core and set up our configuration parameters.  We need
// | to globalize our $xglobals_cache var because we need to pass
// | that as a configuration array to the core constructor.
// +--

@include_once($this->globals('core.path_private') . '/core/CORE/CORE.php');

global $xglobal_cache;

$core = new CORE($xglobal_cache);

if ((!(empty($core->cerror))) && ($this->IsError($core->cerror))) {

     $error = 1;

} // End of if statement.

if (empty($error)) {

     $dsn = array('dbtype'   => $this->globals('core.db_dbtype'),
                  'username' => $this->globals('core.db_username'),
                  'password' => $this->globals('core.db_password'),
                  'hostname' => $this->globals('core.db_hostname'),
                  'dbname'   => $this->globals('core.db_dbname'));

     $CORE_DB =& $core->load_object(array('app'       => 'core',
                                          'class'     => 'CORE_DB',
                                          'name'      => 'CORE_DB_1',
                                          'construct' => $dsn));

     if ($this->IsError($CORE_DB)) {$error = 1;}

} // End of if statement.

if (empty($error)) {

     $result = $CORE_DB->connect();

     if ($this->IsError($result)) {$error = 1;}

} // End of if statement.

if (empty($error)) {

     $sql = "SELECT id, class, version FROM core_apps";

     $result = $CORE_DB->sql_do(array('table' => 'core_apps',
                                      'sql'   => $sql,
                                      'order' => array('id' => 'ASC')));

     if (($this->IsError($result)) || (empty($result))) {$error = 1;}

} // End of if statement.

if (empty($error)) {

     $count = 0;

     foreach ($result as $num => $row) {

          $apps_array['app.' . $count] = array('appid.0'   => $row['id'],
                                               'class.0'   => $row['class'],
                                               'version.0' => $row['version']);

          $count++;

     } // End of foreach statement.

} // End of if statement.

if (empty($error)) {

     $CORE_DB->disconnect();

} // End of if statement.

// +--
// | Default $apps_array to basic core info if we ran into
// | a problem.
// +--

if (empty($apps_array)) {

     $apps_array = array('app.0' => array('appid.0'   => 'core',
                                          'class.0'   => 'CORE',
                                          'version.0' => $version_core));

} // End of if statement.

// +--
// | Make a report to the central server.  We don't care about
// | errors here.
// +--

$xmlrequest          = array();

$xmlrequest['xml.0'] = $apps_array;

$xmlrequest['xml.0']['version_php.0']     = PHP_VERSION;
$xmlrequest['xml.0']['version_os.0']      = PHP_OS;
$xmlrequest['xml.0']['version_webserv.0'] = $_SERVER['SERVER_SOFTWARE'];
$xmlrequest['xml.0']['type_db.0']         = $this->globals('core.db_dbtype');

$xmlresponse = $this->centserv_req(array('xml'     => $xmlrequest,
                                         'dtd'     => 'centralserv_installreport_req_v1.0.dtd',
                                         'method'  => 'InstallReport',
                                         'apiver'  => '1.0'));

// +--
// | Define variables for the confirm display.
// +--

$link     = $this->globals('core.script_backend');
$pathpub  = $this->xhtml_encode($this->globals('core.path_public'));
$pathpriv = $this->xhtml_encode($this->globals('core.path_private'));

// +--
// | Final Confirm Display
// +--

print <<<ENDOFTEXT

<p>The installation process has completed.</p>

<p>During the installation process, your Management Interface account was set up 
using your registration email address and the password you use to access this installer 
script.  You can change these intitial account settings after logging into the 
Management Interface.</p>

<p><a href="{$link}" title="Management Interface">Click here to run 
the Management Interface.</a></p>

<p class="strong">Security Notice:</p>

<p>During this installation process, a public downloads directory was created.  This
directory should be password protected for security purposes.  In addition, if your 
private directory path is web-accessible, you must password protect that directory 
as well. Follow the instructions below to password protect these directories:</p>
  
<p>If you are installing on a Unix or Linux server running Apache, this can be done 
with .htaccess and .htpasswd files. In order to do this properly, you should use 
whatever tool your hosting provider has available to password protect directories.
For most Unix or Linux servers, your control panel should have a function for this. 
If you are running on a Windows server, you will most likely have to contact your 
Windows server administrator and ask them to password protect the directories for you.
These directories are located on the filesystem at the following locations:</p>

<p>Public Downloads Directory: {$pathpub}/downloads</p>
<p>Private Directory: {$pathpriv}</p>

<p>Enter the username and password you choose for the public downloads directory 
in the management interface using the Core | Settings | 
Download Directory Settings function after logging into the Management 
Interface.</p>

ENDOFTEXT;

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Module Install Tasks                                             |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: install_do                                             |
// +------------------------------------------------------------------+

function install_do ($input = array()) {

// +--
// | This function runs a generic installation.  It accepts the 
// | following input in an array:
// |
// | install   =>  The type of install to be done.
// |
// | stepnum   =>  The current step number.
// |
// | steptext  =>  The text for the current step.
// |
// | stepthis  =>  The step used as a wrapper for processing.
// |
// | cgivar    =>  The installation CGI var name used by stepthis.
// |
// | cgivalue  =>  The installation CGI value used by stepthis.
// |
// | cgifinish =>  The installation CGI value to use when finished.
// |
// | overwrite =>  Boolean indicator controlling whether a complete
// |               module overwrite should be done.  Defaults to 0.
// |
// | newonly   =>  Boolean indicator controlling whether new modules
// |               only should be installed.  Defaults to 0.
// +--

$install   = (isset($input['install'])   ? $input['install']   : '');
$stepnum   = (isset($input['stepnum'])   ? $input['stepnum']   : '');
$steptext  = (isset($input['steptext'])  ? $input['steptext']  : '');
$stepthis  = (isset($input['stepthis'])  ? $input['stepthis']  : '');
$cgivar    = (isset($input['cgivar'])    ? $input['cgivar']    : '');
$cgivalue  = (isset($input['cgivalue'])  ? $input['cgivalue']  : '');
$cgifinish = (isset($input['cgifinish']) ? $input['cgifinish'] : '');
$overwrite = (isset($input['overwrite']) ? $input['overwrite'] : 0);
$newonly   = (isset($input['newonly'])   ? $input['newonly']   : 0);

// +--
// | Make sure we have everything.  If we don't, error out.
// +--

if ((empty($install)) || (empty($stepnum)) || (empty($steptext)) || (empty($stepthis)) || (empty($cgivar)) || (empty($cgivalue)) || (empty($cgifinish))) {

     $message = "The install_do() method was accessed with incomplete
                 information.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Create our stepnum and steptext global variables.
// +--

$this->globals('installer.step',$stepnum);
$this->globals('installer.steptext',$steptext);

// +--
// | Contact our central server to get download instructions.
// +--

$xmlrequest          = array();

$xmlrequest['xml.0'] = array('install.0' => $install);

$xmlresponse = $this->centserv_req(array('xml'     => $xmlrequest,
                                         'dtd'     => 'centralserv_install_req_v1.0.dtd',
                                         'method'  => 'Install',
                                         'apiver'  => '1.0'));

// +--
// | Handle errors.
// +--

if ($this->IsError($xmlresponse)) {return $xmlresponse;}

// +--
// | Define the EOL.
// +--

$eol = $this->globals('installer.eol');

// +--
// | Progress bar logic.
// +--

$progress_bar = '';

$progress_bar_countt  = 0;
$progress_bar_counti  = 0;
$progress_bar_disp    = 50;

// +--
// | Figure out where we are in the mix.
// +--

$action = 'COMPLETE';

$taskdo_txt   = '';
$taskcomp_txt = '';
$taskpend_txt = '';

$taskdo_num   = $this->globals('installer_cgi.taskdo');

if (!(isset($taskdo_num))) {$action = 'INTRO'; $taskdo_num = '0';}

// +--
// | Loop through the XML.
// +--

$count = 0;

while (IsSet($xmlresponse['xml.0']['package.' . $count]['name.0'])) {

     // +--
     // | Set up installation data.
     // +--

     $xinstall = array();

     $xinstall['name']      = $xmlresponse['xml.0']['package.' . $count]['name.0'];
     $xinstall['version']   = $xmlresponse['xml.0']['package.' . $count]['version.0'];
     $xinstall['type']      = $xmlresponse['xml.0']['package.' . $count]['type.0'];
     $xinstall['url']       = $xmlresponse['xml.0']['package.' . $count]['url.0'];
     $xinstall['app']       = $xmlresponse['xml.0']['package.' . $count]['app.0'];
     $xinstall['desc']      = $xmlresponse['xml.0']['package.' . $count]['desc.0'];

     $xinstall['overwrite'] = $overwrite;
     $xinstall['newonly']   = $newonly;

     $taskdo_num_incremented = 0;

     // +--
     // | Mark pending tasks as pending.
     // +--

     if ($taskdo_num < $count) {

          $xtext = $xinstall['desc'] . ' ' . $xinstall['version'];
          $xtext = $this->xhtml_encode($xtext);

          $taskpend_txt .= '<li>' . $xtext . '</li>' . $eol;

     } // End of if statement.

     // +--
     // | Handle current tasks.
     // +--

     if ($taskdo_num == $count) {

          // +--
          // | If our action is INTRO we need to present the 
          // | first item as a current install item.
          // +--

          if (($action == 'INTRO') || ($action == 'INSTALL')) {

               $xtext = $xinstall['desc'] . ' ' . $xinstall['version'];
               $xtext = $this->xhtml_encode($xtext);

               $taskdo_txt .= '<li>' . $xtext . '</li>' . $eol;

          // +--
          // | Otherwise we need to do an install.
          // +--

          } else {

               $action = 'INSTALL';

               $result = $this->install_package($xinstall);

               // +--
               // | Handle errors.
               // +--

               if ($this->IsError($result)) {

                    $message  = "An error was encountered while installing the 
                                 {$xinstall['desc']} module.  Error Information: ";

                    $message .=  $result->GetMessage();

                    $result = $this->RaiseError($message);

                    return $result;

               // +--
               // | Since we completed this install we can confirm it
               // | and add the item to the completed list.
               // +--

               } else {

                    $taskdo_num++;
                    $taskdo_num_incremented++;

                    $xtext = $xinstall['desc'] . ' ' . $xinstall['version'];
                    $xtext = $this->xhtml_encode($xtext);

                    $taskcomp_txt .= '<li>' . $xtext . '</li>' . $eol;

                    if ($result == 1) {

                         $message = "Thank you.  {$xinstall['desc']} version {$xinstall['version']} 
                                     has been installed/updated.  You can now continue through the 
                                     multi-step installation process.";

                    } elseif ($result == 2) {

                         $message = "Thank you.  {$xinstall['desc']} version {$xinstall['version']} 
                                     was already installed.  The module was not updated because it 
                                     is currently up to date.  Please continue through the multi-step 
                                     installation process.";

                    } else {

                         $message = "Thank you.  {$xinstall['desc']} version {$xinstall['version']} 
                                     was already installed.  The module was not updated because you 
                                     selected to install new modules only.  Please continue through 
                                     the multi-step installation process.";

                    } // End of if statement.

                    $this->disp_message($message,'CONFIRM');

                    $progress_bar_counti = $count + 1;

               } // End of if statement.

          } // End of if statement.

     } // End of if statement.

     // +--
     // | Handle items we've already completed.
     // +--

     if (($taskdo_num > $count) && (!($taskdo_num_incremented))) {

          $xtext = $xinstall['desc'] . ' ' . $xinstall['version'];
          $xtext = $this->xhtml_encode($xtext);

          $taskcomp_txt .= '<li>' . $xtext . '</li>' . $eol . $eol;

     } // End of if statement.

     $count++;

     $progress_bar_countt  = $count;

} // End of while statement.

// +--
// | Progress bar logic.
// +--

$bars_disp     = '';
$bars_leftdisp = '';
$bar_count     = 0;

if (($progress_bar_counti) && ($progress_bar_countt)) {

     $pct = $progress_bar_counti / $progress_bar_countt;
     $pct = round($pct,2);

     $pct_disp = $pct * 100;

     $bars = $progress_bar_disp * $pct;
     $bars = round($bars);

} else {

     $bars     = 0;
     $pct_disp = 0;

} // End of if statement.

while ($bar_count < $bars) {$bar_count++; $bars_disp .= '|';}

$bars_left = $progress_bar_disp - $bars;

$bar_count = 0;

while ($bar_count < $bars_left) {$bar_count++; $bars_leftdisp .= '|';}

$pct_leftdisp = 100 - $pct_disp;

$progress_bar  = '<p class="meter">Progress: </p>';

if ($bars) {$progress_bar .= '<p class="metercomp">' . $bars_disp . '</p>';}

if ($bars_left) {$progress_bar .= '<p class="meterpend">' . $bars_leftdisp . '</p>';}

$progress_bar .= '<p class="meter"> [' . $pct_disp . '%]</p>' . $eol . $eol;

// +--
// | Figure out if we just completed what we had to do.
// +--

if ($taskdo_num >= $count) {$action = 'COMPLETE';}

// +--
// | Formulate the form header.
// +--

if ($action == 'INTRO') {

$header = <<<ENDOFTEXT

<p>You have selected to process a multi-step installation that will 
complete the {$steptext} on this webserver account.  Click the 'Continue' 
button to proceed (or wait for the form to submit itself if you selected 
the auto-submit option).</p>

ENDOFTEXT;

} elseif ($action == 'COMPLETE') {

$header = <<<ENDOFTEXT

<p>Installation tasks have completed for the {$steptext} on this 
webserver account.</p>

ENDOFTEXT;

} else {

$header = <<<ENDOFTEXT

<p>Continue clicking the 'Continue' button to complete the 
{$steptext} on this webserver account (or wait for this form to 
submit itself if you selected the auto-submit option).</p>

ENDOFTEXT;

} // End of if statement.

// +--
// | Add the form tag to the header.
// +--

$insname = $this->globals('installer.script_name');

$header .= '<form action="' . $insname . '" method="post" id="installer">' . $eol . $eol;

// +--
// | Add the progress info to the header.
// +--

if (!($taskdo_txt))   {$taskdo_txt   = '<li>Current Install: None</li>' . $eol;}
if (!($taskpend_txt)) {$taskpend_txt = '<li>Pending Install: None</li>' . $eol;}
if (!($taskcomp_txt)) {$taskcomp_txt = '<li>Completed Install: None</li>' . $eol;}

$header .= <<<ENDOFTEXT

<fieldset>

<legend class="strong"><label for="taskdo">Installation Task Status</label></legend>

<p class="formfieldleg">Installation Task Status</p>

<div class="formfieldinstruct">

<p>The progress meter below displays your progress during this 
multi-task interactive installation process.</p>

<div id='meter'>{$progress_bar}</div>

</div>

<p class="hidden"><input type="hidden" name="taskstatus" id="taskstatus" value="1" /></p>

</fieldset>

<fieldset>

<legend class="strong"><label for="taskdo">Installation Task Listing</label></legend>

<p class="formfieldleg">Installation Task Listing</p>

<div class="formfieldinstruct">

<p>The following installation task listing shows all modules to be 
installed during this multi-task interactive installation process 
as well as the installation status of each module.</p>

<p class="strong">Current Task:</p>

<ul>
{$taskdo_txt}
</ul>

<p class="hidden"><input type="hidden" name="taskdo" id="taskdo" value="{$taskdo_num}" /></p>

<p class="strong">Pending Tasks:</p>

<ul>
{$taskpend_txt}
</ul>

<p class="strong">Completed Tasks:</p>

<ul>
{$taskcomp_txt}
</ul>

</div>

</fieldset>

ENDOFTEXT;

// +--
// | Formulate the form fields.
// +--

if ($action == 'COMPLETE') {$cgivalue = $cgifinish;}

$fields[0]['id']       = $cgivar;
$fields[0]['type']     = 'HIDDEN';
$fields[0]['required'] = 0;
$fields[0]['value']    = $cgivalue;

$fields[1]['id']       = 'install_overwrite';
$fields[1]['type']     = 'HIDDEN';
$fields[1]['required'] = 0;
$fields[1]['value']    = $overwrite;

$fields[2]['id']       = 'install_newonly';
$fields[2]['type']     = 'HIDDEN';
$fields[2]['required'] = 0;
$fields[2]['value']    = $newonly;

// +--
// | Handle the auto-submit form object.
// +--

$auto_submit = $this->globals('installer_cgi.auto_submit');
if (!($auto_submit)) {$auto_submit = 0;}

// +--
// | Print the form.
// +--

$this->disp_form(array('header'   => $header,
                       'fields'   => $fields,
                       'step'     => $stepthis,
                       'supform'  => 1,
                       'autosub'  => $auto_submit));

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: install_pear_source                                    |
// +------------------------------------------------------------------+

function install_pear_source ($input = array()) {

// +--
// | This function installs PEAR source files.
// +--

$installed = $this->globals('core.install_pearsource');

if ($installed) {return 1;}

// +--
// | Get the pear source XML file.
// +--

$pearsource = $this->xmlget_public('install_pearsource.xml');

if ($this->IsError($pearsource)) {

     $message  = "The installer was unable to obtain XML information from 
                  the central server for the PEAR source file
                  installation.  Error Information: ";

     $message .= $pearsource->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Loop through the XML and build out directories.
// +--

$count = 0;

while (IsSet($pearsource['xml.0']['directory.' . $count])) {

     $dir = $pearsource['xml.0']['directory.' . $count]['name.0'];

     $dir = preg_replace('/^PRIVATE/',$this->globals('core.path_private'),$dir);
     $dir = preg_replace('/^PUBLIC/',$this->globals('core.path_public'),$dir);

     $result = $this->make_dir($dir);

     if ($this->IsError($result)) {

          $message  = "The installer was unable to create a directory
                       for the PEAR source file installation.  Error 
                       Information: ";

          $message .= $result->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

     $count++;

} // End of while statement.

// +--
// | Loop through the XML and copy files.
// +--

$count = 0;

while (IsSet($pearsource['xml.0']['file.' . $count])) {

     $origin = $pearsource['xml.0']['file.' . $count]['origin.0'];
     $dest   = $pearsource['xml.0']['file.' . $count]['destination.0'];

     $dest = preg_replace('/^PRIVATE/',$this->globals('core.path_private'),$dest);
     $dest = preg_replace('/^PUBLIC/',$this->globals('core.path_public'),$dest);

     $result = $this->file_copy(array('source' => $origin,
                                      'dest'   => $dest));

     if ($this->IsError($pearsource)) {

          $message  = "The installer was unable to copy a source file
                       for the PEAR source file installation.  Error 
                       Information: ";

          $message .= $pearsource->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

     $count++;

} // End of while statement.

// +--
// | Update our config value.
// +--

$result = $this->writeconfig('core.install_pearsource','1','PRIVATE');
if ($this->IsError($result)) {return $result;}

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: install_package                                        |
// +------------------------------------------------------------------+

function install_package ($input = array()) {

// +--
// | This function runs a package file installation.  It accepts the 
// | following input in an array:
// |
// | name      =>  The module name.
// |
// | version   =>  The module version.
// |
// | type      =>  The module type (MODULE or SKIN).
// |
// | url       =>  The URL for the module archive file.
// |
// | app       =>  Optional parameter for the component.  If not
// |               specified we default to 'core'.
// |
// | overwrite =>  Boolean indicator controlling whether a complete
// |               module overwrite should be done.  Defaults to 0.
// |
// | newonly   =>  Boolean indicator controlling whether new modules 
// |               only should be installed.  Defaults to 0.
// +--

$name      = (isset($input['name'])      ? $input['name']      : '');
$version   = (isset($input['version'])   ? $input['version']   : '');
$type      = (isset($input['type'])      ? $input['type']      : '');
$url       = (isset($input['url'])       ? $input['url']       : '');
$app       = (isset($input['app'])       ? $input['app']       : 'core');
$overwrite = (isset($input['overwrite']) ? $input['overwrite'] : 0);
$newonly   = (isset($input['newonly'])   ? $input['newonly']   : 0);

// +--
// | Make sure we have everything.  If we don't, error out.
// +--

if ((empty($name)) || (empty($version)) || (empty($type)) || (empty($url))) {

     $message = "The install_package() method was accessed with incomplete
                 information.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Skip core skin installation if it looks like we've already 
// | got the skin installed.
// +--

if (preg_match('/^Skin\-/',$name)) {

     $xname = preg_replace('/^Skin\-/','',$name);
     $xdir  = $this->globals('core.path_public') . '/skins/' . $xname;

     if (@file_exists($xdir)) {return 2;}

} // End of if statement.

// +--
// | Get the current version of the software being installed.
// +--

$current_version = $this->install_getver(array('app'    => $app,
                                               'module' => $name));

$version_compare = $this->check_version($current_version,$version);

// +--
// | If we're installing new modules only and we've got a current
// | version that is not '0.0.0', then we can skip this one.
// +--

if ((!(empty($newonly))) && ($current_version != '0.0.0')) {

     return 3;

} // End of if statement.

// +--
// | If we're not overwriting all files and our installed version
// | is at least that of what we're trying to install, we can return.
// +--

if ((empty($overwrite)) && ($version_compare)) {

     return 2;

} // End of if statement.

// +--
// | Download the file to the temp directory if it's not already
// | there.
// +--

$filename = $name . '-' . $version . '.tar';
$dest     = $this->globals('core.path_private') . '/temp/' . $filename;

if (!(@file_exists($dest))) {

     $result   = $this->file_copy(array('source' => $url,
                                        'dest'   => $dest));

     if ($this->IsError($result)) {

          $message  = "The installer was unable to download the {$name} 
                       version {$version} source file from the 
                       central server.  Error Information: ";

          $message .= $result->GetMessage();

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

} // End of if statement.

// +--
// | Load the Archive_Tar and File_Find PEAR classes.
// +--

include_once('Archive/Tar.php');
include_once('File/Find.php');

// +--
// | Extract the archive file to a random temp directory.
// +--

$extract_dir = $this->globals('core.path_private') . '/temp/' . $this->random_key(12);

$result = $this->make_dir($extract_dir);

if ($this->IsError($result)) {

     $message  = "The installer was unable to create a temporary 
                  installation directory for the {$name} version
                  {$version} module.  Error Information: ";

     $message .= $result->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Now untar the file.
// +--

@$tar = new Archive_Tar($dest);

if (!($tar->extractModify($extract_dir, ''))) {

     $this->delete_dir($extract_dir);
     $this->file_delete($dest);

     $message  = "The installer was unable extract the {$name} version 
                  {$version} source file.  The file was not a valid 
                  archive file.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Map out the contents of the file.
// +--

@$filefind = new File_Find();

$tree = $filefind->mapTree($extract_dir . '/' . $name . '-' . $version);

if (!(isset($tree[0][1]))) {

     $this->delete_dir($extract_dir);
     $this->file_delete($dest);

     $message  = "The installer was unable to determine the contents of
                  the {$name} version {$version} source file.  The file
                  may have been empty.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Build out any directories requested.  We replace the strings
// | PRIVATE and PUBLIC with their respective values.
// |
// | Add directories that do not exist to a $make_dirs array.
// +--

$ed        = $extract_dir . '/' . $name . '-' . $version;
$ed_quoted = preg_quote($ed,'/');
$make_dirs = array();
$pathpriv  = $this->globals('core.path_private');
$pathpub   = $this->globals('core.path_public');

if (isset($tree[0])) {

     foreach ($tree[0] as $num => $dir) {

          if ($dir != $ed) {

               $xdest = preg_replace('/^' . $ed_quoted . '/','',$dir);

               if (($xdest != '/PRIVATE') && ($xdest != '/PUBLIC')) {

                    $xdest = preg_replace('/^\/PRIVATE\//',$pathpriv  . '/',$xdest);
                    $xdest = preg_replace('/^\/PUBLIC\//' ,$pathpub   . '/' ,$xdest);

                    if (!(@file_exists($xdest))) {$make_dirs[] = $xdest;}

                } // End of if statement.

          } // End of if statement.

     } // End of foreach statement.

} // End of if statement.

sort($make_dirs);

// +--
// | Build out the directories requested (if there were any).
// +--

if (!(empty($make_dirs))) {

     foreach ($make_dirs as $num => $dir) {

          $result = $this->make_dir($dir);

          if ($this->IsError($result)) {

               $this->delete_dir($extract_dir);
               $this->file_delete($dest);

               $message  = "The installer was unable to create the directory
                            {$dir} while attempting to install the 
                            {$name} version {$version} module.  Error 
                            Information: ";

               $message .= $result->GetMessage();

               $result = $this->RaiseError($message);

               return $result;

          } // End of if statement.

     } // End of foreach statement.

} // End of if statement.

// +--
// | Now read and parse the package.xml file.
// +--

$xml_file = $ed . '/package.xml';

$file_contents = $this->file_read($xml_file);

if ($this->IsError($file_contents)) {

     $this->delete_dir($extract_dir);
     $this->file_delete($dest);

     $message  = "The installer was unable to located the package.xml file
                  for the {$name} version {$version} module.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

$xparsed = $this->xmlparser($file_contents);

if ($this->IsError($xparsed)) {

     $this->delete_dir($extract_dir);
     $this->file_delete($dest);

     $message  = "The installer was unable to parse the package.xml file
                  for the {$name} version {$version} module.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

if (empty($xparsed['xml.0']['version.0'])) {

     $this->delete_dir($extract_dir);
     $this->file_delete($dest);

     $message  = "The package.xml file for the {$name} version 
                  {$version} module was not properly formatted.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Install the module files based on the current version and 
// | the contents of the pacakge.xml file.
// +--

$xfiles = array('newfile' => array(),
                'changed' => array(),
                'deleted' => array());

$count = 0;

while (isset($xparsed['xml.0']['version.' . $count])) {

     // +--
     // | Get the version and type.
     // +--

     $xml_version = $xparsed['xml.0']['version.' . $count]['number.0'];
     $xml_type    = $xparsed['xml.0']['version.' . $count]['type.0'];

     // +--
     // | Determine if we need to work with this version.
     // +--

     $version_compare = $this->check_version($current_version,$xml_version);

     if (!($version_compare)) {

          // +--
          // | Loop through the XML info and add files to our xfiles
          // | array.
          // +--

          // +--
          // | First handle new files.
          // +--

          $xcount = 0;

          while (isset($xparsed['xml.0']['version.' . $count]['newfile.' . $xcount])) {

               $file = $xparsed['xml.0']['version.' . $count]['newfile.' . $xcount];

               $xfiles['newfile'][] = $file;

               $xcount++;

          } // End of while statement.

          // +--
          // | Next handle updated files.
          // +--

          $xcount = 0;

          while (isset($xparsed['xml.0']['version.' . $count]['changed.' . $xcount])) {

               $file = $xparsed['xml.0']['version.' . $count]['changed.' . $xcount];

               $xfiles['changed'][] = $file;

               $xcount++;

          } // End of while statement.

          // +--
          // | Lastly handle deleted files.
          // +--

          $xcount = 0;

          while (isset($xparsed['xml.0']['version.' . $count]['deleted.' . $xcount])) {

               $file = $xparsed['xml.0']['version.' . $count]['deleted.' . $xcount];

               $xfiles['deleted'][] = $file;

               // +--
               // | If this file exists in our 'newfile' or 'changed'
               // | arrays we want to remove it.
               // +--

               foreach ($xfiles['newfile'] as $xnum => $xfile) {
                    if ($xfile == $file) {unset($xfiles['newfile'][$xnum]);}
               }

               foreach ($xfiles['changed'] as $xnum => $xfile) {
                    if ($xfile == $file) {unset($xfiles['changed'][$xnum]);}
               }

               $xcount++;

          } // End of while statement.

     } // End of if statement.

     $count++;

} // End of while statement.

// +--
// | Now work with the contents of our xfiles array.  Handle deleting
// | old files first.
// +--

if (!(empty($xfiles['deleted']))) {

     foreach ($xfiles['deleted'] as $num => $file) {

          $xfile = $file;
          $xfile = preg_replace('/^\//','',$xfile);

          if (($xfile) && ($xfile != 'PRIVATE') && ($xfile != 'PUBLIC')) {

               $file = preg_replace('/^PRIVATE\//',$pathpriv . '/' ,$file);
               $file = preg_replace('/^PUBLIC\//' ,$pathpub . '/'  ,$file);

               if (is_dir($file)) {

                    $this->delete_dir($file);

               } else {

                    $this->file_delete($file);

               } // End of if statement.

          } // End of if statement.

     } // End of foreach statement.

} // End of if statement.

// +--
// | Create a file copy array.
// +--

$file_copy = array();

// +--
// | Now see if we're copying over all of the files.  We know if
// | we're doing this if the $xfiles array keys 'newfile.0' or 
// | 'changed.0' have a value of *.
// +--

$copy_all = 0;

if (!(empty($xfiles['newfile']))) {

     foreach ($xfiles['newfile'] as $num => $value) {if ($value == '*') {$copy_all = 1;}}

} // End of if statement.

if (!(empty($xfiles['changed']))) {

     foreach ($xfiles['changed'] as $num => $value) {if ($value == '*') {$copy_all = 1;}}

} // End of if statement.

// +--
// | Now handle overwrite requests.  If we get one of these, we 
// | overwrite all files.
// +--

if (!(empty($overwrite))) {$copy_all = 1;}

// +--
// | If we're copying all of the files, add all the files to our
// | file_copy array.
// +--

if (($copy_all) && (isset($tree[1]))) {

     sort($tree[1]);

     foreach ($tree[1] as $num => $file) {

          $file = preg_replace('/^' . $ed_quoted . '\/PRIVATE\//','PRIVATE/',$file);
          $file = preg_replace('/^' . $ed_quoted . '\/PUBLIC\//','PUBLIC/',$file);

          if ((preg_match('/^PRIVATE\//',$file)) || (preg_match('/^PUBLIC\//',$file))) {

               $file_copy[] = $file;

          } // End of if statement.

     } // End of foreach statement.

// +--
// | Otherwise we need to loop through our $xfiles array keys 
// | 'newfile.0' and 'changed.0' to get the files we're copying.
// +--

} else {

     // +--
     // | Handle new files.
     // +--

     if (!(empty($xfiles['newfile']))) {

          foreach ($xfiles['newfile'] as $num => $file) {

               $file_copy[] = $file;

          } // End of foreach statement.

     } // End of if statement.

     // +--
     // | Handle updated files.
     // +--

     if (!(empty($xfiles['changed']))) {

          foreach ($xfiles['changed'] as $num => $file) {

               $file_copy[] = $file;

          } // End of foreach statement.

     } // End of if statement.

} // End of if statement.

// +--
// | Now we copy the files if we have any to copy.
// +--

if (!(empty($file_copy))) {

     foreach ($file_copy as $num => $file) {

          if ($file != $ed) {

               $file = preg_replace('/^\//','',$file);

               if (($file) && ($file != 'PRIVATE') && ($file != 'PUBLIC')) {

                     $sourcefile = $ed . '/' . $file;

                     $file = preg_replace('/^PRIVATE\//',$pathpriv . '/' ,$file);
                     $file = preg_replace('/^PUBLIC\//' ,$pathpub . '/'  ,$file);

                     $result = $this->file_copy(array('source' => $sourcefile,
                                                      'dest'   => $file));

                     if ($this->IsError($result)) {

                         $this->delete_dir($extract_dir);
                         $this->file_delete($dest);

                         $message  = "The installer was unable to create the file
                                      {$file} while attempting to install the 
                                      {$name} version {$version} module.  Error 
                                      Information: ";

                         $message .= $result->GetMessage();

                         $result = $this->RaiseError($message);

                         return $result;

                     } // End of if statement.

                } // End of if statement.

          } // End of if statement.

     } // End of foreach statement.

} // End of if statement.

// +--
// | Delete our archive file and temp directory.
// +--

$this->delete_dir($extract_dir);
$this->file_delete($dest);

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: install_getver                                         |
// +------------------------------------------------------------------+

function install_getver ($input = array()) {

// +--
// | This function checks to see if a module is installed already and
// | if it is, it returns the current version.
// |
// | app       =>  The component for which the module is being
// |               installed.  Defaults to 'core'.
// |
// | module    =>  The module name.
// +--

$app     = (isset($input['app'])     ? $input['app']     : 'core');
$module  = (isset($input['module'])  ? $input['module']  : '');

// +--
// | Make sure we have everything.  If we don't, we can return
// | a version of '0.0.0'.
// +--

if ((empty($app)) || (empty($module))) {return '0.0.0';}

// +--
// | Determine where our data_core_modules_0.xml resides. 
// +--

if ($app == 'core') {

     $xml_file  = $this->globals('core.path_private') . '/core/';
     $xml_file .= $module . '/install/data_core_modules_0.xml';

} elseif ($app == 'pear') {

     $xml_file  = $this->globals('core.path_private');
     $xml_file .= '/pear/install/' . $module . '.xml';

} else {

     $xml_file  = $this->globals('core.path_private');
     $xml_file .= '/apps/' . $app . '/' . $module;
     $xml_file .= '/install/data_core_modules_0.xml';

} // End of if statement.

// +--
// | See if the file exists.  If it doesn't, return a version of
// | '0.0.0'.
// +--

if (!(@file_exists($xml_file))) {return '0.0.0';}

// +--
// | If it does exist, get the contents of the file and parse the
// | XML in it.
// +--

$file_contents = $this->file_read($xml_file);

if (($this->IsError($file_contents)) || (empty($file_contents))) {return '0.0.0';}

$xparsed = $this->xmlparser($file_contents);

if (($this->IsError($xparsed)) || (empty($xparsed['xml.0']['row.0']))) {return '0.0.0';}

// +--
// | Get info from the parsed XML.  If we can't get a version from
// | the file, we return a version of '0.0.0'.
// +--

$parsed = array();

$count = 0;

while (isset($xparsed['xml.0']['row.0']['data.' . $count])) {

     if (!(empty($xparsed['xml.0']['row.0']['data.' . $count . '.att']['column.0']))) {

          $key   = $xparsed['xml.0']['row.0']['data.' . $count . '.att']['column.0'];
          $value = $xparsed['xml.0']['row.0']['data.' . $count];

          $parsed[$key] = $value;

     } // End of if statement.

     $count++;

} // End of while statement.

if (empty($parsed['version'])) {return '0.0.0';}

// +--
// | Return the version.
// +--

return $parsed['version'];

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Startup Tasks                                                    |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: load_pear                                              |
// +------------------------------------------------------------------+

function load_pear () {

// +--
// | This function loads PEAR if we can find it.  It also sets up 
// | include directories.
// +--

static $pear_included;

if ($pear_included) {return 1;}

// +--
// | Set up a few variables.
// +--

$pathpriv = $this->globals('core.path_private');
$pathpear = $pathpriv . '/pear';
$pearphp  = $pathpear . '/PEAR.php';

// +--
// | Return if we don't have enough to go on.
// +--

if (empty($pathpriv))           {return 1;}
if (!(@file_exists($pathpear))) {return 1;}
if (!(@file_exists($pearphp)))  {return 1;}

// +--
// | Setup include dirs.
// +--

if ($this->globals('installer.os') == 'Windows') {

     $include_path  = '.;' . $pathpear;

} else {

     $include_path  = '.:' . $pathpear;

} // End of if statement.

ini_set('include_path',$include_path);

// +--
// | Require PEAR and set the PEAR error reporting level.
// +--

include_once('PEAR.php');

// +--
// | Change our static variable.
// +--

$pear_included = 1;

// +--// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: defeat_register_globals                                |
// +------------------------------------------------------------------+

function defeat_register_globals () {

// +--
// | This function runs the internals of the installer program.
// +--

if ((ini_get('register_globals') == '1') || (ini_get('register_globals') == 'On')) {

     // +--
     // | Handle all global arrays.
     // +--

     if (!(empty($_SERVER)))  {$this->destroy_globals($_SERVER ,'_SERVER'); }
     if (!(empty($_ENV)))     {$this->destroy_globals($_ENV    ,'_ENV');    }
     if (!(empty($_COOKIE)))  {$this->destroy_globals($_COOKIE ,'_COOKIE'); }
     if (!(empty($_GET)))     {$this->destroy_globals($_GET    ,'_GET');    }
     if (!(empty($_POST)))    {$this->destroy_globals($_POST   ,'_POST');   }
     if (!(empty($_FILES)))   {$this->destroy_globals($_FILES  ,'_FILES');  }
     if (!(empty($_REQUEST))) {$this->destroy_globals($_REQUEST,'_REQUEST');}
     if (!(empty($_SESSION))) {$this->destroy_globals($_SESSION,'_SESSION');}

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: destroy_globals                                        |
// +------------------------------------------------------------------+

function destroy_globals ($input = array(),$type = '') {

// +--
// | This function destroys any globals created by a given array.
// +--

foreach ($input as $key => $value) {

     unset(${$key});

} // End of foreach statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: defeat_magic_quotes                                    |
// +------------------------------------------------------------------+

function defeat_magic_quotes () {

// +--
// | This function cleans all form input of slashes and quotes
// | that may have been added by the ini magic_quotes_* values.
// |
// | These ini values can only be changed on the server and 
// | directory levels and their default settings range from server 
// | to server and PHP version to PHP version.
// |
// | This function exists instead of an error message (like with the 
// | 'safe_mode' check) because we can fix the problems associated with 
// | ini values on our own in this function.
// |
// | This code is based on the functions given under the
// | get_magic_quotes_gpc entry in the PHP online manual by 
// | dinesh at dinsoft dot net and an unknown author.  The original
// | source code was offered for free without license.
// +--

// +--
// | If magic_quotes_gpc is On/1 we need to do some work.
// +--

if ((ini_get('magic_quotes_gpc') == 'On') || (ini_get('magic_quotes_gpc') == '1')) {

     // +--
     // | If magic_quotes_sybase is On/1 we need to strip quotes.
     // +--

     if ((ini_get('magic_quotes_sybase') == 'On') || (ini_get('magic_quotes_sybase') == '1')) {

          $_ENV     = $this->defeat_mq_stripquotes($_ENV) ;
          $_GET     = $this->defeat_mq_stripquotes($_GET);
          $_POST    = $this->defeat_mq_stripquotes($_POST);
          $_COOKIE  = $this->defeat_mq_stripquotes($_COOKIE);
          $_SERVER  = $this->defeat_mq_stripquotes($_SERVER) ;
          $_REQUEST = $this->defeat_mq_stripquotes($_REQUEST);

     // +--
     // | If magic_quotes_sybase is Off/0 we need to strip slashes.
     // +--

     } else {

          $_ENV     = $this->defeat_mq_stripslashes($_ENV);
          $_GET     = $this->defeat_mq_stripslashes($_GET);
          $_POST    = $this->defeat_mq_stripslashes($_POST);
          $_COOKIE  = $this->defeat_mq_stripslashes($_COOKIE);
          $_SERVER  = $this->defeat_mq_stripslashes($_SERVER) ;
          $_REQUEST = $this->defeat_mq_stripslashes($_REQUEST);

     } // End of if statement.

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Functions: defeat_mq_stripslashes                                |
// +------------------------------------------------------------------+

function defeat_mq_stripslashes ($data = array()) {

// +--
// | This function aids the 'defeat_magic_quotes' function.
// |
// | This code is based on the functions given under the
// | get_magic_quotes_gpc entry in the PHP online manual by 
// | dinesh at dinsoft dot net and an unknown author.  The original
// | source code was offered for free without license.
// +--

foreach ( $data as $i => $item ) {

     $data[$i] = is_array($item)
                 ? $this->defeat_mq_stripslashes($item)
                 : stripslashes($item);

} // End of foreach statement.

return $data;

} // End of function.

// +------------------------------------------------------------------+
// | Functions: defeat_mq_stripquotes                                 |
// +------------------------------------------------------------------+

function defeat_mq_stripquotes ($data = array()) {

// +--
// | This function aids the 'defeat_magic_quotes' function.
// |
// | This code is based on the functions given under the
// | get_magic_quotes_gpc entry in the PHP online manual by 
// | dinesh at dinsoft dot net and an unknown author.  The original
// | source code was offered for free without license.
// +--

foreach ( $data as $i => $item ) {

     $data[$i] = is_array($item)
                 ? $this->defeat_mq_stripquotes($item)
                 : str_replace('\'\'','\'',$item);

} // End of foreach statement.

return $data;

} // End of function.

// +------------------------------------------------------------------+
// | Function: get_os                                                 |
// +------------------------------------------------------------------+

function get_os () {

// +--
// | Determine the operating system we're running under.  We set to 
// | either 'Windows' or 'Unix' as we need to treat only these two OS 
// | types differently.  If an OS is not 'Windows' it is considered 
// | 'Unix'.
// +--

if (substr(PHP_OS, 0, 3) == 'WIN') {

     $this->globals('installer.os','Windows');

} elseif (PHP_OS == 'HP-UX') {

     $this->globals('installer.os','Unix: HP-UX');

} elseif (PHP_OS == 'AIX') {

     $this->globals('installer.os','Unix: IBM AIX');

} elseif (PHP_OS == 'OSX') {

     $this->globals('installer.os','Unix: Max OSX');

} else {

     $this->globals('installer.os','Unix: Generic');

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: check_php                                              |
// +------------------------------------------------------------------+

function check_php () {

// +--
// | This function checks the PHP environment and filesystem to ensure
// | we are setting the software up in a valid environment.
// +--

// +--
// | The first thing to do is to check and see if the main directory  
// | path this installer needs to write to is writable.  If not, 
// | we have to error out right away with a message instructing 
// | the user what to do.
// +--

$dir  = $this->globals('core.main_path_force');

if (!(is_writable($dir))) {

     $errstr = "

     <p>This script cannot currently write to the directory:</p>

     <p>{$dir}</p>

     <p>This directory needs to have permissions set so that it is 
     writable via the webserver process that executes PHP in order 
     to use this installer script.  To correct the permissions for 
     this directory in order to use this installer script, adjust 
     permissions as follows:</p>

     <p>For Unix/Linux servers, use your FTP client or SSH shell to 
     'chmod' the directory above to a writable level.  This level is 
     typically 'chmod 777'.</p>

     <p>For Windows servers, contact your server administrator and 
     request that they set permissions on the directory above to 
     'Full Control' for the process that PHP runs under.  This needs 
     to be done via Windows Explorer, not the IIS Control Panel.</p>

     <p>Once permissions have been adjusted, access this installer 
     script again.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | The next thing we do is check the license agreement file 
// | (license.pdf) to make sure it exists.
// +--

$dir  = $this->globals('core.main_path_force');
$file = $dir . '/license.pdf';

if (!(@file_exists($file))) {

     $errstr = "

     <p>This script could not locate the file 'license.pdf' in the
     directory:</p>

     <p>{$dir}</p>

     <p>This could be the result of an incomplete upload or file
     extraction during the installation process, or could indicate
     an issue determining the directory from which this script is 
     being executed.</p>

     <p>If the file 'license.pdf' does exist in this directory, you need 
     to edit the scripts 'index.php', 'admin.php' and 'installer.php' 
     and enter a value for the \$main_path_force variable at the top 
     of those scripts.  Follow the instructions in each of those scripts 
     for more information.</p>

     <p>If you have already edited the \$main_path_force variable in 
     those scripts, and are seeing this message again, the value you 
     used for that variable appears to be incorrect.  Please try again.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | Check the PHP version we're running under.
// +--

$required = '4.3.0';
$current  = PHP_VERSION;

$result = $this->check_version($current,$required);

if (!($result)) {

     $errstr = "

     <p>PHP version {$current} is currently installed on this
     webserver.  This program requires PHP version {$required} or
     higher to execute.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | We set 'safe_mode' to 'Off' to ensure we don't run in 'safe_mode'.
// | 'safe_mode' restricts many filesystem operations needed by this
// | script to install and control various components and modules.
// +--

if (ini_get('safe_mode') == 'On') {

     ini_set('safe_mode','Off');

} elseif (ini_get('safe_mode') == '1') {

     ini_set('safe_mode','0');

} // End of if statement.

// +--
// | Make sure 'safe_mode' is off.
// +--

if ((ini_get('safe_mode') == '1') || (ini_get('safe_mode') == 'On')) {

     $errstr = "

     <p>The PHP configuration value for 'safe_mode' is currently set to
     '1' and this script requires a value of '0' to execute.</p>

     <p>This script attempted to change this value at runtime, however
     the current server configuration did not permit the script to
     make this runtime change.  Contact your server administrator
     and request that this PHP configuration value be set to '0' or
     permissions be granted to this script to change the value at
     runtime.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | We set 'magic_quotes_runtime' to 'Off' to ensure we don't cloud
// | up the script with variables from GET/POST/PUT/CLI requests
// | that we don't want or care about.
// +--

if (ini_get('magic_quotes_runtime') == 'On') {

     ini_set('magic_quotes_runtime','Off');

} elseif (ini_get('magic_quotes_runtime') == '1') {

     ini_set('magic_quotes_runtime','0');

} // End of if statement.

// +--
// | Make sure 'magic_quotes_runtime' is off.
// +--

if ((ini_get('magic_quotes_runtime') == '1') || (ini_get('magic_quotes_runtime') == 'On')) {

     $errstr = "

     <p>The PHP configuration value for 'magic_quotes_runtime' is
     currently set to '1' and this script requires a value of '0'
     to execute.</p>

     <p>This script attempted to change this value at runtime, however
     the current server configuration did not permit the script to
     make this runtime change.  Contact your server administrator
     and request that this PHP configuration value be set to '0' or
     permissions be granted to this script to change the value at
     runtime.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | We set 'max_execution_time' to '120' seconds.  This is a very
// | nice to have if the server will let you do it.  We don't check
// | this one as the ability to set 'max_execution_time' is not
// | critical to running the program.
// +--

ini_set('max_execution_time',120);

// +--
// | The PHP variable 'memory_limit' is disabled (set to -1).  This 
// | is very nice to have if the server will let you do it.  We don't 
// | check this one as the ability to set 'memory_limit' is not 
// | critical to running the program.
// +--

ini_set('memory_limit',-1);

// +--
// | Another nice to have is the 'arg_separator.output' PHP ini var.
// | We set 'arg_separator.output' to '&amp;'.
// +--

ini_set('arg_separator.output','&amp;');

// +--
// | Check to make sure the cURL extension is loaded.
// | If it isn't, we error out.
// +--

$curl_error = 0;

if (!(extension_loaded('curl'))) {

     if ((ini_get('enable_dl') != '1') && (ini_get('enable_dl') != 'On')) {

          $curl_error = 1;

     } else {

          if (substr(PHP_OS, 0, 3) == 'WIN') {

               $suffix = '.dll';

          } elseif (PHP_OS == 'HP-UX') {

               $suffix = '.sl';

          } elseif (PHP_OS == 'AIX') {

               $suffix = '.a';

          } elseif (PHP_OS == 'OSX') {

               $suffix = '.bundle';

          } else {

               $suffix = '.so';

          } // End of if statement.

          if ((!(@dl('php_' . $extension . $suffix))) || (!(@dl($extension . $suffix)))) {

               $curl_error = 1;

          } // End of if statement.

     } // End of if statement.

} // End of if statement.

if ($curl_error) {

     $errstr = "

     <p>The cURL PHP extension is not loaded.  This script requires
     the cURL PHP extension to be loaded in order to function properly.</p>

     <p>This script attempted to change this value at runtime, however
     the current server configuration did not permit the script to
     make this runtime change.  Contact your server administrator
     and request that the cURL PHP extension be loaded at run time.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | We set 'file_uploads' to 'On' to ensure we can process 
// | uploads.
// +--

if (ini_get('file_uploads') == 'Off') {

     ini_set('file_uploads','On');

} elseif (ini_get('file_uploads') == '0') {

     ini_set('file_uploads','1');

} // End of if statement.

// +--
// | Make sure 'file_uploads' is on.
// +--

if ((ini_get('file_uploads') == '0') || (ini_get('file_uploads') == 'Off')) {

     $errstr = "

     <p>The PHP configuration value for 'file_uploads' is currently set to
     '0' and this script requires a value of '1' to execute.</p>

     <p>This script attempted to change this value at runtime, however
     the current server configuration did not permit the script to
     make this runtime change.  Contact your server administrator
     and request that this PHP configuration value be set to '0' or
     permissions be granted to this script to change the value at
     runtime.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | Make sure the server's upload temp directory is writable.  
// | We need this for file upload functionality.
// +--

$tempdir = ini_get('upload_tmp_dir');

if (($tempdir) && (!(is_writable($tempdir)))) {

     $errstr = "

     <p>This script cannot currently write to the directory:</p>

     <p>{$tempdir}</p>

     <p>This directory needs to have permissions set so that it is 
     writable via the webserver process that executes PHP in order 
     to upload files using this script.  To correct the permissions 
     for this directory in order to use this installer script, adjust 
     permissions as follows:</p>

     <p>For Unix/Linux servers, use your FTP client or SSH shell to 
     'chmod' the directory above to a writable level.  This level is 
     typically 'chmod 777'.</p>

     <p>For Windows servers, contact your server administrator and 
     request that they set permissions on the directory above to 
     'Full Control' for the process that PHP runs under.  This needs 
     to be done via Windows Explorer, not the IIS Control Panel.</p>

     <p>Once permissions have been adjusted, access this installer 
     script again.</p>

     ";

     $result = $this->RaiseError($errstr);

     return $result;

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: check_version                                          |
// +------------------------------------------------------------------+

function check_version ($current = '0.0.0',$required = '0.0.0') {

// +--
// | This function returns true if our version is at least or greater
// | than the version supplied.  This code was found under the
// | phpversion() manual entry in the PHP manual.
// +--

if ($required == '0.0.0') {return 1;}

// +--
// | Figure out if we're OK.
// +--

list($majorC, $minorC, $editC) = preg_split('/[\/\.\-]/i', $current, 3);
list($majorR, $minorR, $editR) = preg_split('/[\/\.\-]/i', $required, 3);

if ((isset($majorC)) && (isset($minorC)) && (isset($majorR)) && (isset($minorR))) {

if ($majorC > $majorR) {return 1;}
if ($majorC < $majorR) {return 0;}

if ($minorC > $minorR) {return 1;}
if ($minorC < $minorR) {return 0;}

if ((isset($editC)) && (isset($editR))) {

     if ($editC  > $editR)  {return 1;}
     if ($editC  < $editR)  {return 0;}

} // End of if statement.

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Installer Display                                                |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: disp                                                   |
// +------------------------------------------------------------------+

function disp () {

// +--
// | This function displays the installer screen output.
// +--

// +--
// | Define our date for our copyright and our EOL.
// +--

$eol       = $this->globals('installer.eol');

$title_add = '';

if ($this->globals('installer.steptext')) {

     $title_add = ' - ' . $this->xhtml_encode($this->globals('installer.steptext'));

} // End of if statement.

// +--
// | Print the header section.
// +--

print <<<ENDOFTEXT

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" /> 

<style type="text/css" media="all">

body {
     font-family: Verdana, Tahoma, Arial, sans-serif;
     font-size: 11px;
     color: #333333;
     font-weight: normal;
     text-align: left;
     background-color: #F5F5F5;
     margin: 20px;
     font-size: 12px;
     }

a {
     color: #30569D;
     text-decoration: underline;
     font-weight: normal;
     }

a:hover {
     color: #333333;
     text-decoration: underline;
     }

.strong {
     font-weight: bold;
     }

fieldset {
     border: none;
     padding: 0px;
     margin-bottom: 15px;
     }

legend {
     display: none;
     }


label {
     display: none;
     }

fieldset p {
     display: block;
     margin: 0px 0px 8px 0px;
     }

#header {
     border-top: 1px solid #333333;
     border-left: 1px solid #333333;
     border-right: 1px solid #333333;
     width: 620px;
     padding: 0px;
     margin: 0px auto 0px auto;
     background-image: url('//central.kryptronic.com/public/media/header_clickcartpro.png');
     background-position: top left;
     background-repeat: no-repeat;
     height: 50px;
     -moz-border-radius: 8px 8px 0px 0px;
     -webkit-border-radius: 8px 8px 0px 0px;
     border-radius: 8px 8px 0px 0px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     }

#content {
     color: #333333;
     background-color: #FFFFFF;
     border-bottom: 1px solid #333333;
     border-left: 1px solid #333333;
     border-right: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: auto;
     -moz-border-radius: 0px 0px 8px 8px;
     -webkit-border-radius: 0px 0px 8px 8px;
     border-radius: 0px 0px 8px 8px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     line-height: 1.25em;
     }

#pgtitle {
     color: #4E70AE;
     padding: 0px;
     margin: 0px 0px 10px 0px;
     font-weight: bold;
     font-size: 18px;
     }

.formfieldleg {
     border-top: 1px solid #DEDEDE;
     padding-top: 10px;
     font-weight: bold;
     }

.formfieldinstruct {
     color: #30569D;
     font-size: 11px;
     margin: 5px 0px 5px 0px;
     }

#meter {
     width: auto;
     margin: 20px 0px 10px 0px;
     }

p.meter {
     color: #333333;
     display: inline;
     }

p.metercomp {
     background-color: #339933;
     color: #339933;
     display: inline;
     font-weight: bold;
     padding: 5px 0px 5px 0px;
     }

p.meterpend {
     background-color: #CCCCCC;
     color: #CCCCCC;
     display: inline;
     font-weight: bold;
     padding: 5px 0px 5px 0px;
     }

.msgerror {
     color: #FF0000;
     font-weight: bold;
     }

.msgconf {
     color: #339933;
     font-weight: bold;
     }

.hidden {
     display: none;
     }

.formfieldradcb {
     color: inherit;
     background-color: inherit;
     margin-bottom: 4px;
     border: none;
     }

.formfield {
     background-color: #FFFFFF;
     border: 1px solid #8C867B;
     margin: 5px 5px 0px 0px;
     font-family: Arial, Helvetica, sans-serif;
     font-size: 12px;
     padding: 2px;
     }

.formfield:focus {
     background-color: #FFFFDD;
     border: 1px solid #FFCC66;
     }

select.formfield {
     -moz-border-radius: 6px 0px 0px 6px;
     -webkit-border-radius: 6px 0px 0px 6px;
     border-radius: 6px 0px 0px 6px;
     }

input.formfield, textarea.formfield {
     -moz-border-radius: 6px 6px 6px 6px;
     -webkit-border-radius: 6px 6px 6px 6px;
     border-radius: 6px 6px 6px 6px;
     }

.formbutton {
     color: #333333;
     background-color: #DEDEDE;
     padding: 1px;
     margin-top: 5px;
     margin-left: 2px;
     font-weight: bold;
     width: 100px;
     font-size: 11px;
     border: 1px solid #333333;
     -moz-border-radius: 6px 6px 6px 6px;
     -webkit-border-radius: 6px 6px 6px 6px;
     border-radius: 6px 6px 6px 6px;
     }

.formbutton:hover {
     color: #333333;
     background-color: #EFEFEF;
     -moz-border-radius: 6px 6px 6px 6px;
     -webkit-border-radius: 6px 6px 6px 6px;
     border-radius: 6px 6px 6px 6px;
     }

</style>

<title>Software Installer{$title_add}</title>

<script type="text/javascript" src="//central.kryptronic.com/public/jquery/jquery.min.js"></script>
<script type="text/javascript">jQuery.noConflict();</script>

<script type="text/javascript">

jQuery(document).ready(function(){

     jQuery('input:submit').click(function(){

          if (jQuery(this).prop('value') == 'Cancel') {return true;}

          if (jQuery(this).hasClass('disabled')) {return false;}

          jQuery(this).addClass('disabled');

          jQuery(this).prop('value','Please Wait...');

          return true;

     });

ENDOFTEXT;

if ($this->globals('installer.auto_submit')) {print '     jQuery(\'#installer\').submit();' . $eol;}

print <<<ENDOFTEXT

     jQuery('a[rel=\'external\']').prop('target', '_blank');

});

jQuery(window).unload(function() {

     jQuery('input:submit').removeClass('disabled');

});

</script>

</head>

<body>

<div id="header">&nbsp;</div>

<div id="content">

ENDOFTEXT;

// +--
// | Print the page header section.
// +--

$step     = $this->xhtml_encode($this->globals('installer.step'));
$steptext = $this->xhtml_encode($this->globals('installer.steptext'));
$numsteps = $this->xhtml_encode($this->globals('installer.numsteps'));

if (($step) && ($steptext)) {

     print '<div id="pgtitle">Step ' . $step . ' of ';
     print $numsteps . ': ' . $steptext . '</div>' . $eol . $eol;

} elseif (($step === '0') && ($steptext)) {

     print '<div id="pgtitle">' . $steptext . '</div>' . $eol . $eol;

} // End of if statement.

// +--
// | Print our content.
// +--

$content = $this->globals('installer.buffered_output');

print $content;

// +--
// | Print the page footer.
// +--

print <<<ENDOFTEXT

</div>

</body>

</html>

ENDOFTEXT;

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: disp_message                                           |
// +------------------------------------------------------------------+

function disp_message ($message = '',$type = 'ERROR') {

// +--
// | This function prints a message.
// +--

$eol = $this->globals('installer.eol');

// +--
// | If message is blank, return true without printing anything.
// +--

if ($message == '') {return 1;}

// +--
// | Replace full directory paths in the message.
// +--

$pathpriv_quoted = preg_quote($this->globals('core.path_private'),'/');
$pathpub_quoted  = preg_quote($this->globals('core.path_public'),'/');

$message = preg_replace('/' . $pathpriv_quoted . '\//','/',$message);
$message = preg_replace('/' . $pathpub_quoted  . '\//','/',$message);

// +--
// | Encode the message.
// +--

$message = $this->xhtml_encode($message);

// +--
// | Print the message.
// +--

if ($type == 'ERROR') {

     print '<p class="msgerror">' . $message . '</p>' . $eol . $eol;

} else {

     print '<p class="msgconf">' . $message . '</p>' . $eol . $eol;

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: disp_form                                              |
// +------------------------------------------------------------------+

function disp_form ($input = array()) {

// +--
// | This function prints an XHTML form to be used by the installer.
// | 
// | Input is accepted in the form of an array with the following
// | parameters:
// |
// | 'header'   => XHTML header
// |
// | 'step'     => The step to post to.
// |
// | 'supform'  => Optional boolean indicator.  If true the opening 
// |               <form> tag is supressed.  Useful if the header
// |               contains form fields.
// |
// | 'autosub'  => Optional indicator.  If value is 1 this form 
// |               will be auto-submitted.
// |
// | 'fields'   => An array of fields with the following array keys:
// |
// |               'id'       => Form field name.
// |
// |               'name'     => Field display name.
// |
// |               'type'     => Form field type (SELECT, RADIO, HIDDEN
// |                           CHECKBOX, TEXT-REG, TEXT-LONG, PASSWORD)
// |
// |               'desc'     => Pre-formatted XHTML description.
// |
// |               'values'   => An array of values (key = select value,
// |                             value = select display name) for a 
// |                             SELECT, CHECKBOX or RADIO field.
// |
// |               'value'    => A value to use for HIDDEN fields.
// |
// |               'required' => Boolean required indicator.
// +--

$eol = $this->globals('installer.eol');

// +--// | Set up function variables.
// +--

$header  = (isset($input['header'])  ? $input['header']  : '');
$fields  = (isset($input['fields'])  ? $input['fields']  : array());
$step    = (isset($input['step'])    ? $input['step']    : 'Default');
$supform = (isset($input['supform']) ? $input['supform'] : 0);
$autosub = (isset($input['autosub']) ? $input['autosub'] : 0);

// +--
// | Handle the auto-submit form object.
// +--

if ($autosub == 1) {

     $this->globals('installer.auto_submit',1);

} // End of if statement.

// +--
// | Print the form header.
// +--

if ($header) {

     print $header . $eol . $eol;

} // End of if statement.

// +--
// | Print the <form> element and required info if not supressed.
// +--

if (empty($supform)) {

     $insname = $this->globals('installer.script_name');

     print '<form action="' . $insname . '" method="post" id="installer">' . $eol . $eol;

     print '<p>Required fields are marked with a star (*). ';

     if ($autosub == 1) {

          print 'This form should auto-submit itself.  If this does not occur, ';
          print 'click the \'Continue\' button at the bottom of ';
          print 'this page to proceed.</p>' . $eol . $eol;


     } else {

          print 'Click the \'Continue\' button at the bottom of ';
          print 'this page to proceed.</p>' . $eol . $eol;

     } // End of if statement.

} // End of if statement.

// +--
// | Get a list of all of the fields.
// +--

$seen = array();

foreach ($fields as $num => $field) {

     $id = (isset($field['id']) ? $field['id'] : '');

     $seen[$id] = 1;

} // End of foreach statement.

// +--
// | Print the HIDDEN form fields.
// +--

foreach ($fields as $num => $field) {

     $id       = (isset($field['id'])       ? $field['id']       : '');
     $name     = (isset($field['name'])     ? $field['name']     : '');
     $type     = (isset($field['type'])     ? $field['type']     : '');
     $desc     = (isset($field['desc'])     ? $field['desc']     : '');
     $values   = (isset($field['values'])   ? $field['values']   : array());
     $value    = (isset($field['value'])    ? $field['value']    : '');
     $required = (isset($field['required']) ? $field['required'] : '');

     if ($type == 'HIDDEN') {

          $pid    = $this->xhtml_encode($id);
          $pvalue = $this->xhtml_encode($value);

          print '<p class="hidden"><input type="hidden" name="' . $pid . '" ';
          print 'id="' . $pid . '" value="' . $pvalue . '" /></p>' . $eol . $eol;

     } // End of if statement.

} // End of foreach statement.

// +--
// | Print the ALL OTHER form fields.
// +--

foreach ($fields as $num => $field) {

     $id       = (isset($field['id'])       ? $field['id']       : '');
     $name     = (isset($field['name'])     ? $field['name']     : '');
     $type     = (isset($field['type'])     ? $field['type']     : '');
     $desc     = (isset($field['desc'])     ? $field['desc']     : '');
     $values   = (isset($field['values'])   ? $field['values']   : array());
     $value    = (isset($field['value'])    ? $field['value']    : '');
     $required = (isset($field['required']) ? $field['required'] : '');

     $req = ''; if ($required) {$req = '*';}

     $pvalue = $this->make_value($id);

     $pid    = $this->xhtml_encode($id);
     $pname  = $this->xhtml_encode($name);

     $xpid   = $pid;

     if (($type == 'CHECKBOX') || ($xpid == 'RADIO')) {$xpid .= '--1';}

     if ($type != 'HIDDEN') {

          print '<fieldset>' . $eol . $eol;

          print '<legend class="strong"><label for="' . $xpid . '">' . $pname . $req;
          print '</label></legend>' . $eol . $eol;

          print '<p class="formfieldleg">' . $pname . $req . '</p>' . $eol . $eol;

          print '<div class="formfieldinstruct">' . $desc . '</div>' . $eol . $eol;

          if (($type == 'TEXT-REG') || ($type == 'TEXT-LONG') || ($type == 'PASSWORD')) {

               $pvalue = $this->xhtml_encode($pvalue);

               $size  = '25';   if ($type == 'TEXT-LONG')  {$size = '50';}
               $xtype = 'text'; if ($type == 'PASSWORD')   {$xtype = 'password';}

               print '<input class="formfield" type="' . $xtype . '" ';

               if ($type == 'PASSWORD') {print 'autocomplete="off" ';}

               print 'name="' . $pid . '" id="' . $pid . '" value="';
               print $pvalue . '" size="' . $size . '" />' . $eol . $eol;

          } else {

               if (is_array($pvalue)) {$pvalue = array_flip($pvalue);} else {$pvalue = array($pvalue => 1);}

               if (!(empty($values))) {

                    $count   = 0;
                    $pvalues = array();

                    $made_checked = 0;

                    foreach ($values as $xkey => $xvalue) {

                         $count++;

                         $checked = 0; if (array_key_exists($xkey,$pvalue)) {$checked = 1; $made_checked = 1;}

                         $pvalues[] = array('value'   => $xkey,
                                            'display' => $this->xhtml_encode($xvalue),
                                            'checked' => $checked,
                                            'xid'     => $id . '--' . $count);

                    } // End of foreach statement.

                    if ((!($made_checked)) && ($type == 'RADIO')) {$pvalues[0]['checked'] = 1;}

                    if ($type == 'SELECT') {

                          print '<select class="formfield" name="' . $pid . '" id="' . $pid . '">' . $eol;

                          foreach ($pvalues as $num => $xv) {

                               $checked = ''; if ($xv['checked']) {$checked = ' selected="selected"';}

                               print '<option value="' . $xv['value'] . '" ';
                               print $checked . '>' . $xv['display'] . '</option>' . $eol;

                          } // End of foreach statement.

                          print '</select>' . $eol . $eol;

                    } elseif ($type == 'CHECKBOX') {

                          foreach ($pvalues as $num => $xv) {

                               $checked = ''; if ($xv['checked']) {$checked = ' checked="checked"';}

                               print '<p><input class="formfieldradcb" type="checkbox" name="' . $pid . '[]" ';
                               print 'id="' . $xv['xid'] . '" value="' . $xv['value'] . '"';
                               print $checked . ' />' . ' ' . $xv['display'] . '</p>' . $eol;

                          } // End of foreach statement.

                    } elseif ($type == 'RADIO') {

                          foreach ($pvalues as $num => $xv) {

                               $checked = ''; if ($xv['checked']) {$checked = ' checked="checked"';}

                               print '<p><input class="formfieldradcb" type="radio" name="' . $pid . '" ';
                               print 'id="' . $xv['xid'] . '" value="' . $xv['value'] . '"';
                               print $checked . ' />' . ' ' . $xv['display'] . '</p>' . $eol;

                          } // End of foreach statement.

                    } // End of if statement.

               } // End of if statement.

          } // End of if statement.

          print '</fieldset>' . $eol . $eol;

     } // End of if statement.

} // End of foreach statement.

// +--
// | Print our license_agree, config_password and step fields
// | if they weren't seen.
// +--

if (!(array_key_exists('license_agree',$seen))) {

     $value = $this->globals('installer_cgi.license_agree');

     if (is_array($value)) {$value = 1;}

     $value = $this->xhtml_encode($value);

     print '<p class="hidden"><input type="hidden" name="license_agree" ';
     print 'id="license_agree" value="' . $value . '" /></p>' . $eol . $eol;

} // End of if statement.

if (!(array_key_exists('config_password',$seen))) {

     $value = $this->xhtml_encode($this->globals('installer_cgi.config_password'));

     print '<p class="hidden"><input type="hidden" name="config_password" ';
     print 'id="config_password" value="' . $value . '" /></p>' . $eol . $eol;

} // End of if statement.

if (!(array_key_exists('step',$seen))) {

     print '<p class="hidden"><input type="hidden" name="step" ';
     print 'id="step" value="' . $step . '" /></p>' . $eol . $eol;

} // End of if statement.

if (($autosub == 1) && (!(array_key_exists('auto_submit',$seen)))) {

     print '<p class="hidden"><input type="hidden" name="auto_submit" ';
     print 'id="auto_submit" value="1" /></p>' . $eol . $eol;

} // End of if statement.

// +--
// | Print the form footer.
// +--

print <<<ENDOFTEXT

<p><input class="formbutton" type="submit" name="SUBMIT" id="SUBMIT" value="Continue" /></p>

</form>

ENDOFTEXT;

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | XML Functions                                                    |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: centserv_req                                           |
// +------------------------------------------------------------------+

function centserv_req ($input = array()) {

// +--
// | This routine makes an XML request to the central
// | server.  It accepts an array as input as follows:
// |
// | 'xml'     => The contents of the XML request in the form of an
// |              array.  
// |
// | 'dtd'    => The DTD to use for the request.
// |
// | 'method'  => The method being activated on the central
// |              server.
// |
// | 'apiver'  => The API version to use.  Defaults to 1.0.
// |
// | 'license' => An optional license to use for authentication 
// |              instead of the global value (handy for registration
// |              requests).
// +--

// +--
// | Set our default function values.
// +--

$xml    = (isset($input['xml'])      ? $input['xml']     : array());
$dtd    = (isset($input['dtd'])      ? $input['dtd']     : '');
$method = (isset($input['method'])   ? $input['method']  : '');
$apiver = (isset($input['apiver'])   ? $input['apiver']  : '1.0');
$license = (isset($input['license']) ? $input['license'] : '');

unset($input);

// +--
// | Make sure our XML was submitted.  If we don't have a
// | XML request, we return a PEAR error.
// +--

if ((empty($dtd)) || (empty($method))) {

     $message = "A request was made to connect to the 
                 central server, however the request did not 
                 contain an a valid DTD or method.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Figure out which license we'll use.
// +--

$lickey = $this->globals('core.reg_lickey');

if (!(empty($license))) {$lickey = $license;}

// +--
// | Formulate the request.
// +--

$eol        = $this->globals('installer.eol');

$post_url   = 'http://central.kryptronic.com/khxc/central.php';

$app_url    = $this->globals('core.url_nonssl') . '/';
$app_url   .= $this->globals('core.script_frontend');
$app_url    = $this->xhtml_encode($app_url);

$reg_lickey = $this->xhtml_encode($lickey);

$xmlrequest  = '<?xml version="1.0" encoding="utf-8"?>' . $eol;

$xmlrequest .= '<!DOCTYPE xml SYSTEM "http://central.kryptronic.com/public/dtd/';
$xmlrequest .= $dtd . '">' . $eol;

// +--
// | Build out an XML array and formulate it as XML.
// +--

if (!(empty($xml))) {$xmlbuild = $xml;} else {$xmlbuild = array();}

$xmlbuild['xml.0']['method.0']      = $method;
$xmlbuild['xml.0']['api.0']         = $apiver;
$xmlbuild['xml.0']['reg_lickey.0']  = $reg_lickey;
$xmlbuild['xml.0']['app_url.0']     = $app_url;

$result = $this->xmlbuild($xmlbuild);

if ($this->IsError($result)) {

     $message  = "The installer could not formulate an XML request for 
                  the central server.  Error Information: ";

     $message .=  $result->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

$xmlrequest .= $result;

// +--
// | Send the request.
// +--

$result = $this->exec_curl(array('url'  => $post_url,
                                 'type' => 'POST',
                                 'mode' => 'HTTP',
                                 'data' => array('xmlrequest' => $xmlrequest)));

if ($this->IsError($result)) {

     $message  = "The installer could not communicate with the 
                  central server.  This may be the result of an Internet 
                  connectivity problem.  Error Information: ";

     $message .=  $result->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Parse the result.
// +--

$parsed = $this->xmlparser($result);

// +--
// | Handle errors.
// +--

if ($this->IsError($parsed)) {

     $message  = "The installer failed to receive an XML response from the 
                  central server.  Error Information: ";

     $message .=  $parsed->GetMessage();

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Handle the response.
// +--

if (!(IsSet($parsed['xml.0']['status.0']))) {

     $message = "The installer failed to receive an XML response from the 
                  central server.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

if ($parsed['xml.0']['status.0'] != 'OK') {

     $message = "The central server did not approve the request 
                 submitted.  The server replied with this message: 
                 {$parsed['xml.0']['message.0']}";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Return the parsed result.
// +--

return $parsed;

} // End of function.

// +------------------------------------------------------------------+
// | Function: xmlget_public                                          |
// +------------------------------------------------------------------+

function xmlget_public ($file = '') {

// +--
// | This function returns an array of XML data from a public
// | XML file on the central server.
// +--

$xmlresponse = array();

if (empty($file)) {return $xmlresponse;}

$xmldata = $this->exec_curl(array('url'  => 'http://central.kryptronic.com/public/xml/' . $file,
                                  'type' => 'GET',
                                  'mode' => 'HTTP',
                                  'data' => ''));

if ($this->IsError($xmldata)) {return $xmldata;}

$xmlresponse = $this->xmlparser($xmldata);

return $xmlresponse;

} // End of function.

// +------------------------------------------------------------------+
// | Function: xmlparser                                              |
// +------------------------------------------------------------------+

function xmlparser ($xmldata = '') {

// +--
// | This function creates an array of items from an XML string.  This
// | code is based very loosely on the parser given under the XML entry
// | in the PHP online manual by vladson at pc-labs dot info and 
// | modified by aerik at wikidweb dot com.  The original source code
// | was offered for free without license.
// +--

if (!(isset($xmldata))) {

     $message = "An incomplete request to parse XML into an array
                 was received.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Do the dirty work...
// +--

$xmlarray  = array();

// +--
// | Define the regular expressions for elements and attributes.
// +--

$regex_elements   = '/<([-\w]+)\s*([^\/>]*)\s*(?:\/>|>(.*?)<\/\s*\\1\s*>)/s';
$regex_attributes = '/([-\w]+)=(?:"|\')([^"\']*)(:?"|\')/';

// +--
// | Retrieve the element information.
// +--
 
preg_match_all($regex_elements, $xmldata, $elements);

foreach ($elements[1] as $ie => $ne) {

     $iec = '0';

     while (IsSet($xmlarray[$ne . '.' . $iec])) {$iec++;}

     if ($elements[1][$ie]) {

          $xmlarray[$ne . '.' . $iec] = '';

     } // End of if statement.

     // +--
     // | Retrieve the attribute information for the element.
     // +--

     if ($attributes = trim($elements[2][$ie])) {

          preg_match_all($regex_attributes, $attributes, $att);

          foreach ($att[1] as $ia => $na) {

               $iac = '0';

               while (IsSet($xmlarray[$ne . '.' . $iec . '.' . 'att'][$att[1][$ia] . '.' . $iac])) {$iac++;}

               $xmlarray[$ne . '.' . $iec . '.' . 'att'][$att[1][$ia] . '.' . $iac] = $this->xhtml_decode($att[2][$ia]);

          } // End of foreach statement.

     } // End of if statement.

     // +--
     // | Retrieve the text information for the element and process
     // | subelements separately.
     // +--

     $cdend = strpos($elements[3][$ie],'<');

     if ($cdend > '0') {

          $xmlarray[$ne . '.' . $iec] = substr($elements[3][$ie],0,$cdend -1);

     } // End of if statement.

     if (preg_match($regex_elements, $elements[3][$ie])) {

          $xmlarray[$ne . '.' . $iec] = $this->xmlparser($elements[3][$ie]);

     } elseif (isset($elements[3][$ie])) {

          $xmlarray[$ne . '.' . $iec] = $this->xhtml_decode($elements[3][$ie]);

     } // End of if statement.

} // End of foreach statement.

unset($elements);

// +--
// | Return our array.
// +--

return $xmlarray;

} // End of function.

// +------------------------------------------------------------------+
// | Function: xmlbuild                                               |
// +------------------------------------------------------------------+

function xmlbuild ($xmldata = array()) {

// +--
// | This function builds an XML data structure from an array.
// +--

if ((!(isset($xmldata))) || (!(is_array($xmldata)))) {

     $message = "An incomplete request to make XML from an array
                 was received.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

$eol = $this->globals('installer.eol');

// +--
// | Start with a blank XML string.
// +--

$xmlstring = '';

// +--
// | Build the XML structure.
// +--

foreach ($xmldata as $key => $value) {

     // +--
     // | Skip attributes array keys.
     // +--

     if (!(preg_match('/^(.*?)\.(.*?)\.att$/',$key))) {

          $key1 = preg_replace('/^(.*?)\.(.*?)$/','\\1',$key);
          $key2 = preg_replace('/^(.*?)\.(.*?)$/','\\1',$key);

          // +--
          // | Handle keys where attributes exist.
          // +--

          if (array_key_exists($key . '.att',$xmldata)) {

               $att = $xmldata[$key . '.att'];

               foreach ($att as $attname => $attvalue) {

                    $attname  = preg_replace('/^(.*?)\.(.*?)$/','\\1',$attname);
                    $key1    .= ' ' . $attname . '="';
                    $key1    .= $this->xhtml_encode($attvalue) . '"';

               } // End of foreach statement.

          } // End of if statement.

          // +--
          // | Build the XML data structure with the calculated
          // | key.
          // +--

          if (is_array($value)) {

               $xmlstring .= '<'  . $key1 . '>' . $eol;
               $xmlstring .= $this->xmlbuild($value);
               $xmlstring .= '</' . $key2 . '>' . $eol;

          } else {

               $xmlstring .= '<'  . $key1 . '>';
               $xmlstring .= $this->xhtml_encode($value);
               $xmlstring .= '</' . $key2 . '>' . $eol;

          } // End of if statement.

     } // End of if statement.

} // End of foreach statement.

// +--
// | Return our string.
// +--

return $xmlstring;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | CGI and XHTML Functions                                          |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: formdata_array                                         |
// +------------------------------------------------------------------+

function formdata_array ($input = array()) {

// +--
// | This function returns an array of formdata values.  It accepts
// | input in an array with the following format:
// |
// | key:   The formdata field.
// | value: Boolean indicating required status.
// |
// | This function will return an error object if any required fields
// | are not complete.
// +--

$result = array();

if (empty($input)) {return $result;}

$reqnotcomp = 0;

foreach ($input as $key => $value) {

     $xvalue = $this->globals('installer_cgi.' . $key);

     if (!(isset($xvalue))) {$xvalue = '';}

     $result[$key] = $xvalue;

     if ((empty($result[$key])) && (!(empty($value)))) {$reqnotcomp++;}

} // End of foreach statement.

if ($reqnotcomp) {

     $message = "You did not complete all of the required fields before 
                 clicking the 'Continue' button.  Please try again.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Return the result array.
// +--

return $result;

} // End of function.

// +------------------------------------------------------------------+
// | Function: load_formdata                                          |
// +------------------------------------------------------------------+

function load_formdata () {

// +--
// | This function loads formdata from CGI requests.
// +--

if (!(empty($_POST)))  {$this->create_globals($_POST ,'_POST'); }
if (!(empty($_GET)))   {$this->create_globals($_GET  ,'_GET'); }

} // End of function.

// +------------------------------------------------------------------+
// | Function: create_globals                                         |
// +------------------------------------------------------------------+

function create_globals ($input = array(),$type = '') {

// +--
// | This routine creates CGI global variables.
// +--

foreach ($input as $name => $value) {

     if (is_array($value)) {

          $x_value = array();

          foreach ($value as $x_num => $x_val) {

               $x_value[$x_num] = $this->xhtml_decode($x_val);

          } // End of if statement.

          $value = $x_value;

     } else {

          $value = $this->xhtml_decode($value);

     } // End of if statement.

     $this->globals('installer_cgi.' . $name,$value);

} // End of foreach statement.

unset($input);

} // End of function.

// +------------------------------------------------------------------+
// | Function: xhtml_decode                                           |
// +------------------------------------------------------------------+

function xhtml_decode ($string = '') {

// +--
// | This function decodes XHTML strings.
// +--

return $this->xhtml_translate($string,'DECODE');

} // End of function.

// +------------------------------------------------------------------+
// | Function: xhtml_encode                                           |
// +------------------------------------------------------------------+

function xhtml_encode ($string = '') {

// +--
// | This function encodes XHTML strings.
// +--

return $this->xhtml_translate($string,'ENCODE');

} // End of function.

// +------------------------------------------------------------------+
// | Function: xhtml_translate                                        |
// +------------------------------------------------------------------+

function xhtml_translate ($string = '', $encdec = 'ENCODE') {

// +--
// | This function encodes XHTML strings replacing ASCII entities
// | with XHTML entities.  It accepts two paramters: 
// |
// | string => The string to encode or decode
// |
// | encdec => A string 'ENCODE' or 'DECODE' to let this function
// |           know which action to perform.
// +--

static $trans_encode;
static $trans_decode;

if ((!($trans_encode)) || (!($trans_decode))) {

      $trans = get_html_translation_table(HTML_ENTITIES, ENT_QUOTES);

      foreach ($trans as $key => $value) {

           $trans[$key]    = '&#' . ord($key) . ';';

     } // End of foreach statement.

     $trans[chr(38)] = '&';
     $trans['$']     = '&#36;';

     $trans_encode = $trans;
     $trans_decode = array_flip($trans);

     if ($this->debug) {$this->debugger("xhtml_translate: XHTML transalation tables built.");}

} // End of if statement.

if (($string) && ($encdec == 'ENCODE')) {

     $find = '&(?![A-Za-z]{0,4}\w{2,3};|#[0-9]{2,3};)';

     $string = preg_replace('/' . $find . '/','&#38;',strtr($string,$trans_encode));

} elseif (($string) && ($encdec == 'DECODE')) {

     $string = preg_replace('/&nbsp;/',' ',$string);
     $string = preg_replace('/&#38;/','&',strtr($string,$trans_decode));

} // End of if statement.

// +--
// | Return the string.
// +--

return $string;

} // End of function.

// +------------------------------------------------------------------+
// | Function: make_value                                             |
// +------------------------------------------------------------------+

function make_value ($id = '') {

// +--
// | This function determines the correct value to use for a form
// | field.
// +--

if (empty($id)) {return '';}

// +--
// | First get the CGI value.  Return that if it's true.
// +--

$value = $this->globals('installer_cgi.' . $id);

if (!(empty($value))) {return $value;}

// +--
// | Return blank if this is the password field.  We don't want
// | to pre-populate that field.
// +--

if ($id == 'config_password') {return '';}

// +--
// | Change our ID so it's core-compliant.
// +--

$id = preg_replace('/^config\_/','core.',$id);

// +--
// | Next get the core global value.  Return that if it's true.
// +--

$value = $this->globals($id);

if (!(empty($value))) {return $value;}

// +--
// | Next see if we can guess the value.  Return that if it's true.
// +--

$value = $this->guess_value($id);

if (!(empty($value))) {return $value;}

// +--
// | Return blank otherwise.
// +--

return '';

} // End of function.

// +------------------------------------------------------------------+
// | Function: guess_value                                            |
// +------------------------------------------------------------------+

function guess_value ($input = '') {

// +--
// | This function guesses what should be the value of a variable.
// +--

$variable  = $input;
$value     = '';

// +--
// | Set a temporary value for $_SERVER['SCRIPT_NAME'] in case
// | PHP is running as a CGI and it's set to 'php.cgi'.
// +--

$server_script_name = '';

if (IsSet($_SERVER['SCRIPT_NAME'])) {

     if (!(preg_match('/php\.cgi/', $_SERVER['SCRIPT_NAME']))) {

          $server_script_name = $_SERVER['SCRIPT_NAME'];

     } // End of if statement.

} // End of if statement.

// +--
// | Switch though our various variables.
// +--

switch ($variable) {

// +--
// | Public Path.
// +--

     case "core.path_public":
          
          $value = $this->globals('core.main_path_force');

          break;

// +--
// | Private Path.
// +--

     case "core.path_private":

          if (IsSet($_SERVER['DOCUMENT_ROOT'])) {

               $value = dirname($_SERVER['DOCUMENT_ROOT']) . '/core-private';

          } else {

               if (@file_exists(__FILE__)) {

                    $pathf = __FILE__;

               } elseif  (IsSet($_SERVER['PATH_TRANSLATED'])) {

                    $pathf = $_SERVER['PATH_TRANSLATED'];

               } elseif (IsSet($_SERVER['SCRIPT_FILENAME'])) {

                    $pathf = $_SERVER['SCRIPT_FILENAME'];

               } // End of if statement.

               if  (IsSet($_SERVER['PATH_INFO'])) {

                    $pathp = $_SERVER['PATH_INFO'];

               } elseif ($server_script_name) {

                    $pathp = $server_script_name;

               } elseif (IsSet($_SERVER['PHP_SELF'])) {

                    $pathp = $_SERVER['PHP_SELF'];

               } // End of if statement.

               if (($pathf) && ($pathp)) {

                    $pathf   = str_replace('\\\\','/',$pathf);
                    $pathf   = str_replace('\\','/',$pathf);

                    $pathp   = str_replace('\\\\','/',$pathp);
                    $pathp   = str_replace('\\','/',$pathp);

                    $find    = '/' . preg_replace('/\//', '\\/', $pathp) . '/';
                    $replace = '';
                    $value   = preg_replace($find, $replace, $pathf);

                    $value   = dirname($value) . '/core-private';

               } // End of if statement.

          } // End of if statement.

          break;

// +--
// | Frontend Script Name.
// +--

     case "core.script_frontend":

          if (@file_exists($this->globals('core.main_path_force') . '/index.php')) {

               $value = 'index.php'; 

          } // End of if statement.

          break;

// +--
// | Backend Script Name.
// +--

     case "core.script_backend":

          if (@file_exists($this->globals('core.main_path_force') . '/admin.php')) {

               $value = 'admin.php'; 

          } // End of if statement.

          break;

// +--
// | Non-SSL URL
// +--

     case "core.url_nonssl":

          if  (IsSet($_SERVER['SERVER_NAME'])) {

               $urln = $_SERVER['SERVER_NAME'];

          } elseif (IsSet($_SERVER['HTTP_HOST'])) {

               $urln = $_SERVER['HTTP_HOST'];

          } // End of if statement.

          if  (IsSet($_SERVER['PATH_INFO'])) {

               $urlp = $_SERVER['PATH_INFO'];

          } elseif ($server_script_name) {

               $urlp = $server_script_name;

          } elseif (IsSet($_SERVER['PHP_SELF'])) {

               $urlp = $_SERVER['PHP_SELF'];

          } // End of if statement.

          if (($urln) && ($urlp)) {

          $insname = $this->globals('installer.script_name');
          $insname = preg_quote($insname,'/');

          $urlp  = preg_replace('/\/' . $insname . '/', '', $urlp);

          $value = 'http://' . $urln . $urlp;

          } // End of if statement.       

          break;

// +--
// | SSL URL (Same as Non-SSL URL)
// +--

     case "core.url_ssl":

          if  (IsSet($_SERVER['SERVER_NAME'])) {

               $urln = $_SERVER['SERVER_NAME'];

          } elseif (IsSet($_SERVER['HTTP_HOST'])) {

               $urln = $_SERVER['HTTP_HOST'];

          } // End of if statement.

          if  (IsSet($_SERVER['PATH_INFO'])) {

               $urlp = $_SERVER['PATH_INFO'];

          } elseif ($server_script_name) {

               $urlp = $server_script_name;

          } elseif (IsSet($_SERVER['PHP_SELF'])) {

               $urlp = $_SERVER['PHP_SELF'];

          } // End of if statement.

          if (($urln) && ($urlp)) {

          $insname = $this->globals('installer.script_name');
          $insname = preg_quote($insname,'/');

          $urlp  = preg_replace('/\/' . $insname . '/', '', $urlp);

          $value = 'http://' . $urln . $urlp;

          } // End of if statement.       

          break;

// +--
// | Database type.
// +--

     case "core.port_ssl":

          $value = '443';

          break;

// +--
// | Cookie Domain Non-SSL
// +--

     case "core.cookie_domain_nonssl":

          $path = '/' . preg_replace('/^(http|https)\:\/\/([\d\w.]+)\//i','',$this->globals('core.url_nonssl'));
          $path = preg_quote($path,'/');

          $urln = $this->globals('core.url_nonssl');
          $urln = preg_replace('/' . $path . '$/','',$urln);
          $urln = preg_replace('/^(http|https)\:\/\//','',$urln);

          $num    = '(\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])';
          $match  = '/^'  . $num;
          $match .= '\\.' . $num;
          $match .= '\\.' . $num;
          $match .= '\\.' . $num . '$/';

          if (($urln) && (!(preg_match($match, $urln)))) {  

               $tld  = '';

               $tlds = $this->xmlget_public('install_tlds.xml');

               $count = '0';

               while (IsSet($tlds['xml.0']['tld.' . $count])) {

                    $tldsvalue = $tlds['xml.0']['tld.' . $count];

                    $count++;

                    if (!($tld)) {

                         $match = preg_replace('/\./','\\.',$tldsvalue); 

                         $match = '/' . $match . '$/';

                         if (preg_match($match, $urln)) {

                              $tld = $tldsvalue;

                         } // End of if statement.

                    } // End of if statement.

               } // End of while statement.

               if ($tld) {

                    $tldtemp = preg_replace('/\./','\.',$tld);

                    $find  = '/' . $tldtemp . '.*?/';

                    $urln  = preg_replace($find,'',$urln);

                    $array = explode('.', $urln);

                    $array = array_reverse($array);

                    $urln  = $array['0'];

                    $value = '.' . $urln . $tld;

               } // End of if statement. 

          } // End of if statement. 

          break;

// +--
// | Cookie Path Non-SSL
// +--

     case "core.cookie_path_nonssl":

          $value = '/' . preg_replace('/^(http|https)\:\/\/([\d\w.]+\/)/i','',$this->globals('core.url_nonssl'));

          if ($value == '/' . $this->globals('core.url_nonssl')) {$value = '/';}

          break;

// +--
// | Cookie Domain SSL
// +--

     case "core.cookie_domain_ssl":

          $path = '/' . preg_replace('/^(http|https)\:\/\/([\d\w.]+)\//i','',$this->globals('core.url_ssl'));
          $path = preg_quote($path,'/');

          $urln = $this->globals('core.url_ssl');
          $urln = preg_replace('/' . $path . '$/','',$urln);
          $urln = preg_replace('/^(http|https)\:\/\//','',$urln);

          $num    = '(\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])';
          $match  = '/^'  . $num;
          $match .= '\\.' . $num;
          $match .= '\\.' . $num;
          $match .= '\\.' . $num . '$/';

          if (($urln) && (!(preg_match($match, $urln)))) {  

               $tld  = '';

               $tlds = $this->xmlget_public('install_tlds.xml');

               $count = '0';

               while (IsSet($tlds['xml.0']['tld.' . $count])) {

                    $tldsvalue = $tlds['xml.0']['tld.' . $count];

                    $count++;

                    if (!($tld)) {

                         $match = preg_replace('/\./','\\.',$tldsvalue); 

                         $match = '/' . $match . '$/';

                         if (preg_match($match, $urln)) {

                              $tld = $tldsvalue;

                         } // End of if statement.

                    } // End of if statement.

               } // End of while statement.

               if ($tld) {

                    $tldtemp = preg_replace('/\./','\.',$tld);

                    $find  = '/' . $tldtemp . '.*?/';

                    $urln  = preg_replace($find,'',$urln);

                    $array = explode('.', $urln);

                    $array = array_reverse($array);

                    $urln  = $array['0'];

                    $value = '.' . $urln . $tld;

               } // End of if statement. 

          } // End of if statement. 

          break;

// +--
// | Cookie Path SSL
// +--

     case "core.cookie_path_ssl":

          $value = '/' . preg_replace('/^(http|https)\:\/\/([\d\w.]+\/)/i','',$this->globals('core.url_ssl'));

          if ($value == '/' . $this->globals('core.url_ssl')) {$value = '/';}

          break;

// +--
// | Database type.
// +--

     case "core.db_dbtype":

          $value = 'mysql';

          break;

// +--
// | Database hostname.
// +--

     case "core.db_hostname":

          $value = 'localhost'; 

          break;

// +--
// | Mail type.
// +--

     case "core.mail_mailtype":

          $value = 'smtp'; 

          break;

// +--
// | Mail sendmail path.
// +--

     case "core.mail_sendmail":

          $value = '/usr/sbin/sendmail'; 

          break;

// +--
// | Mail hostname.
// +--

     case "core.mail_host":

          $value = 'localhost'; 

          break;

// +--
// | Mail port.
// +--

     case "core.mail_port":

          $value = '25'; 

          break;

// +--
// | Default case returns blank value.
// +--

     default:

          $value = '';

          break;

} // End of switch statement.

return $value;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | File Functions                                                   |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: file_copy                                              |
// +------------------------------------------------------------------+

function file_copy ($input = array()) {

// +--
// | This routine copies a file from one location to another.
// | It accepts the following array keys as input:
// |
// | source   ->  The full filesystem path to the source file.
// |
// | dest     ->  The full filesystem path to the destination
// |              file.  If this file does not exist, it
// |              will be created.// |
// | Optional parameters:
// |
// | replace  ->  An array of keys (find string) and values (replace
// |              string) to use for file copies.
// +--

// +--
// | Set our default function values.
// +--

$source  = (isset($input['source'])  ? $input['source']  : '');
$dest    = (isset($input['dest'])    ? $input['dest']    : '');
$replace = (isset($input['replace']) ? $input['replace'] : '');

unset($input);

// +--
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$source = preg_replace('/\.\./','',$source);
$dest   = preg_replace('/\.\./','',$dest);

// +--
// | If $source or $dest is blank, we return an error.
// +--

if ((!($source)) || (!($dest))) {

     $message = "The file_copy() function was accessed with either 
                 a blank source or blank destination parameter.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | First read the file in.
// +--

$file_contents = $this->file_read($source);

if ($this->IsError($file_contents)) {return $file_contents;}

// +--
// | Do optional replacements.
// +--

if ((is_array($replace)) && (!(empty($replace)))) {

     foreach ($replace as $strfind => $strrpl) {

          $quoted_strfind = preg_quote($strfind,'/');
          $file_contents  = preg_replace('/' . $quoted_strfind . '/',$strrpl,$file_contents);

     } // End of foreach statement.

} // End of if statement.

// +--
// | Then write the contents out.
// +--

$result = $this->file_write(array('name' => $dest,
                                  'data' => $file_contents));

if ($this->IsError($result)) {return $result;}

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: file_read                                              |
// +------------------------------------------------------------------+

function file_read ($file = '') {

// +--
// | This routine reads a file into a data string and returns the
// | data to the caller.
// |
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$file = preg_replace('/\.\./','',$file);

// +--
// | If $file is blank, we return an error.
// +--

if (!($file)) {

     $message = "The file_read() function was accessed with a blank file name.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Figure out if we have a remote file request.  If we do we
// | retrieve the file using the exec_curl function.
// +--

if (preg_match('/^http\:\/\//', $file)) {

     $mode = 'HTTP';

} elseif (preg_match('/^https\:\/\//', $file)) {

     $mode = 'HTTPS';

} else {

     $mode = 'FILE';

} // End of if statement.

// +--
// | Use the exec_curl function for remote files.
// +--

if (($mode == 'HTTP') || ($mode == 'HTTPS')) {

     $file_contents = $this->exec_curl(array('url' => $file,
                                             'type' => 'GET',
                                             'mode' => $mode,
                                             'data' => ''));

     if ($this->IsError($file_contents)) {return $file_contents;}

     return $file_contents;

// +--
// | Otherwise this file appears to exist on the filesystem so 
// | we read it in normally.  $mode == 'FILE' here.
// +--

} else {

     // +--
     // | If the destination file does not exist we error out.
     // +--

     if (!(@file_exists($file))) {

          $file = $this->paths_strip($file);

          $message = "The file_read() function was unable
                      to locate the file requested.  File: {$file}";

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

     // +--
     // | Read the file into a variable.
     // +--

     $file_contents = @file_get_contents($file);

     if ((!($file_contents)) && (!($file_contents === ''))) {

          $file = $this->paths_strip($file);

          $message = "The file_read() function was unable
                      to read the file requested.  File: {$file}";

          $result = $this->RaiseError($message);

          return $result;

     } // End of if statement.

     // +--
     // | Return the file contents.
     // +--

     return $file_contents;

} // End of if statement.

} // End of function.

// +------------------------------------------------------------------+
// | Function: file_write                                             |
// +------------------------------------------------------------------+

function file_write ($input = array()) {

// +--
// | This routine writes $input['data'] to file $input['name'].
// +--

// +--
// | Set our default function values.
// +--

$name = (isset($input['name']) ? $input['name'] : '');
$data = (isset($input['data']) ? $input['data'] : '');

unset($input);

// +--
// | List out ASCII files.
// +--

$files_ascii = array('php'   => 1,
                     'xml'   => 1,
                     'htm'   => 1,
                     'html'  => 1,
                     'css'   => 1,
                     'cgi'   => 1,
                     'pl'    => 1,
                     'pm'    => 1,
                     'shtml' => 1,
                     'txt'   => 1,
                     'dhtml' => 1,
                     'js'    => 1,
                     'tmpl'  => 1,
                     'csv'   => 1);

// +--
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$name = preg_replace('/\.\./','',$name);

// +--
// | If $name is blank, we return an error.
// +--

if (!($name)) {

     $message = "The file_write() function was accessed
                 with a blank file name.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | If the destination file exists, we attempt to delete it.  If the
// | delete does not work, we have to abort.
// +--

if (@file_exists($name)) {

     @unlink($name);

} // End of if statement.

if (@file_exists($name)) {

     $message = "The file_write() function failed to delete the file: {$name}.
                 The file existed prior to writing data to it.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Do line ending replacements on text files.
// +--

$pathinfo = pathinfo($name);

if ((isset($pathinfo['extension'])) && (array_key_exists($pathinfo['extension'],$files_ascii))) {

     $data = preg_replace('/\015\012|\012|\015/',"\015\012",$data);

} // End of if statement.

// +--
// | Set permissions.
// +--

$perms = $this->globals('core.perms_level_files');

// +--
// | If the permissions on the destination directory are executable,
// | and the file is a .php file, make the file executable.
// +--

if ((isset($pathinfo['dirname'])) && (isset($pathinfo['extension'])) && ($pathinfo['extension'] == 'php')) {

     $dirname = $pathinfo['dirname'];

     while (preg_match('/\\\\/',$dirname)) {$dirname = preg_replace('/\\\\/','/',$dirname);}

     while (preg_match('/\/\//',$dirname)) {$dirname = preg_replace('/\/\//','/',$dirname);}

     $dirname = preg_replace('/\/$/','',$dirname);

     if (@file_exists($dirname)) {

          $perms_dir = @substr(@decoct(@fileperms($dirname)),2);

          if ((!(empty($perms_dir))) && ($perms_dir == $this->globals('core.perms_level_exec'))) {

               $perms = $this->globals('core.perms_level_exec');

          } // End of if statement.

     } // End of if statement.

} // End of if statement.

// +--
// | Open a file handle and write to the file.
// +--

$fh = @fopen($name, 'wb');

// +--
// | If the handle was opened, we can write to the file.
// +--

if ($fh) {

     @flock($fh, LOCK_EX);

     @fwrite($fh, $data);

     @flock($fh, LOCK_UN);

     @fclose($fh);

     // +--
     // | Clear our stat cache and chmod the file.
     // +--

     @clearstatcache();

     @chmod($name, intval($perms, 8));

} // End of if statement.

// +--
// | Check to be sure the file was written.
// +--

if (!(@file_exists($name))) {

     $message = "The file_write() function failed to create the file: {$name}.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: file_delete                                            |
// +------------------------------------------------------------------+

function file_delete ($name = '') {

// +--
// | This routine deletes a file.
// | 
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$name = preg_replace('/\.\./','',$name);

// +--
// | If $name is blank, we return an error.
// +--

if (!($name)) {

     $message = "The file_delete() function was accessed 
                 with a blank file name.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | If the file exists, we delete it.
// +--

if (@file_exists($name)) {

     @unlink($name);

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: make_dir                                               |
// +------------------------------------------------------------------+

function make_dir ($dir = '', $isexec = 0) {

// +--
// | This routine creates a directory.
// | 
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$dir = preg_replace('/\.\./','',$dir);

if (empty($dir)) {

     $message = "The make_dir function was accessed with incomplete data.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Return true if the directory already exists.
// +--

if (@file_exists($dir)) {return 1;}

// +--
// | Make the directory and handle errors.
// +--

umask(0);

$perms = $this->globals('core.perms_level_dirs');

if (!(empty($isexec))) {$perms = $this->globals('core.perms_level_exec');}

if (!(@mkdir($dir, intval($perms, 8)))) {

     $message = "The make_dir was unable to create the directory: {$dir}.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | For public directories, create index.html and default.html
// | files.
// +--

$pub_quoted = preg_quote($this->globals('core.path_public') . '/','/');

if (preg_match('/^' . $pub_quoted . '/',$dir)) {

     $blank_xhtml = $this->blank_xhtml();

     $this->file_write(array('name' => $dir . '/index.html',
                             'data' => $blank_xhtml));

     $this->file_write(array('name' => $dir . '/default.html',
                             'data' => $blank_xhtml));

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: delete_dir                                             |
// +------------------------------------------------------------------+

function delete_dir ($directory = '') {

// +--
// | This routine recursively deletes a directory and it's contents.
// |
// | Remove any double dots so as to prevent reverse directory 
// | recursion.
// +--

$directory = preg_replace('/\.\./','',$directory);

// +--
// | If the directory is blank, return true.
// +--

if (empty($directory)) {

     return 1;

} // End of if statement.

// +--
// | This function deletes an entire directory. This code is based 
// | on code provided at Aidan's PHP Repository. The original source
// | code was offered for free without license.
// +--

// +--
// | Check to make sure we have a valide directory to delete.  If
// | not, return true.
// +--

if (!(@file_exists($directory))) {

     return 1;

} // End of if statement.

// +--
// | If it's just a file, delete it.
// +--

if ((is_file($directory)) || (is_link($directory))) {

     return @unlink($directory);

} // End of if statement.

// +--
// | Loop through the directory.
// +--

$dir = @dir($directory);

while (false !== $entry = $dir->read()) {

     // +--
     // | Skip pointers.
     // +--

     if ($entry == '.' || $entry == '..') {

          continue;

     } // End of if statement.

     // +--
     // | Recurse the directory.
     // +--

     $this->delete_dir($directory . '/' . $entry);

} // End of while statement.
  
// +--
// | Clean up.
// +--

$dir->close();

return @rmdir($directory);

} // End of function.

// +------------------------------------------------------------------+
// | Function: setupdirs                                              |
// +------------------------------------------------------------------+

function setupdirs () {

// +--
// | This function makes sure all the directories we need to run
// | installs for PEAR and CORE exist.
// +--

$dirs_private = array('temp','core','apps','pear','downloads','uploads');

$dirs_public  = array('media','downloads','skins','uploads','utilities');

// +--
// | Loop through our private directories and create them if they
// | don't exist.
// +--

foreach ($dirs_private as $key => $dirname) {

     $directory = $this->globals('core.path_private') . '/' . $dirname;
     if (!(@file_exists($directory))) {

          umask(0);

          $result = $this->make_dir($directory);

          if ($this->IsError($result)) {

               $message = "The installer was unable to create a '{$dirname}' 
                           directory within the Private Directory Path.  
                           Permissions may be incorrect on this directory. 
                           Error Information: " . $this->GetMessage($result);

               $result = $this->RaiseError($message);

               return $result;

          } // End of if statement.

     } // End of if statement.

} // End of foreach statement.

// +--
// | Loop through our public directories and create them if they
// | don't exist.
// +--

foreach ($dirs_public as $key => $dirname) {

     $directory = $this->globals('core.path_public') . '/' . $dirname;

     if (!(@file_exists($directory))) {

          umask(0);

          $isexec = 0; if ($dirname != 'media') {$isexec = 1;}

          $result = $this->make_dir($directory,$isexec);

          if ($this->IsError($result)) {

               $message = "The installer was unable to create a '{$dirname}' 
                           directory within the Public Directory Path.  
                           Permissions may be incorrect on this directory. 
                           Error Information: " . $this->GetMessage($result);

               $result = $this->RaiseError($message);

               return $result;

          } // End of if statement.

     } // End of if statement.

} // End of foreach statement.

// +--
// | Create a .htaccess file in the private directory for security
// | purposes.  Do not handle errors here.
// +--

$dest = $this->globals('core.path_private') . '/.htaccess';

if (!(@file_exists($dest))) {

     $file_contents = $this->private_htaccess();

     $this->file_write(array('name' => $dest,
                             'data' => $file_contents));

} // End of if statement.

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: blank_xhtml                                            |
// +------------------------------------------------------------------+

function blank_xhtml () {

// +--
// | This function returns content for a blank XHTML file.
// +--

return <<<ENDOFTEXT

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

<style type="text/css" media="all">

body {
     font-family: Verdana, Tahoma, Arial, sans-serif;
     font-size: 12px;
     color: #333333;
     font-weight: normal;
     text-align: left;
     background-color: #F5F5F5;
     margin: 20px;
     }

#content {
     color: #333333;
     background-color: #FFFFFF;
     border: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: auto;
     -moz-border-radius: 8px 8px 8px 8px;
     -webkit-border-radius: 8px 8px 8px 8px;
     border-radius: 8px 8px 8px 8px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     line-height: 1.5em;
     }

#pgtitle {
     color: #4E70AE;
     padding: 0px;
     margin: 0px 0px 10px 0px;
     font-weight: bold;
     font-size: 18px;
     }

</style>

<title>Directory Index File</title>

</head>

<body>

<div id="content">

<div id="pgtitle">Directory Index File</div>

<p>You have accessed a directory index file.</p>


</div>

</body>

</html>

ENDOFTEXT;

} // End of function.

// +------------------------------------------------------------------+
// | Function: public_config                                          |
// +------------------------------------------------------------------+

function public_config () {

// +--
// | This function returns a representation of the primary public 
// | config file to be used.
// +--

return <<<ENDOFTEXT
<?php 

\$config['core.password'] = '';
\$config['core.path_public'] = '';
\$config['core.path_private'] = '';
\$config['core.script_frontend'] = '';
\$config['core.script_backend'] = '';

?>
ENDOFTEXT;

} // End of function.

// +------------------------------------------------------------------+
// | Function: private_config                                         |
// +------------------------------------------------------------------+

function private_config () {

$password_copy = $this->globals('core.password');

return <<<ENDOFTEXT
<?php 

\$config['core.password_copy'] = '{$password_copy}';
\$config['core.url_nonssl'] = '';
\$config['core.url_ssl'] = '';
\$config['core.port_ssl'] = '';
\$config['core.cookie_domain_nonssl'] = '';
\$config['core.cookie_path_nonssl'] = '';
\$config['core.cookie_domain_ssl'] = '';
\$config['core.cookie_path_ssl'] = '';
\$config['core.reg_lickey'] = '';
\$config['core.reg_fname'] = '';
\$config['core.reg_lname'] = '';
\$config['core.reg_email'] = '';
\$config['core.cryptkey'] = '';
\$config['core.db_dbtype'] = '';
\$config['core.db_hostname'] = '';
\$config['core.db_dbname'] = '';
\$config['core.db_username'] = '';
\$config['core.db_password'] = '';
\$config['core.curl_proxyurl'] = '';
\$config['core.curl_proxyuser'] = '';
\$config['core.curl_proxypass'] = '';
\$config['core.curl_proxyhttp'] = '';
\$config['core.curl_proxyhttps'] = '';
\$config['core.mail_mailtype'] = '';
\$config['core.mail_sendmail'] = '';
\$config['core.mail_host'] = '';
\$config['core.mail_port'] = '';
\$config['core.mail_user'] = '';
\$config['core.mail_pass'] = '';
\$config['core.install_pearsource'] = '';
\$config['core.install_pear'] = '';
\$config['core.install_core'] = '';
\$config['core.install_apps'] = '';
\$config['core.install_db'] = '';

?>
ENDOFTEXT;

} // End of function.

// +------------------------------------------------------------------+
// | Function: private_htaccess                                       |
// +------------------------------------------------------------------+

function private_htaccess () {

// +--
// | This function returns a representation of a private .htaccess
// | file.
// +--

return <<<ENDOFTEXT
AuthUserFile /none/
AuthGroupFile /none/
AuthName ByPassword
AuthType Basic
<Limit GET>
require valid-user
</Limit>
ENDOFTEXT;

} // End of function.

// +------------------------------------------------------------------+
// | Function: writeconfig                                            |
// +------------------------------------------------------------------+

function writeconfig ($varname = '',$varvalue = '',$pubpriv = 'PUBLIC') {

// +--
// | This function writes new variable values out to a config
// | file.
// +--

if ((empty($varname)) || (empty($pubpriv))) {

     $message = "The writeconfig() function was accessed with invalid 
                 parameters.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Define our file.
// +--

if ($pubpriv == 'PRIVATE') {

     $file = $this->globals('core.path_private') . '/config.php';

} else {

     $file = $this->globals('core.main_path_force') . '/config.php';

} // End of if statement.

// +--
// | Get our strings set up.
// +--

$name    = $varname;
$value   = addslashes($varvalue);
$find    = '/\$config\[\'' . $name . '\'\] = \'.*?\';/';
$replace = '$config[\'' . $name . '\'] = \'' . $value .'\';';

// +--
// | Get the contents of our file.
// +--

$file_contents = $this->file_read($file);

if ($this->IsError($file_contents)) {return $file_contents;}

// +--
// | Do the data replacement.
// +--

$file_contents = preg_replace($find, $replace, $file_contents);

// +--
// | Write the file back out.
// +--

$result = $this->file_write(array('name' => $file,
                                  'data' => $file_contents));

if ($this->IsError($result)) {return $result;}

// +--
// | Check to be sure our value was written out.  If not we return
// | false.  
// +--

$file_contents = $this->file_read($file);

if ($this->IsError($file_contents)) {return $file_contents;}

if (!(strstr($file_contents, $replace))) {

     $message = "The writeconfig() function was unable to save data 
                 to the configuration file.";

     $result = $this->RaiseError($message);

     return $result;
     
} // End of if statement.

// +--
// | Globalize our value.
// +--

$this->globals($varname,$varvalue);

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Curl Functions                                                   |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: exec_curl                                              |
// +------------------------------------------------------------------+

function exec_curl ($input = array()) {

// +--
// | Set our default function values.
// +--

$url  = (isset($input['url'])  ? $input['url']   : '');
$type = (isset($input['type']) ? $input['type']  : 'POST');
$mode = (isset($input['mode']) ? $input['mode']  : 'HTTP');
$data = (isset($input['data']) ? $input['data']  : array());

unset($input);

// +--
// | Define our method variables based on our core configuration
// | as created by our installer.
// +--

$proxyurl   = $this->globals('core.curl_proxyurl');
$proxyuser  = $this->globals('core.curl_proxyuser');
$proxypass  = $this->globals('core.curl_proxypass');
$proxyhttp  = $this->globals('core.curl_proxyhttp');
$proxyhttps = $this->globals('core.curl_proxyhttps');

// +--
// | Make sure our URL was submitted.  If we don't have a
// | URL, we return a PEAR error.
// +--

if (!($url)) {

     $message = "A request was made to connect to a remote URL, however 
                 the request did not contain a URL.";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Make sure we have a valid mode (HTTP|HTTPS).  If not, we 
// | return an error.
// +--

if (($mode != 'HTTP') && ($mode != 'HTTPS')) {

     $message = "A request was made to connect to a remote URL, however 
                 the request did not contain a valid HTTP or HTTPS mode. 
                 URL: {$url}";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Make sure our request is either GET or POST.  If we don't 
// | have a GET or POST request, we return a PEAR error.
// +--

if (($type != 'POST') && ($type != 'GET')) {

     $message = "A request was made to connect to a remote URL, however 
                 the request type submitted was not a valid POST or GET 
                 request. URL: {$url}";

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Build out our query string.
// +--

$query_string = '';

if (is_array($data)) {

     foreach ($data as $name => $value) {

          $query_string .= $name . '=' . urlencode($value) . '&';

     } // End of foreach statement.

     if ($query_string) {

          $query_string = substr($query_string, 0, -1);
          $query_string = htmlentities($query_string);

     } // End of if statement.

} // End of if statement.

// +--
// | Set our URL parameter.  If we have a GET request, we build
// | our $query_string onto our URL.
// +--

if (($type == 'GET') && ($query_string)) {

     $url .= '?' . $query_string;

} // End of if statement.

// +--
// | Initiate a cURL handle.
// +--

$ch = curl_init();

// +--
// | Set our URL parameter.
// +--

curl_setopt($ch, CURLOPT_URL, $url);

// +--
// | Set our POST options if this is a POST request.  We set the 
// | post fields to the $query_string if $data was an array.
// | Otherwise we set our post fields to the $data variable.
// +--

if (($type == 'POST') && ($query_string)) {

     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);

} elseif (($type == 'POST') && ($data)) {

     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

} // End of if statement.

unset($data);

// +--
// | Define our referer (sp. referrer).
// +--

$insname   = $this->globals('installer.script_name');

$referer   = $this->globals('core.url_nonssl') . '/' . $insname;

// +--
// | Define our user agent.
// +--

$user_agent = 'Kryptronic Software Installer ' . $this->version;

// +--
// | Set other cURL options.
// +--

curl_setopt($ch, CURLOPT_TIMEOUT, 25);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $referer);
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);

// +--
// | If we use a proxy, we configure it here.
// +--

if ($proxyurl) {

     if (($mode == 'HTTP') && ($proxyhttp)) {

          curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
          curl_setopt($ch, CURLOPT_PROXY, $proxyurl);

          if (($proxyuser) && ($proxypass)) {

               $user_pass = $proxyuser . ':' . $proxypass;

               curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);

          } // End of if statement.

     } // End of if statement.

     if (($mode == 'HTTPS') && ($proxyhttps)) {

          curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
          curl_setopt($ch, CURLOPT_PROXY, $proxyurl);

          if (($proxyuser) && ($proxypass)) {

               $user_pass = $proxyuser . ':' . $proxypass;

               curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);

           } // End of if statement.

      } // End of if statement.

} // End of if statement.

// +--
// | Set verifyPeer and verifyHost to false to avoid Peer and Host
// | verification errors (especially on Windows).
// +--

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

// +--
// | Execute our cURL request.
// +--

$result = curl_exec($ch);

// +--
// | If our request was successful, we return our result.
// | Otherwise we return an error.
// +--

if (!($result)) {

     $message = curl_error($ch);

     if (!($message)) {

          $message = "A request was made to connect to a remote URL, 
                      however there was a general cURL error while 
                      processing the request. URL: {$url}";

     } // End of if statement.

     $result = $this->RaiseError($message);

     return $result;

} // End of if statement.

// +--
// | Return the result.
// +--

return $result;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Misc. Functions                                                  |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: random_key                                             |
// +------------------------------------------------------------------+

function random_key ($length = 16) {

// +--
// | This function creates a random key of alpha and numeric characters
// | to be used in a variety of ways.  One example is as a session id.
// | This could also be used as random string or password generator.
// | Length can be anywhere between 8 and 64 digits with a default of
// | 16.
// +--

$random_key = '';

// +--
// | Handle issues with the passed length.
// +--

settype($length,'integer');

if ($length < 8) {$length = 8;}
if ($length > 64) {$length = 64;}

// +--
// | Create our key from a pattern of alpha and numeric characters.
// +--

$pattern  = 'abcdef0123456789';

for ($i = 0; $i < $length; $i++) {

     if (isset($random_key)) {

          $random_key .= $pattern{rand(0,15)};

     } else {

          $random_key  = $pattern{rand(0,15)};

     } // End of if statement.

} // End of for statement.

// +--
// | Return the random key.
// +--

return $random_key;

} // End of function.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Error Object Class Functions (Like PEAR_Error)                   |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Function: iserror                                                |
// +------------------------------------------------------------------+

function iserror ($object = '') {

// +--
// | This function checks to see if a given object is an error object.
// +--

if (!(is_object($object))) {return false;}

$error_classes = array('COREerror'     => 1,
                       'coreerror'     => 1, 
                       'PEAR_Error'    => 1,
                       'pear_error'    => 1,
                       'COREinsterror' => 1,
                       'coreinsterror' => 1);

$class = get_class($object);

if (array_key_exists($class,$error_classes)) {

     return 1;

} // End of if statement.

return false;

} // End of function.

// +------------------------------------------------------------------+
// | Function: raiseerror                                             |
// +------------------------------------------------------------------+

function &raiseerror ($message = '') {

// +--
// | This function creates an error object and returns it.
// +--

if (empty($message)) {$message = 'Unknown error.';}

@$error_object = new COREinsterror($message);

// +--
// | Return a reference to the error object created.
// +--

return $error_object;

} // End of function.

// +------------------------------------------------------------------+
// | End of Class                                                     |
// +------------------------------------------------------------------+

} // End of class.

// +------------------------------------------------------------------+
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// |                                                                  |
// | Error Object Class                                               |
// |                                                                  |
// |------------------------------------------------------------------|
// |------------------------------------------------------------------|
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | Class Definition: COREinsterror                                  |
// +------------------------------------------------------------------+

class COREinsterror {

// +--
// | This class creates error objects for internal error handling.
// +--

// +------------------------------------------------------------------+
// | Class Variables                                                  |
// +------------------------------------------------------------------+

var $class   = 'COREinsterror';
var $version = '8.0.0';

var $message = 'Unknown error message.';

// +------------------------------------------------------------------+
// | Constructor Function                                             |
// +------------------------------------------------------------------+

function COREinsterror ($errormsg = '') {

// +--
// | This is the constructor function.  This function starts up the
// | class.  Any pre-load variable assignments go here.
// +--

$this->message = $errormsg;

// +--
// | Return object.
// +--

return $this;

} // End of function.

// +------------------------------------------------------------------+
// | Function: getmessage                                             |
// +------------------------------------------------------------------+

function getmessage () {

// +--
// | This function returns an error message for an object.
// +--

// +--
// | Return the message.
// +--

return $this->message;

} // End of function.

// +------------------------------------------------------------------+
// | End of Class                                                     |
// +------------------------------------------------------------------+

} // End of class.

// +------------------------------------------------------------------+
// | End Of File                                                      |
// +------------------------------------------------------------------+

?>