<?php 

// +------------------------------------------------------------------+
// |                                                                  |
// | Copyright 1999-Present Kryptronic, Inc. All rights reserved.     |
// |                                                                  |
// | This software is copyrighted, trademarked, developed and         |
// | licensed by Kryptronic, Inc. This software is distributed        |
// | under license.                                                   |
// |                                                                  |
// | View the license agreement for more information.  Installation   |
// | of this software package indicates acceptance of the license     |
// | agreement.                                                       |
// |                                                                  |
// +------------------------------------------------------------------+

// +------------------------------------------------------------------+
// | IF INSTRUCTED TO EDIT THE $main_path_force VARIABLE, EDIT THE    |
// | VALUE BETWEEN THE SINGLE QUOTES ON THE FOLLOWING LINE.           |
// +------------------------------------------------------------------+

$main_path_force   = '';

$perms_level_files  = '777';
$perms_level_dirs   = '777';
$perms_level_exec   = '777';

// +------------------------------------------------------------------+
// | DO NOT EDIT BELOW THIS LINE.                                     |
// +------------------------------------------------------------------+

// +--
// | Debugger Note:  If you would like to turn debugging on, once the
// | core is installed you can adjust the class $debug variable in
// | the file {PRIVATE}/core/CORE/CORE.php.  The following settings
// | apply:
// |
// | 0:         Debugging off (default)
// | 1:         File-based output (sent to {PRIVATE}/temp directory)
// | 2:         Browser-based output (sent to web browser)
// +--

// +--
// | The following parameters are to be left alone.  They represent
// | core directives that affect how this program operates when 
// | executed.  These parameters need to remain unchanged here but 
// | may require changes to run other core-based scripts via methods
// | like cron.
// |
// | app:       The 'app' parameter is generally left blank.  'app' is
// |            passed using URL parameters.
// |
// | namespace: The 'namespace' parameter is generally left blank.  
// |            'namespace' is passed using URL parameters.
// |
// | interface: The 'interface' parameter dictates the interface
// |            to be run by the core.
// | 
// |            Value FrontEnd:  Produces frontend interface
// |            Value BackEnd:   Produces backend (admin) interface
// |            Value Installer: Produces installer (admin without
// |                             login) interface
// |
// | output:    The 'output' parameter allows the caller script to
// |            run the core without any output being generated.
// |           
// |            Value 0:         No Output Produced
// |            Value 1:         Output standards compliant XHTML
// |
// | errhandle: The 'errhandle' parameter allows the caller script to
// |            specify whether errors should be triggered or returned
// |            in an array.
// |           
// |            Value 0:         Trigger error in core
// |            Value 1:         Return a COREerror object.
// +--

$interface = 'BackEnd';
$output    = 1;
$errhandle = 0;

// +--
// | Set permissions level for executable files and 
// | dirs to the same level as this file.
// +--

$thisfile = __FILE__;

while (preg_match('/\\\\/',$thisfile)) {$thisfile = preg_replace('/\\\\/','/',$thisfile);}

while (preg_match('/\/\//',$thisfile)) {$thisfile = preg_replace('/\/\//','/',$thisfile);}

$thisfile = preg_replace('/\/$/','',$thisfile);

$thisfile_perms = @substr(@decoct(@fileperms($thisfile)),3);

if (!(empty($thisfile_perms))) {

     $perms_level_exec = $thisfile_perms;

} // End of if statement.

// +--
// | Main program loader.  This object call creates an instance
// | of the COREmain class.  When the exec() function runs, the
// | program runs and produces output.  We exit() afterwards.
// +--

$coremain = new COREmain;

$coremain->exec(array('core.main_path_force'    => $main_path_force,
                      'core.interface'          => $interface,
                      'core.output'             => $output,
                      'core.errhandle'          => $errhandle,
                      'core.perms_level_files'  => $perms_level_files,
                      'core.perms_level_dirs'   => $perms_level_dirs,
                      'core.perms_level_exec'   => $perms_level_exec));

// +--
// | Exit() is called from within the core during it's shutdown
// | function, however it's good practice to call it here as well
// | to handle garbage collection.
// +--

exit();

// +------------------------------------------------------------------+
// | Class Definition                                                 |
// +------------------------------------------------------------------+

class COREmain {

// +--
// | This class is used to verify the PHP environment we're running
// | in, load and execute the CORE class and provide error handling
// | outside of the scope of the main core class.
// +--

// +------------------------------------------------------------------+
// | Class Variables                                                  |
// +------------------------------------------------------------------+

var $class   = 'COREmain';
var $version = '8.0.0';
var $cerror;

// +------------------------------------------------------------------+
// | Constructor Function                                             |
// +------------------------------------------------------------------+

function COREmain () {

// +--
// | This is the constructor function.  This function starts up the
// | class.  Any pre-load variable assignments go here.
// +--

// +--
// | Return object.
// +--

return $this;

} // End of function.

// +------------------------------------------------------------------+
// | Function: exec                                                   |
// +------------------------------------------------------------------+

function exec ($input = array()) {

// +--
// | This routine is run to run the internals of the class.  Main class
// | logic is contained in this function.
// +--

// +--
// | Globalize our input array.
// +--

if (!(empty($input))) {

     foreach ($input as $key => $value) {$this->globals($key,$value);}

} // End of if statement.

// +--
// | Set error handling up to output errors to the browser.  We handle
// | all errors except for E_NOTICE errors.
// +--

ini_set('display_errors','1');

error_reporting(E_ALL ^ E_NOTICE);

set_error_handler(array(&$this,'error_display'));

// +--
// | Determine the directory from where we're running this program.
// +--

$path = $this->globals('core.main_path_force');

if ((!(empty($path))) && (@file_exists($path))) {

     $path = $this->globals('core.main_path_force');

} elseif (@file_exists(dirname(__FILE__))) {

     $path = dirname(__FILE__);

} elseif (@file_exists(getcwd())) {

     $path = getcwd();

} elseif (@file_exists(dirname($_SERVER['PATH_TRANSLATED']))) {

     $path = dirname($_SERVER['PATH_TRANSLATED']);

} elseif (@file_exists(dirname($_SERVER['SCRIPT_FILENAME']))) {

     $path = dirname($_SERVER['SCRIPT_FILENAME']);

} else {

     $errstr = "

     <p>This script could not determine the directory from which it is 
     being executed.  You need to edit the scripts 'index.php', 'admin.php' 
     and 'installer.php' and enter a value for the \$main_path_force 
     variable at the top of those scripts. Follow the instructions in each of 
     those scripts for more information.</p>

     <p>If you have already edited the \$main_path_force variable and are 
     seeing this message again, the value you used for that variable 
     appears to be incorrect.  Please try again.</p>

     ";

     trigger_error($errstr,E_USER_ERROR);

} // End of if statement.

// +--
// | Format our working directory we've just determined and globalize it.
// +--

$path = $this->paths_convert($path);

$this->globals('core.main_path_force',$path);

// +--
// | Include our config.php in the public directory.  Globalize the 
// | config array.
// +--

if (@file_exists($this->globals('core.main_path_force') . '/config.php')) {

     include($this->globals('core.main_path_force') . '/config.php');

     foreach ($config as $key => $value) {$this->globals($key,$value);}

     unset($config);

} // End of if statement.

// +--
// | If the $config array key 'core.path_private' was not defined,
// | we had a problem and need to error out.
// +--

$pathpriv = $this->globals('core.path_private');

if (empty($pathpriv)) {

     $errstr = "

     <p>It appears you have not run the core 
     installer script.  You need to run the installer script before
     accessing this script.</p>

     <p><a href=\"installer.php\" title=\"Installer\">Click here to run
     the installer script.</a></p>

     ";

     trigger_error($errstr,E_USER_ERROR);

} // End of if statement.

// +--
// | Our private config file will be included automatically
// | by the core when it loads up.
// |
// | Now that we have our public config file included,
// | we can include our main core file.
// +--

$privpath = $this->globals('core.path_private');

if (@file_exists($privpath . '/core/CORE/CORE.php')) {

     include_once($privpath . '/core/CORE/CORE.php');

// +--
// | If there is a problem finding the file, we error out.
// +--

} else {

     $errstr = "

     <p>This script could not locate the file 'CORE.php' in the
     directory:</p>

     <p>{$privpath}/core/CORE</p>

     <p>This could be the result of an incomplete installation.  The
     configuration files created by the installer appear to be complete, 
     however the installation of the codebase is incomplete.  This is a
     fatal error that cannot be resolved automatically.  Reinstall the
     software to continue.</p>

     <p><a href=\"installer.php\" title=\"Installer\">Click here to run
     the installer script.</a></p>

     ";

     trigger_error($errstr,E_USER_ERROR);

} // End of if statement.

// +--
// | If we were able to include our main core file, we can run the core.
// | Above we set 'output' to '1' and 'errtype' to '0' so the core will 
// | produce output and trigger errors internally.  There is no need to
// | check for errors at this level.  We run three methods on the core
// | object:
// |
// | new (constructor):  To create the object and run startup tasks.
// | exec:               To run the component phase.
// | shutdown:           To run shutdown tasks and produce output.
// +--

global $xglobal_cache;

$core = new CORE($xglobal_cache);

$core->exec();

$core->shutdown();

// +--
// | Return true.
// +--

return 1;

} // End of function.

// +------------------------------------------------------------------+
// | Function: globals                                                |
// +------------------------------------------------------------------+

function globals ($name = '',$value = null,$default = null) {

// +--
// | This function maintains a global array of global variables for
// | use within the program.  Global variables can be set, changed and
// | obtained from this function.
// +--

global $xglobal_cache;

// +--
// | If the request contained a default identifier (passed as a true
// | value), we set a default value if the global doesn't exist.
// +--

if ((!(empty($name))) && (isset($value)) && (isset($default)) && (!(isset($xglobal_cache[$name])))) {

     $xglobal_cache[$name] = $value;

     return $value;

} // End of if statement.

// +--
// | Set requests have both a name and value passed
// | to this function.
// +--

if ((!(empty($name))) && (isset($value)) && (!(isset($default)))) {

     $xglobal_cache[$name] = $value;

     return $value;

} // End of if statement.

// +--
// | Get requests have only a global variable name
// | passed to this function.
// +--

if ((!(empty($name))) && (isset($xglobal_cache[$name]))) {

     return $xglobal_cache[$name];

} // End of if statement.

// +--
// | All other requests result in a null return value.
// +--

return null;

} // End of function.

// +------------------------------------------------------------------+
// | Function: paths_convert                                          |
// +------------------------------------------------------------------+

function paths_convert ($string) {

// +--
// | This function converts filesystem paths to unix-style and strips
// | any trailing slashes.
// +--

while (preg_match('/\\\\/',$string)) {$string = preg_replace('/\\\\/','/',$string);}

while (preg_match('/\/\//',$string)) {$string = preg_replace('/\/\//','/',$string);}

$string = preg_replace('/\/$/','',$string);

return $string;

} // End of function.

// +------------------------------------------------------------------+
// | Function: paths_strip                                            |
// +------------------------------------------------------------------+

function paths_strip ($string) {

// +--
// | This function strips full server paths from a given string for
// | security purposes.
// +--

$pathpub   = $this->globals('core.path_public');
$pathpriv  = $this->globals('core.path_private');
$pathforce = $this->globals('core.main_path_force');

$string = str_replace('\\','/',$string);

if (!(empty($pathforce))) {

     $find   = preg_quote($pathforce . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.
 
if (!(empty($pathpub))) {

     $find   = preg_quote($pathpub . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.

if (!(empty($pathpriv))) {

     $find   = preg_quote($pathpriv . '/','/');
     $string = preg_replace('/' . $find . '/','/',$string);

} // End of if statement.

return $string;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_display                                          |
// +------------------------------------------------------------------+

function error_display ($errno = '',$errstr = '',$errfile = '',$errline = '') {

// +--
// | This function is called via PHP when an error is encountered.
// | Scripts pass errors through this function via PHP's trigger_error
// | function using:
// |
// | trigger_error('some_error_message',E_USER_ERROR);
// | 
// | PHP also passes errors through this function without script
// | intervention.
// +--

// +--
// | If we've hit this function with a suppressed error or an E_STRICT
// | or E_NOTICE error, we return.
// +--

if ((error_reporting() == 0) || ($errno == E_NOTICE) || ($errno == E_STRICT)) {

     return 1;

} // End of if statement.

// +--
// | If we are currently buffering output, destroy the buffer
// | and reset buffer status.
// +--

if ($this->globals('installer.buffer_status')) {

     @ob_end_clean();

     $this->globals('installer.buffer_status',0);

} // End of if statement.

// +--
// | Modify our $errfile if it is non-blank.  We want to remove
// | full paths from error messages to increase security.
// +--

if ($errfile) {$errfile = $this->paths_strip($errfile);}

// +--
// | Modify our $errstr if it is non-blank.  We want to add <p>
// | tags if they're not there.
// +--

if (($errstr) && (!(preg_match('/<p>/',$errstr)))) {

     $errstr = '<p>' . $errstr . '</p>';

} // End of if statement.

// +--
// | Print output header.
// +--

print $this->error_div_header();

// +--
// | Print output content.
// +--

if ($errstr) {print $this->error_div_content($errstr);}

// +--
// | Print output info.
// +--

if ($errno && $errline && $errfile) {print $this->error_div_info($errno,$errline,$errfile);}

// +--
// | Print output footer.
// +--

print $this->error_div_footer();

// +--
// | This was a fatal error so we exit.
// +--

exit();

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_header                                       |
// +------------------------------------------------------------------+

function error_div_header () {

// +--
// | This function prints the error header.
// +--

$xhtml = <<<ENDOFTEXT

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" /> 

<style type="text/css" media="all">

body {
     font-family: Verdana, Tahoma, Arial, sans-serif;
     font-size: 12px;
     color: #333333;
     font-weight: normal;
     text-align: left;
     background-color: #F5F5F5;
     margin: 20px;
     }

a {
     color: #30569D;
     text-decoration: none;
     font-weight: normal;
     }

a:hover {
     text-decoration: underline;
     }

.strong {
     font-weight: bold;
     }

#content {
     color: #333333;
     background-color: #FFFFFF;
     border: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: 0px auto 0px auto;
     -moz-border-radius: 8px 8px 0px 0px;
     -webkit-border-radius: 8px 8px 0px 0px;
     border-radius: 8px 8px 0px 0px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     line-height: 1.5em;
     }

#info {
     color: #333333;
     background-color: #FFFFFF;
     border-left: 1px solid #333333;
     border-right: 1px solid #333333;
     border-bottom: 1px solid #333333;
     width: 600px;
     padding: 10px;
     margin: 0px auto 0px auto;
     -moz-border-radius: 0px 0px 8px 8px;
     -webkit-border-radius: 0px 0px 8px 8px;
     border-radius: 0px 0px 8px 8px;
     -moz-box-shadow: 2px 2px 2px #333333;
     -webkit-box-shadow: 2px 2px 2px #333333;
     box-shadow: 2px 2px 2px #333333;
     font-size: 11px;
     }

#pgtitle {
     color: #4E70AE;
     padding: 0px;
     margin: 0px 0px 10px 0px;
     font-weight: bold;
     font-size: 18px;
     }

</style>

<title>Script Execution Error</title>

</head>

<body>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_content                                      |
// +------------------------------------------------------------------+

function error_div_content ($errstr = '') {

// +--
// | This function prints the error contet.
// +--

$xhtml = <<<ENDOFTEXT

<div id="content">

<div id="pgtitle">Script Execution Error</div>

{$errstr}

</div>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_info                                         |
// +------------------------------------------------------------------+

function error_div_info ($errno = '',$errline = '',$errfile = '') {

// +--
// | This function prints the error info.
// +--

$xhtml = <<<ENDOFTEXT

<div id="info">File: {$errfile} Line: {$errline} Error Number: {$errno}</div>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | Function: error_div_footer                                       |
// +------------------------------------------------------------------+

function error_div_footer () {

// +--
// | This function prints the error footer.
// +--

$xhtml = <<<ENDOFTEXT

</body>

</html>

ENDOFTEXT;

return $xhtml;

} // End of function.

// +------------------------------------------------------------------+
// | End of Class                                                     |
// +------------------------------------------------------------------+

} // End of class.

// +------------------------------------------------------------------+
// | End Of File                                                      |
// +------------------------------------------------------------------+

?>